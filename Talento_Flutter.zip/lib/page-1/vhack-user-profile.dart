import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // vhackuserprofileU9N (80:1546)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogroup7fh2bDz (Kwdvu194ZsppshSatb7fH2)
              width: double.infinity,
              height: 384*fem,
              child: Stack(
                children: [
                  Positioned(
                    // topbarhnp (80:1548)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 414*fem,
                      height: 87.67*fem,
                      child: Center(
                        // backgrounddwN (80:1549)
                        child: SizedBox(
                          width: double.infinity,
                          height: 87.67*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0xffd0d1d3),
                                  offset: Offset(0*fem, 0.3300000131*fem),
                                  blurRadius: 0*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // maskgroupiC8 (80:1550)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 249*fem,
                        child: Image.asset(
                          'assets/page-1/images/mask-group-xbA.png',
                          width: 414*fem,
                          height: 249*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // barsstatusbariphonexMkt (80:1553)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                      width: 414*fem,
                      height: 44*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timestyle49W (80:1572)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                            height: double.infinity,
                            child: Text(
                              '9:41',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'SF Pro Text',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2575*ffem/fem,
                                letterSpacing: -0.3000000119*fem,
                                color: Color(0xff171717),
                              ),
                            ),
                          ),
                          Container(
                            // mobilesignalhyA (80:1567)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                            width: 18.77*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/mobile-signal-ank.png',
                              width: 18.77*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // wifiPb6 (80:1563)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                            width: 16.86*fem,
                            height: 10.97*fem,
                            child: Image.asset(
                              'assets/page-1/images/wifi-dMA.png',
                              width: 16.86*fem,
                              height: 10.97*fem,
                            ),
                          ),
                          Container(
                            // batteryVPE (80:1555)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                            width: 24.5*fem,
                            height: 10.5*fem,
                            child: Image.asset(
                              'assets/page-1/images/battery-kSt.png',
                              width: 24.5*fem,
                              height: 10.5*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group8xnc (80:1574)
                    left: 18*fem,
                    top: 44*fem,
                    child: Container(
                      width: 378*fem,
                      height: 25*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // vectorFmi (80:1575)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 331*fem, 0.96*fem),
                            width: 22*fem,
                            height: 16.04*fem,
                            child: Image.asset(
                              'assets/page-1/images/vector.png',
                              width: 22*fem,
                              height: 16.04*fem,
                            ),
                          ),
                          TextButton(
                            // vectormzx (80:1576)
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 25*fem,
                              height: 25*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-jsv.png',
                                width: 25*fem,
                                height: 25*fem,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle5Gwi (80:1577)
                    left: 11*fem,
                    top: 118*fem,
                    child: Align(
                      child: SizedBox(
                        width: 393*fem,
                        height: 265*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(33*fem),
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x2d30007e),
                                offset: Offset(0*fem, 10*fem),
                                blurRadius: 25*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // maskgroupMCU (80:1578)
                    left: 164*fem,
                    top: 69*fem,
                    child: Align(
                      child: SizedBox(
                        width: 100*fem,
                        height: 100*fem,
                        child: Image.asset(
                          'assets/page-1/images/mask-group.png',
                          width: 100*fem,
                          height: 100*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // currentlyastudentpursuingproce (80:1581)
                    left: 43.5*fem,
                    top: 206*fem,
                    child: Align(
                      child: SizedBox(
                        width: 336*fem,
                        height: 46*fem,
                        child: Text(
                          'Currently a student pursuing Process and Food Engineering in University Putra Malaysia. Continue learning about science, food science, engineering and mechanical things.',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w300,
                            height: 1.2625480036*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // yiqingGCx (80:1582)
                    left: 185*fem,
                    top: 176*fem,
                    child: Align(
                      child: SizedBox(
                        width: 65*fem,
                        height: 24*fem,
                        child: Text(
                          'Yi Qing',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle6umi (80:1583)
                    left: 36*fem,
                    top: 319*fem,
                    child: Align(
                      child: SizedBox(
                        width: 168*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0xff084fff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle7Rk4 (80:1584)
                    left: 224*fem,
                    top: 319*fem,
                    child: Align(
                      child: SizedBox(
                        width: 168*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0xff084fff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // resume5pc (80:1585)
                    left: 81*fem,
                    top: 330*fem,
                    child: Align(
                      child: SizedBox(
                        width: 78*fem,
                        height: 24*fem,
                        child: Text(
                          'Resume',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.8*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // followBse (80:1586)
                    left: 276*fem,
                    top: 330*fem,
                    child: Align(
                      child: SizedBox(
                        width: 64*fem,
                        height: 24*fem,
                        child: Text(
                          'Follow',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.8*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame18skU (80:1620)
                    left: 111*fem,
                    top: 259*fem,
                    child: Container(
                      width: 193*fem,
                      height: 45*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group14nsS (80:1622)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // image156t8 (80:1624)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-15.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 29*fem,
                          ),
                          Container(
                            // group16q52 (80:1625)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // instagramicon1NKr (80:1627)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/instagramicon-1.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 29*fem,
                          ),
                          Container(
                            // group17EN4 (80:1628)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // image16Yde (80:1630)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-16-zFS.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupa3b6FY4 (KwdwajVrvmHStdLiF8a3B6)
              width: 889*fem,
              height: 502*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group112yDA (116:774)
                    left: 11*fem,
                    top: 6*fem,
                    child: Container(
                      width: 129*fem,
                      height: 214*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(21*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x26000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 15*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group10gdN (116:775)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(21*fem),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // group18SMe (116:776)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(28*fem, 71.67*fem, 26*fem, 69.67*fem),
                                width: 129*fem,
                                height: 214*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfff8f9fc),
                                  borderRadius: BorderRadius.circular(21*fem),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // line1LC8 (116:779)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 70.67*fem),
                                      width: 73*fem,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xb2979797),
                                      ),
                                    ),
                                    Container(
                                      // line2FZz (116:778)
                                      margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                      width: 73*fem,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xb2979797),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // savesBCk (116:780)
                              left: 49.5*fem,
                              top: 29.0678710938*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 34*fem,
                                  height: 39*fem,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 24*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.0918749173*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '182\n',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.3102499008*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'Saves',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 11*ffem,
                                            fontWeight: FontWeight.w300,
                                            height: 1.0918749896*ffem/fem,
                                            letterSpacing: 0.055*fem,
                                            color: Color(0xff959595),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // followersETr (116:781)
                              left: 41*fem,
                              top: 159*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 48*fem,
                                  height: 37*fem,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 18*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.171875*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '245\n',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'Followers',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 11*ffem,
                                            fontWeight: FontWeight.w300,
                                            height: 1.1725*ffem/fem,
                                            letterSpacing: 0.055*fem,
                                            color: Color(0xff959595),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // followingUmW (116:782)
                              left: 41.5*fem,
                              top: 86*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 47*fem,
                                  height: 37*fem,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 18*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.171875*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '201\n',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'Following',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 11*ffem,
                                            fontWeight: FontWeight.w300,
                                            height: 1.1725*ffem/fem,
                                            letterSpacing: 0.055*fem,
                                            color: Color(0xff959595),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group1NkQ (80:1591)
                    left: 150*fem,
                    top: 124*fem,
                    child: Container(
                      width: 249*fem,
                      height: 339*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupv1glgm6 (Kwdwxe32ZT5ywCx23EV1GL)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 7*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // image322KA (132:352)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                                  width: 119*fem,
                                  height: 123*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-32.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // image33ZZz (132:354)
                                  width: 119*fem,
                                  height: 118*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-33.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroup2yxav9e (Kwdx4PNT97Y5shB2jn2YXA)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // image341Rz (132:356)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                                  width: 120*fem,
                                  height: 123*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-34.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // image35hpc (132:358)
                                  width: 120*fem,
                                  height: 123*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-35.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroup5jfsTYt (Kwdx8iaZtyXajAKzk55JFS)
                            margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // image36yXE (132:360)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                                  width: 118*fem,
                                  height: 75*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-36.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // image37VVa (132:362)
                                  width: 120*fem,
                                  height: 80*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-37.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // savedqpL (80:1598)
                    left: 150*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 50*fem,
                        height: 22*fem,
                        child: Text(
                          'Saved',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // galleryYCx (80:1599)
                    left: 147*fem,
                    top: 96*fem,
                    child: Align(
                      child: SizedBox(
                        width: 57*fem,
                        height: 22*fem,
                        child: Text(
                          'Gallery',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group14qhr (80:1609)
                    left: 11*fem,
                    top: 242*fem,
                    child: Container(
                      width: 129*fem,
                      height: 164*fem,
                      decoration: BoxDecoration (
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x26000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 15*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group10vjJ (80:1610)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(21*fem),
                        ),
                        child: Container(
                          // group18Hpk (80:1611)
                          padding: EdgeInsets.fromLTRB(42*fem, 25*fem, 40*fem, 29*fem),
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff8f9fc),
                            borderRadius: BorderRadius.circular(21*fem),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group20PMz (80:1617)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 20*fem),
                                padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                                decoration: BoxDecoration (
                                  color: Color(0xffe8e5f2),
                                  borderRadius: BorderRadius.circular(12*fem),
                                ),
                                child: Center(
                                  // image17gbz (80:1619)
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-17.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group18RZa (80:1613)
                                margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                                decoration: BoxDecoration (
                                  color: Color(0xffe8e5f2),
                                  borderRadius: BorderRadius.circular(12*fem),
                                ),
                                child: Center(
                                  // image169kU (80:1615)
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-16-r5E.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // background58L (80:1631)
                    left: 0*fem,
                    top: 470*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 32*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xffd0d1d3),
                                offset: Offset(0*fem, -0.3300000131*fem),
                                blurRadius: 0*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnavxhv (25:2272)
                    left: 0*fem,
                    top: 409*fem,
                    child: Container(
                      width: 889*fem,
                      height: 93*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // subtractGTi (I25:2272;25:2307)
                            left: 0*fem,
                            top: 27*fem,
                            child: Align(
                              child: SizedBox(
                                width: 889*fem,
                                height: 66*fem,
                                child: Image.asset(
                                  'assets/page-1/images/subtract-HzY.png',
                                  width: 889*fem,
                                  height: 66*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bottomnaviconsCMN (I25:2272;25:2308)
                            left: 45*fem,
                            top: 40*fem,
                            child: Align(
                              child: SizedBox(
                                width: 40*fem,
                                height: 40*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.asset(
                                    'assets/page-1/images/bottom-nav-icons-1ag.png',
                                    width: 40*fem,
                                    height: 40*fem,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bottomnaviconsTo6 (I25:2272;25:2309)
                            left: 109*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 60*fem,
                                height: 60*fem,
                                child: Image.asset(
                                  'assets/page-1/images/bottom-nav-icons-E64.png',
                                  width: 60*fem,
                                  height: 60*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bottomnaviconsyWY (I25:2272;25:2310)
                            left: 192.5*fem,
                            top: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                                width: 40*fem,
                                height: 40*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(60*fem),
                                ),
                                child: Center(
                                  // image13EhN (I25:2272;25:2310;78:413)
                                  child: SizedBox(
                                    width: 26*fem,
                                    height: 26*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-13-4kg.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bottomnaviconsBsW (I25:2272;25:2311)
                            left: 266.25*fem,
                            top: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                                width: 40*fem,
                                height: 40*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(60*fem),
                                ),
                                child: Center(
                                  // image9qx4 (I25:2272;25:2311;72:1830)
                                  child: SizedBox(
                                    width: 34*fem,
                                    height: 31.66*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-9-rUp.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bottomnaviconsPig (I25:2272;25:2312)
                            left: 340*fem,
                            top: 40*fem,
                            child: Align(
                              child: SizedBox(
                                width: 40*fem,
                                height: 40*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.asset(
                                    'assets/page-1/images/bottom-nav-icons-RDi.png',
                                    width: 40*fem,
                                    height: 40*fem,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse39gxg (132:369)
                    left: 159*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-39-bg.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse38mUL (132:368)
                    left: 347*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-38-bg.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse37sXN (132:367)
                    left: 288*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-37-bg.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse40Z9J (132:373)
                    left: 223*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-40-bg.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}