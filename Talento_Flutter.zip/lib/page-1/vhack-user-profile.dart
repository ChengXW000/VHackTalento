import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // vhackuserprofileMKe (80:1546)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogroup7fh2gMv (Kwdvu194ZsppshSatb7fH2)
              width: double.infinity,
              height: 384*fem,
              child: Stack(
                children: [
                  Positioned(
                    // topbarQHv (80:1548)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 414*fem,
                      height: 87.67*fem,
                      child: Center(
                        // backgroundjb6 (80:1549)
                        child: SizedBox(
                          width: double.infinity,
                          height: 87.67*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0xffd0d1d3),
                                  offset: Offset(0*fem, 0.3300000131*fem),
                                  blurRadius: 0*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // maskgrouppcY (80:1550)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 249*fem,
                        child: Image.asset(
                          'assets/page-1/images/mask-group-P12.png',
                          width: 414*fem,
                          height: 249*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // barsstatusbariphonexLKz (80:1553)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                      width: 414*fem,
                      height: 44*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timestyleEgG (80:1572)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                            height: double.infinity,
                            child: Text(
                              '9:41',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'SF Pro Text',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2575*ffem/fem,
                                letterSpacing: -0.3000000119*fem,
                                color: Color(0xff171717),
                              ),
                            ),
                          ),
                          Container(
                            // mobilesignalHeY (80:1567)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                            width: 18.77*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/mobile-signal-Ee4.png',
                              width: 18.77*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // wifiCmW (80:1563)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                            width: 16.86*fem,
                            height: 10.97*fem,
                            child: Image.asset(
                              'assets/page-1/images/wifi-yHS.png',
                              width: 16.86*fem,
                              height: 10.97*fem,
                            ),
                          ),
                          Container(
                            // batteryL72 (80:1555)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                            width: 24.5*fem,
                            height: 10.5*fem,
                            child: Image.asset(
                              'assets/page-1/images/battery-ySY.png',
                              width: 24.5*fem,
                              height: 10.5*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group83n8 (80:1574)
                    left: 18*fem,
                    top: 44*fem,
                    child: Container(
                      width: 378*fem,
                      height: 25*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // vectornDv (80:1575)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 331*fem, 0.96*fem),
                            width: 22*fem,
                            height: 16.04*fem,
                            child: Image.asset(
                              'assets/page-1/images/vector-GHE.png',
                              width: 22*fem,
                              height: 16.04*fem,
                            ),
                          ),
                          TextButton(
                            // vectorh5z (80:1576)
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 25*fem,
                              height: 25*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector.png',
                                width: 25*fem,
                                height: 25*fem,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle5D4L (80:1577)
                    left: 11*fem,
                    top: 118*fem,
                    child: Align(
                      child: SizedBox(
                        width: 393*fem,
                        height: 265*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(33*fem),
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x2d30007e),
                                offset: Offset(0*fem, 10*fem),
                                blurRadius: 25*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // maskgrouphkC (80:1578)
                    left: 164*fem,
                    top: 69*fem,
                    child: Align(
                      child: SizedBox(
                        width: 100*fem,
                        height: 100*fem,
                        child: Image.asset(
                          'assets/page-1/images/mask-group.png',
                          width: 100*fem,
                          height: 100*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // currentlyastudentpursuingproce (80:1581)
                    left: 43.5*fem,
                    top: 206*fem,
                    child: Align(
                      child: SizedBox(
                        width: 336*fem,
                        height: 46*fem,
                        child: Text(
                          'Currently a student pursuing Process and Food Engineering in University Putra Malaysia. Continue learning about science, food science, engineering and mechanical things.',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w300,
                            height: 1.2625480036*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // yiqingmtU (80:1582)
                    left: 185*fem,
                    top: 176*fem,
                    child: Align(
                      child: SizedBox(
                        width: 65*fem,
                        height: 24*fem,
                        child: Text(
                          'Yi Qing',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle6swW (80:1583)
                    left: 36*fem,
                    top: 319*fem,
                    child: Align(
                      child: SizedBox(
                        width: 168*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0xff084fff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle7QRe (80:1584)
                    left: 224*fem,
                    top: 319*fem,
                    child: Align(
                      child: SizedBox(
                        width: 168*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0xff084fff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // resumeJG8 (80:1585)
                    left: 81*fem,
                    top: 330*fem,
                    child: Align(
                      child: SizedBox(
                        width: 78*fem,
                        height: 24*fem,
                        child: Text(
                          'Resume',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.8*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // followBap (80:1586)
                    left: 276*fem,
                    top: 330*fem,
                    child: Align(
                      child: SizedBox(
                        width: 64*fem,
                        height: 24*fem,
                        child: Text(
                          'Follow',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.8*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame18Hdr (80:1620)
                    left: 111*fem,
                    top: 259*fem,
                    child: Container(
                      width: 193*fem,
                      height: 45*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group14DXW (80:1622)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // image15wCc (80:1624)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-15.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 29*fem,
                          ),
                          Container(
                            // group16Fj6 (80:1625)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // instagramicon1NHv (80:1627)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/instagramicon-1.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 29*fem,
                          ),
                          Container(
                            // group17FMi (80:1628)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // image16aet (80:1630)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-16-aPz.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupa3b6vik (KwdwajVrvmHStdLiF8a3B6)
              width: 889*fem,
              height: 502*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group112fAY (116:774)
                    left: 11*fem,
                    top: 6*fem,
                    child: Container(
                      width: 129*fem,
                      height: 214*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(21*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x26000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 15*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group10ZWp (116:775)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(21*fem),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // group18gbS (116:776)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(28*fem, 71.67*fem, 26*fem, 69.67*fem),
                                width: 129*fem,
                                height: 214*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfff8f9fc),
                                  borderRadius: BorderRadius.circular(21*fem),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // line1yKe (116:779)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 70.67*fem),
                                      width: 73*fem,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xb2979797),
                                      ),
                                    ),
                                    Container(
                                      // line2W4g (116:778)
                                      margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                      width: 73*fem,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xb2979797),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // saves1GL (116:780)
                              left: 49.5*fem,
                              top: 29.0678710938*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 34*fem,
                                  height: 39*fem,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 24*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.0918749173*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '182\n',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.3102499008*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'Saves',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 11*ffem,
                                            fontWeight: FontWeight.w300,
                                            height: 1.0918749896*ffem/fem,
                                            letterSpacing: 0.055*fem,
                                            color: Color(0xff959595),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // followers5hS (116:781)
                              left: 41*fem,
                              top: 159*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 48*fem,
                                  height: 37*fem,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 18*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.171875*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '245\n',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'Followers',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 11*ffem,
                                            fontWeight: FontWeight.w300,
                                            height: 1.1725*ffem/fem,
                                            letterSpacing: 0.055*fem,
                                            color: Color(0xff959595),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // followingjQc (116:782)
                              left: 41.5*fem,
                              top: 86*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 47*fem,
                                  height: 37*fem,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 18*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.171875*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '201\n',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'Following',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 11*ffem,
                                            fontWeight: FontWeight.w300,
                                            height: 1.1725*ffem/fem,
                                            letterSpacing: 0.055*fem,
                                            color: Color(0xff959595),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group1Rgk (80:1591)
                    left: 150*fem,
                    top: 124*fem,
                    child: Container(
                      width: 249*fem,
                      height: 339*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupv1glfb6 (Kwdwxe32ZT5ywCx23EV1GL)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 7*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // image32Pmz (132:352)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                                  width: 119*fem,
                                  height: 123*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-32.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // image33XdJ (132:354)
                                  width: 119*fem,
                                  height: 118*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-33.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroup2yxaqdz (Kwdx4PNT97Y5shB2jn2YXA)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // image34xs2 (132:356)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                                  width: 120*fem,
                                  height: 123*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-34.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // image356iL (132:358)
                                  width: 120*fem,
                                  height: 123*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-35.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroup5jfsqvp (Kwdx8iaZtyXajAKzk55JFS)
                            margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // image36adW (132:360)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                                  width: 118*fem,
                                  height: 75*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-36.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // image37iDv (132:362)
                                  width: 120*fem,
                                  height: 80*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-37.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // savedrb2 (80:1598)
                    left: 150*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 50*fem,
                        height: 22*fem,
                        child: Text(
                          'Saved',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // galleryLFJ (80:1599)
                    left: 147*fem,
                    top: 96*fem,
                    child: Align(
                      child: SizedBox(
                        width: 57*fem,
                        height: 22*fem,
                        child: Text(
                          'Gallery',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group142tp (80:1609)
                    left: 11*fem,
                    top: 242*fem,
                    child: Container(
                      width: 129*fem,
                      height: 164*fem,
                      decoration: BoxDecoration (
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x26000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 15*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group107QU (80:1610)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(21*fem),
                        ),
                        child: Container(
                          // group18fwn (80:1611)
                          padding: EdgeInsets.fromLTRB(42*fem, 25*fem, 40*fem, 29*fem),
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff8f9fc),
                            borderRadius: BorderRadius.circular(21*fem),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group20wuJ (80:1617)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 20*fem),
                                padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                                decoration: BoxDecoration (
                                  color: Color(0xffe8e5f2),
                                  borderRadius: BorderRadius.circular(12*fem),
                                ),
                                child: Center(
                                  // image17dGL (80:1619)
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-17.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group18MTE (80:1613)
                                margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                                decoration: BoxDecoration (
                                  color: Color(0xffe8e5f2),
                                  borderRadius: BorderRadius.circular(12*fem),
                                ),
                                child: Center(
                                  // image165PE (80:1615)
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-16.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // backgroundDVS (80:1631)
                    left: 0*fem,
                    top: 470*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 32*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xffd0d1d3),
                                offset: Offset(0*fem, -0.3300000131*fem),
                                blurRadius: 0*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnavUgG (25:2272)
                    left: 0*fem,
                    top: 409*fem,
                    child: Container(
                      width: 889*fem,
                      height: 93*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // subtractmvG (I25:2272;25:2307)
                            left: 0*fem,
                            top: 27*fem,
                            child: Align(
                              child: SizedBox(
                                width: 889*fem,
                                height: 66*fem,
                                child: Image.asset(
                                  'assets/page-1/images/subtract-2GG.png',
                                  width: 889*fem,
                                  height: 66*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bottomnaviconsUpg (I25:2272;25:2308)
                            left: 45*fem,
                            top: 40*fem,
                            child: Align(
                              child: SizedBox(
                                width: 40*fem,
                                height: 40*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.asset(
                                    'assets/page-1/images/bottom-nav-icons-BDA.png',
                                    width: 40*fem,
                                    height: 40*fem,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bottomnaviconsn4g (I25:2272;25:2309)
                            left: 109*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 60*fem,
                                height: 60*fem,
                                child: Image.asset(
                                  'assets/page-1/images/bottom-nav-icons-SZN.png',
                                  width: 60*fem,
                                  height: 60*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bottomnaviconsJ32 (I25:2272;25:2310)
                            left: 192.5*fem,
                            top: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                                width: 40*fem,
                                height: 40*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(60*fem),
                                ),
                                child: Center(
                                  // image13y9A (I25:2272;25:2310;78:413)
                                  child: SizedBox(
                                    width: 26*fem,
                                    height: 26*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-13-gME.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bottomnavicons7mA (I25:2272;25:2311)
                            left: 266.25*fem,
                            top: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                                width: 40*fem,
                                height: 40*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(60*fem),
                                ),
                                child: Center(
                                  // image9oP6 (I25:2272;25:2311;72:1830)
                                  child: SizedBox(
                                    width: 34*fem,
                                    height: 31.66*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-9-YHv.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bottomnaviconsLtp (I25:2272;25:2312)
                            left: 340*fem,
                            top: 40*fem,
                            child: Align(
                              child: SizedBox(
                                width: 40*fem,
                                height: 40*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.asset(
                                    'assets/page-1/images/bottom-nav-icons-BJ8.png',
                                    width: 40*fem,
                                    height: 40*fem,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse39q4t (132:369)
                    left: 159*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-39-bg.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse38wNp (132:368)
                    left: 347*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-38-bg.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse374CY (132:367)
                    left: 288*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-37-bg.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse40WqE (132:373)
                    left: 223*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-40-bg.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}