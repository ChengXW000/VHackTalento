import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // companyapply124At (94:2130)
        width: double.infinity,
        height: 654*fem,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.only (
            topLeft: Radius.circular(8*fem),
            topRight: Radius.circular(8*fem),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // backgroundZtL (94:2131)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 571*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // chatSSL (94:2133)
              left: 192*fem,
              top: 12*fem,
              child: Align(
                child: SizedBox(
                  width: 28*fem,
                  height: 16*fem,
                  child: Text(
                    'Chat',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame3KW8 (94:2134)
              left: 385.25*fem,
              top: 15.25*fem,
              child: Align(
                child: SizedBox(
                  width: 9.5*fem,
                  height: 9.5*fem,
                  child: Image.asset(
                    'assets/page-1/images/frame-3-xJU.png',
                    width: 9.5*fem,
                    height: 9.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundeHW (94:2136)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 654*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group29WqW (94:2137)
              left: 129*fem,
              top: 12*fem,
              child: Container(
                width: 265.75*fem,
                height: 16*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // internwebdevelopmentopc (94:2139)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 102.25*fem, 0*fem),
                      child: Text(
                        'Intern - Web Development',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xff161722),
                        ),
                      ),
                    ),
                    Container(
                      // frame7Knx (94:2140)
                      width: 9.5*fem,
                      height: 9.5*fem,
                      child: Image.asset(
                        'assets/page-1/images/frame-7-J1v.png',
                        width: 9.5*fem,
                        height: 9.5*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // buttonteal4kY (94:2142)
              left: 165*fem,
              top: 591*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 85*fem,
                  height: 40*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(6*fem),
                    gradient: LinearGradient (
                      begin: Alignment(-1, -1),
                      end: Alignment(1, 1),
                      colors: <Color>[Color(0xff0dae87), Color(0xff1350c6)],
                      stops: <double>[0, 1],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x26000000),
                        offset: Offset(0*fem, 1*fem),
                        blurRadius: 1.5*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Apply',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.25*ffem/fem,
                        letterSpacing: -0.16*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundc9n (94:2143)
              left: 0*fem,
              top: 637*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 17*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xffd0d1d3),
                          offset: Offset(0*fem, -0.3300000131*fem),
                          blurRadius: 0*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group30VzG (94:2144)
              left: 16*fem,
              top: 57*fem,
              child: Container(
                width: 384*fem,
                height: 84*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15pWk (94:2145)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 81*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10uYC (94:2146)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group184fz (94:2147)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5dUC (94:2148)
                              child: SizedBox(
                                width: double.infinity,
                                height: 81*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // candidatemustbecurrentlyunderg (94:2150)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 329*fem,
                          height: 26*fem,
                          child: Text(
                            'Candidate must be currently undergoing a course in IT / Computer Science / Computer engineering.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // qualificationq4U (94:2152)
                      left: 14*fem,
                      top: 11*fem,
                      child: Align(
                        child: SizedBox(
                          width: 116*fem,
                          height: 24*fem,
                          child: Text(
                            'Qualification',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group32ua8 (94:2162)
              left: 16*fem,
              top: 251*fem,
              child: Container(
                width: 384*fem,
                height: 135*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group152Pr (94:2163)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 129*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10xHW (94:2164)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18X5i (94:2165)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5tBA (94:2166)
                              child: SizedBox(
                                width: double.infinity,
                                height: 129*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // candidatefamiliarwithstoredpro (94:2168)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 337*fem,
                          height: 65*fem,
                          child: Text(
                            'Candidate familiar with stored procedures, SQL, .NET development (Winforms & Web Development).\nCandidates that are familiar with HTML, Javascript etc.\nCandidates experience in OO Programming, 3-tier development and SQL is preferred.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // lookingforzNc (94:2170)
                      left: 14*fem,
                      top: 12*fem,
                      child: Align(
                        child: SizedBox(
                          width: 104*fem,
                          height: 24*fem,
                          child: Text(
                            'Looking for',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group33Gqv (94:2171)
              left: 16*fem,
              top: 390*fem,
              child: Container(
                width: 384*fem,
                height: 93*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15p6k (94:2172)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 80*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10Xmr (94:2173)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18VCt (94:2174)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5qGk (94:2175)
                              child: SizedBox(
                                width: double.infinity,
                                height: 80*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // candidateswhoprefertotravelmay (94:2177)
                      left: 14*fem,
                      top: 48*fem,
                      child: Align(
                        child: SizedBox(
                          width: 341*fem,
                          height: 26*fem,
                          child: Text(
                            'Candidates who prefer to travel may be given opportunities to travel; Candidates who prefer not to travel may work locally.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // benefitsBzp (94:2179)
                      left: 14*fem,
                      top: 17*fem,
                      child: Align(
                        child: SizedBox(
                          width: 76*fem,
                          height: 24*fem,
                          child: Text(
                            'Benefits',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group34JpY (94:2241)
              left: 16*fem,
              top: 485*fem,
              child: Container(
                width: 384*fem,
                height: 103*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15ReG (94:2242)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 96*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10iNU (94:2243)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18GPz (94:2244)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5Ebi (94:2245)
                              child: SizedBox(
                                width: double.infinity,
                                height: 96*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // candidatesabletoworkwellinatea (94:2247)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 307*fem,
                          height: 39*fem,
                          child: Text(
                            'Candidates able to work well in a team, as well as individually.\nCandidates passionate about technology and enjoy software development, riding on the latest technologies.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // preferp48 (94:2249)
                      left: 14*fem,
                      top: 10*fem,
                      child: Align(
                        child: SizedBox(
                          width: 57*fem,
                          height: 24*fem,
                          child: Text(
                            'Prefer',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group31tZn (94:2232)
              left: 16*fem,
              top: 154*fem,
              child: Container(
                width: 384*fem,
                height: 92*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15dXN (94:2233)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 84*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10MiG (94:2234)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group187xL (94:2235)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle56A4 (94:2236)
                              child: SizedBox(
                                width: double.infinity,
                                height: 84*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // involvedindesigncodingtestinga (94:2238)
                      left: 14*fem,
                      top: 34*fem,
                      child: Align(
                        child: SizedBox(
                          width: 345*fem,
                          height: 39*fem,
                          child: Text(
                            'Involved in design, coding, testing and deployment of modern information systems. Candidates will have the opportunity to work on state of the art systems running  different programming platform.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // jobscopebm2 (94:2240)
                      left: 14*fem,
                      top: 5*fem,
                      child: Align(
                        child: SizedBox(
                          width: 96*fem,
                          height: 24*fem,
                          child: Text(
                            'Job Scope',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}