import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // candidescription1j4t (69:1548)
        width: double.infinity,
        height: 761*fem,
        child: Stack(
          children: [
            Positioned(
              // rectangle58qtc (152:309)
              left: 37*fem,
              top: 503*fem,
              child: Align(
                child: SizedBox(
                  width: 104*fem,
                  height: 68*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffd9d9d9),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundZJp (69:1549)
              left: 0*fem,
              top: 228*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 533*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundroi (88:1771)
              left: 0*fem,
              top: 744*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 17*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xffd0d1d3),
                          offset: Offset(0*fem, -0.3300000131*fem),
                          blurRadius: 0*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // profileimgAZW (122:2807)
              left: 157*fem,
              top: 178*fem,
              child: Align(
                child: SizedBox(
                  width: 100*fem,
                  height: 100*fem,
                  child: Image.asset(
                    'assets/page-1/images/profile-img-tpp.png',
                    width: 100*fem,
                    height: 100*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // educationboxtEc (88:1772)
              left: 13*fem,
              top: 347*fem,
              child: Container(
                width: 384*fem,
                height: 118*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group10PSG (88:1773)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Container(
                    // group18iUY (88:1774)
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Center(
                      // rectangle5r4x (88:1775)
                      child: SizedBox(
                        width: double.infinity,
                        height: 118*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfff8f9fc),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // experienceboxMXW (88:1776)
              left: 14*fem,
              top: 471*fem,
              child: Container(
                width: 384*fem,
                height: 110*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group10sVr (88:1777)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Container(
                    // group18ELQ (88:1778)
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Center(
                      // rectangle5CHE (88:1779)
                      child: SizedBox(
                        width: double.infinity,
                        height: 110*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfff8f9fc),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // skillsboxWYp (88:1780)
              left: 14*fem,
              top: 587*fem,
              child: Container(
                width: 384*fem,
                height: 99*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group1021N (88:1781)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Container(
                    // group18BQ4 (88:1782)
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Center(
                      // rectangle5XD2 (88:1783)
                      child: SizedBox(
                        width: double.infinity,
                        height: 99*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfff8f9fc),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // upmlogo4ik (88:1784)
              left: 0*fem,
              top: 329*fem,
              child: Container(
                width: 238*fem,
                height: 241*fem,
                decoration: BoxDecoration (
                  image: DecorationImage (
                    fit: BoxFit.cover,
                    image: AssetImage (
                      'assets/page-1/images/upm-logo-bg-QkG.png',
                    ),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // image2A16 (88:1785)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                      width: 238*fem,
                      height: 167*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-2-eEC.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // rectangle595tk (152:310)
                      width: 60*fem,
                      height: 60*fem,
                      child: Image.asset(
                        'assets/page-1/images/rectangle-59-zaC.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // educationdescriptionqN8 (88:1786)
              left: 187*fem,
              top: 387*fem,
              child: Container(
                width: 199*fem,
                height: 64*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // coursecomputerandcommunication (88:1787)
                      constraints: BoxConstraints (
                        maxWidth: 199*fem,
                      ),
                      child: Text(
                        'Course: Computer and Communication  \n               System Engineering',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 11*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xff86878b),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // statusongoing1styeardYt (88:1788)
                      'Status : Ongoing (1st Year)    ',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // yog2026XuA (88:1789)
                      'YOG     : 2026',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // experiencediscriptionsy2 (88:1790)
              left: 178*fem,
              top: 510*fem,
              child: Container(
                width: 146*fem,
                height: 51*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      // companyvhacknaC (88:1791)
                      'Company: Vhack',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // roleparticipantWFJ (88:1792)
                      'Role         : Participant     ',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // periodfeb2023presentcp8 (88:1793)
                      'Period     : Feb2023 - Present',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // education9p4 (88:1794)
              left: 29*fem,
              top: 352*fem,
              child: Align(
                child: SizedBox(
                  width: 90*fem,
                  height: 24*fem,
                  child: Text(
                    'Education',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // experienceekp (88:1795)
              left: 28*fem,
              top: 477*fem,
              child: Align(
                child: SizedBox(
                  width: 101*fem,
                  height: 24*fem,
                  child: Text(
                    'Experience',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // skillsk3A (88:1796)
              left: 29*fem,
              top: 594*fem,
              child: Align(
                child: SizedBox(
                  width: 51*fem,
                  height: 24*fem,
                  child: Text(
                    'Skills',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // figmaimgRQC (88:1797)
              left: 68*fem,
              top: 627*fem,
              child: Align(
                child: SizedBox(
                  width: 29.97*fem,
                  height: 44.95*fem,
                  child: Image.asset(
                    'assets/page-1/images/figma-img.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // cimgwtL (88:1799)
              left: 298*fem,
              top: 627*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 44.95*fem,
                  child: Image.asset(
                    'assets/page-1/images/c-img.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // asmimgUdN (88:1800)
              left: 147*fem,
              top: 627*fem,
              child: Align(
                child: SizedBox(
                  width: 44.95*fem,
                  height: 44.95*fem,
                  child: Image.asset(
                    'assets/page-1/images/asm-img.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // pythonimgawJ (88:1801)
              left: 225*fem,
              top: 627*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 44.95*fem,
                  child: Image.asset(
                    'assets/page-1/images/python-img-35z.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // buttonteal7gL (88:1802)
              left: 162*fem,
              top: 695*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 91*fem,
                  height: 40*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(6*fem),
                    gradient: LinearGradient (
                      begin: Alignment(-1, -1),
                      end: Alignment(1, 1),
                      colors: <Color>[Color(0xff0dae87), Color(0xff1350c6)],
                      stops: <double>[0, 1],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x26000000),
                        offset: Offset(0*fem, 1*fem),
                        blurRadius: 1.5*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'OFFER',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.25*ffem/fem,
                        letterSpacing: -0.16*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // tabupperhPe (69:1550)
              left: 388.25*fem,
              top: 246.25*fem,
              child: Align(
                child: SizedBox(
                  width: 9.5*fem,
                  height: 9.5*fem,
                  child: Image.asset(
                    'assets/page-1/images/tab-upper-TRS.png',
                    width: 9.5*fem,
                    height: 9.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // internengineeringeeengineering (69:1568)
              left: 80*fem,
              top: 319*fem,
              child: Align(
                child: SizedBox(
                  width: 253*fem,
                  height: 20*fem,
                  child: Text(
                    '#intern #engineering(EE) #engineering(SE)',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.5*ffem/fem,
                      color: Color(0x99000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // jayesSY (69:1569)
              left: 181*fem,
              top: 290*fem,
              child: Align(
                child: SizedBox(
                  width: 52*fem,
                  height: 29*fem,
                  child: Text(
                    'Jaye',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}