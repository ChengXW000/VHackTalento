import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // privacyandsettings3KE (6:65)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 90*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // topbarLZE (6:143)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20.33*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12.67*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0xffd0d1d3),
                    offset: Offset(0*fem, 0.3300000131*fem),
                    blurRadius: 0*fem,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // barsstatusbariphonexoBv (6:150)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                    padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                    width: double.infinity,
                    height: 44*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timestyleVaY (6:169)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                          padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                          height: double.infinity,
                          child: Text(
                            '9:41',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'SF Pro Text',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.2575*ffem/fem,
                              letterSpacing: -0.3000000119*fem,
                              color: Color(0xff171717),
                            ),
                          ),
                        ),
                        Container(
                          // mobilesignalMck (6:164)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                          width: 18.77*fem,
                          height: 10.67*fem,
                          child: Image.asset(
                            'assets/page-1/images/mobile-signal-haQ.png',
                            width: 18.77*fem,
                            height: 10.67*fem,
                          ),
                        ),
                        Container(
                          // wififdS (6:160)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                          width: 16.86*fem,
                          height: 10.97*fem,
                          child: Image.asset(
                            'assets/page-1/images/wifi.png',
                            width: 16.86*fem,
                            height: 10.97*fem,
                          ),
                        ),
                        Container(
                          // batteryLja (6:152)
                          margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                          width: 24.5*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/battery.png',
                            width: 24.5*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupv3n83dz (KwdvHBqQYZHHkAyHvcv3N8)
                    margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 130*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // leftarrowiconmZz (6:145)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 102.79*fem, 0*fem),
                          width: 10.21*fem,
                          height: 18*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-JzL.png',
                            width: 10.21*fem,
                            height: 18*fem,
                          ),
                        ),
                        Text(
                          // privacyandsettings66U (6:146)
                          'Privacy and settings',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 17*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff161722),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // accountpYG (6:110)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19.34*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18.66*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // account8Yx (6:112)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 4*fem),
                    child: Text(
                      'ACCOUNT',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 13*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ),
                  Container(
                    // rowRnx (6:113)
                    padding: EdgeInsets.fromLTRB(19*fem, 17*fem, 19.46*fem, 17*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // accountstrokeiconLQ8 (6:117)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                          width: 14*fem,
                          height: 16*fem,
                          child: Image.asset(
                            'assets/page-1/images/account-stroke-icon.png',
                            width: 14*fem,
                            height: 16*fem,
                          ),
                        ),
                        Container(
                          // managemyaccount4L8 (6:115)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 204.75*fem, 0*fem),
                          child: Text(
                            'Manage my account',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowiconmEY (6:116)
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-XAY.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // rowVwE (6:118)
                    padding: EdgeInsets.fromLTRB(18.75*fem, 17*fem, 19.46*fem, 17*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // lockstrokeiconoh2 (6:122)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 14.75*fem, 0*fem),
                          width: 14.5*fem,
                          height: 17.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/lock-stroke-icon.png',
                            width: 14.5*fem,
                            height: 17.5*fem,
                          ),
                        ),
                        Container(
                          // privacyandsafetyvme (6:120)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 218.75*fem, 0*fem),
                          child: Text(
                            'Privacy and safety',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowicondg4 (6:121)
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-TcL.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // rowyV2 (6:123)
                    padding: EdgeInsets.fromLTRB(16.75*fem, 17*fem, 19.46*fem, 17*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // camerastrokeiconhR2 (6:127)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                          width: 19.25*fem,
                          height: 14.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/camera-stroke-icon.png',
                            width: 19.25*fem,
                            height: 14.5*fem,
                          ),
                        ),
                        Container(
                          // contentpreferencescXz (6:125)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 204.75*fem, 0*fem),
                          child: Text(
                            'Content preferences',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowiconw4U (6:126)
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // row4Pz (6:133)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18*fem),
                    padding: EdgeInsets.fromLTRB(16.92*fem, 17*fem, 19.46*fem, 17*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // shareiconNQg (6:137)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.49*fem, 0*fem),
                          width: 17.59*fem,
                          height: 15.58*fem,
                          child: Image.asset(
                            'assets/page-1/images/share-icon.png',
                            width: 17.59*fem,
                            height: 15.58*fem,
                          ),
                        ),
                        Container(
                          // shareprofilessE (6:135)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 256.75*fem, 0*fem),
                          child: Text(
                            'Share profile',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowiconC8p (6:136)
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-9hr.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // general7Wg (6:82)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19.34*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.66*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // generalS3A (6:84)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 4*fem),
                    child: Text(
                      'GENERAL',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 13*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ),
                  Container(
                    // rowZ7n (6:85)
                    padding: EdgeInsets.fromLTRB(18.5*fem, 17*fem, 19.46*fem, 17*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // belliconseG (6:89)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.5*fem, 0*fem),
                          width: 16*fem,
                          height: 16.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/bell-icon.png',
                            width: 16*fem,
                            height: 16.5*fem,
                          ),
                        ),
                        Container(
                          // pushnotifications1Eg (6:87)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 219.75*fem, 0*fem),
                          child: Text(
                            'Push notifications',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowicon7Hi (6:88)
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-79i.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // row3hA (6:90)
                    padding: EdgeInsets.fromLTRB(17.75*fem, 16.75*fem, 19.46*fem, 16.75*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // bookstrokeiconAWt (6:94)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.75*fem, 0*fem),
                          width: 16.5*fem,
                          height: 18.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/book-stroke-icon.png',
                            width: 16.5*fem,
                            height: 18.5*fem,
                          ),
                        ),
                        Container(
                          // languageVZA (6:92)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 274.75*fem, 0*fem),
                          child: Text(
                            'Language',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowicon1nQ (6:93)
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-dPN.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // rowXkk (6:95)
                    padding: EdgeInsets.fromLTRB(17.77*fem, 17*fem, 19.46*fem, 17*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // umbrellastrokeiconfc4 (6:99)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.77*fem, 0.5*fem),
                          width: 16.46*fem,
                          height: 17*fem,
                          child: Image.asset(
                            'assets/page-1/images/umbrella-stroke-icon.png',
                            width: 16.46*fem,
                            height: 17*fem,
                          ),
                        ),
                        Container(
                          // digitalwellbeingbEp (6:97)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 229.75*fem, 0*fem),
                          child: Text(
                            'Digital Wellbeing',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowiconv2C (6:98)
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-vNC.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // rowqQ4 (6:100)
                    padding: EdgeInsets.fromLTRB(17*fem, 17*fem, 19.46*fem, 17*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // accebilitystrokeiconvRW (6:104)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                          width: 18*fem,
                          height: 18*fem,
                          child: Image.asset(
                            'assets/page-1/images/accebility-stroke-icon.png',
                            width: 18*fem,
                            height: 18*fem,
                          ),
                        ),
                        Container(
                          // accessibilityrKA (6:102)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 256.75*fem, 0*fem),
                          child: Text(
                            'Accessibility',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowiconnCp (6:103)
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-kVE.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // row81n (6:105)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                    padding: EdgeInsets.fromLTRB(18.25*fem, 16.88*fem, 19.46*fem, 16.75*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // dropstrokeiconqB6 (6:109)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 14.25*fem, 0*fem),
                          width: 15.5*fem,
                          height: 18.37*fem,
                          child: Image.asset(
                            'assets/page-1/images/drop-stroke-icon.png',
                            width: 15.5*fem,
                            height: 18.37*fem,
                          ),
                        ),
                        Container(
                          // datasaverLde (6:107)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 268.75*fem, 0.13*fem),
                          child: Text(
                            'Data Saver',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowicon4Jk (6:108)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.13*fem),
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-5Sg.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // supportnEk (6:67)
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // supportjfn (6:68)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 4*fem),
                    child: Text(
                      'SUPPORT',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 13*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ),
                  Container(
                    // row3Ra (6:69)
                    padding: EdgeInsets.fromLTRB(18.75*fem, 17*fem, 19.46*fem, 17*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // penstrokeiconNCx (6:73)
                          margin: EdgeInsets.fromLTRB(0*fem, 0.69*fem, 14.25*fem, 0*fem),
                          width: 15*fem,
                          height: 16.81*fem,
                          child: Image.asset(
                            'assets/page-1/images/pen-stroke-icon.png',
                            width: 15*fem,
                            height: 16.81*fem,
                          ),
                        ),
                        Container(
                          // reportaproblemFXe (6:71)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 224.75*fem, 0*fem),
                          child: Text(
                            'Report a problem',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowiconAPi (6:72)
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-2dv.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // rowheY (6:74)
                    padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 19.46*fem, 17*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // questionstrokeicon2Rv (6:78)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 14*fem, 0*fem),
                          width: 16*fem,
                          height: 16*fem,
                          child: Image.asset(
                            'assets/page-1/images/question-stroke-icon.png',
                            width: 16*fem,
                            height: 16*fem,
                          ),
                        ),
                        Container(
                          // helpcenter9WY (6:76)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 261.75*fem, 0*fem),
                          child: Text(
                            'Help Center',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                        Container(
                          // leftarrowiconTXE (6:77)
                          width: 5.79*fem,
                          height: 10.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/left-arrow-icon-7k4.png',
                            width: 5.79*fem,
                            height: 10.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}