import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // companysavedprofile1ZKv (94:2558)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupihrjg9e (Kwe143t5otGPxV5nZFihRJ)
              width: double.infinity,
              height: 384*fem,
              child: Stack(
                children: [
                  Positioned(
                    // topbarCdn (94:2560)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 414*fem,
                      height: 87.67*fem,
                      child: Center(
                        // background9J8 (94:2561)
                        child: SizedBox(
                          width: double.infinity,
                          height: 87.67*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0xffd0d1d3),
                                  offset: Offset(0*fem, 0.3300000131*fem),
                                  blurRadius: 0*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // maskgroupsE8 (94:2562)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 414*fem,
                      height: 249*fem,
                    ),
                  ),
                  Positioned(
                    // barsstatusbariphonexchW (94:2565)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                      width: 414*fem,
                      height: 44*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timestyleVFW (94:2584)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                            height: double.infinity,
                            child: Text(
                              '9:41',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'SF Pro Text',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2575*ffem/fem,
                                letterSpacing: -0.3000000119*fem,
                                color: Color(0xff171717),
                              ),
                            ),
                          ),
                          Container(
                            // mobilesignalkx8 (94:2579)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                            width: 18.77*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/mobile-signal-Fng.png',
                              width: 18.77*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // wifi5Uc (94:2575)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                            width: 16.86*fem,
                            height: 10.97*fem,
                            child: Image.asset(
                              'assets/page-1/images/wifi-LEt.png',
                              width: 16.86*fem,
                              height: 10.97*fem,
                            ),
                          ),
                          Container(
                            // batteryQWt (94:2567)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                            width: 24.5*fem,
                            height: 10.5*fem,
                            child: Image.asset(
                              'assets/page-1/images/battery-ATJ.png',
                              width: 24.5*fem,
                              height: 10.5*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group8Goz (94:2586)
                    left: 18*fem,
                    top: 48*fem,
                    child: Align(
                      child: SizedBox(
                        width: 22*fem,
                        height: 16.04*fem,
                        child: Image.asset(
                          'assets/page-1/images/group-8.png',
                          width: 22*fem,
                          height: 16.04*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle5AuN (94:2588)
                    left: 11*fem,
                    top: 118*fem,
                    child: Align(
                      child: SizedBox(
                        width: 393*fem,
                        height: 265*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(33*fem),
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x2d30007e),
                                offset: Offset(0*fem, 10*fem),
                                blurRadius: 25*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // digitalpenangisagovernmentlink (94:2589)
                    left: 46.5*fem,
                    top: 202*fem,
                    child: Align(
                      child: SizedBox(
                        width: 325*fem,
                        height: 46*fem,
                        child: Text(
                          'Digital Penang is a government-linked company owned by the State of Penang to accelerate efforts to capture opportunities in the digital economy',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w300,
                            height: 1.2625480036*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // digitalpenangJPJ (94:2590)
                    left: 137*fem,
                    top: 170*fem,
                    child: Align(
                      child: SizedBox(
                        width: 131*fem,
                        height: 24*fem,
                        child: Text(
                          'Digital Penang',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle6zmv (94:2591)
                    left: 36*fem,
                    top: 319*fem,
                    child: Align(
                      child: SizedBox(
                        width: 168*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0xff084fff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle76KA (94:2592)
                    left: 224*fem,
                    top: 319*fem,
                    child: Align(
                      child: SizedBox(
                        width: 168*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0xff084fff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // websiteC7J (94:2593)
                    left: 81*fem,
                    top: 330*fem,
                    child: Align(
                      child: SizedBox(
                        width: 79*fem,
                        height: 24*fem,
                        child: Text(
                          'Website',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.8*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // follow5B6 (94:2594)
                    left: 276*fem,
                    top: 330*fem,
                    child: Align(
                      child: SizedBox(
                        width: 64*fem,
                        height: 24*fem,
                        child: Text(
                          'Follow',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.8*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame189we (94:2608)
                    left: 148*fem,
                    top: 259*fem,
                    child: Container(
                      width: 119*fem,
                      height: 45*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group14ff6 (94:2610)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // image15NpQ (94:2612)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-15-VAg.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // group17vb2 (94:2613)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // image16T5A (94:2615)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-16-gNt.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse3m5r (94:2625)
                    left: 160*fem,
                    top: 63*fem,
                    child: Align(
                      child: SizedBox(
                        width: 100*fem,
                        height: 100*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(50*fem),
                            border: Border.all(color: Color(0xff060606)),
                            image: DecorationImage (
                              fit: BoxFit.contain,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-3-bg-p3J.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup9butevL (Kwe1ZnXY7hu6msYm8W9BUt)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
              width: double.infinity,
              height: 502*fem,
              child: Stack(
                children: [
                  Positioned(
                    // ellipse3NbS (94:2595)
                    left: 151*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(22.5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/ellipse-3-bg.png',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse4Dc4 (94:2596)
                    left: 220*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(22.5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/ellipse-4-bg.png',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse56fr (94:2597)
                    left: 285*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            border: Border.all(color: Color(0xff000000)),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-5-bg.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse6aqv (94:2598)
                    left: 351*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            border: Border.all(color: Color(0xff000000)),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-6-bg.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group1JX2 (94:2599)
                    left: 150*fem,
                    top: 124*fem,
                    child: Container(
                      width: 250*fem,
                      height: 377*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupqqssEfa (Kwe1qhEhKMQV6j6aTRqQsS)
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle6zek (94:2600)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.62*fem, 0*fem),
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-6.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // rectangle7iKr (94:2603)
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-7.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 11.58*fem,
                          ),
                          Container(
                            // autogroupezvsCF2 (Kwe1vXRymy65WfvVzzEZVS)
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle8wyJ (94:2601)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.62*fem, 0*fem),
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-8.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // rectangle9H1a (94:2604)
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-9.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 11.58*fem,
                          ),
                          Container(
                            // autogroup3ideDR2 (Kwe1zXKKPzcqzVJAK73idE)
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle10yQC (94:2602)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.62*fem, 0*fem),
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-10.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // rectangle11hqz (94:2605)
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-11.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // peoplealsofollowedE5E (94:2606)
                    left: 150*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 174*fem,
                        height: 22*fem,
                        child: Text(
                          'People Also Followed',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // gallery7ep (94:2607)
                    left: 147*fem,
                    top: 96*fem,
                    child: Align(
                      child: SizedBox(
                        width: 57*fem,
                        height: 22*fem,
                        child: Text(
                          'Gallery',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // backgroundQtp (94:2616)
                    left: 0*fem,
                    top: 470*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 32*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xffd0d1d3),
                                offset: Offset(0*fem, -0.3300000131*fem),
                                blurRadius: 0*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group27KF6 (94:2617)
                    left: 11*fem,
                    top: 6*fem,
                    child: Container(
                      width: 129*fem,
                      height: 147*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(21*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group10nuN (94:2618)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(21*fem),
                        ),
                        child: Container(
                          // group18MBn (94:2619)
                          padding: EdgeInsets.fromLTRB(28*fem, 28*fem, 28*fem, 29*fem),
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff8f9fc),
                            borderRadius: BorderRadius.circular(21*fem),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // ksavesSj2 (94:2622)
                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 4.67*fem),
                                constraints: BoxConstraints (
                                  maxWidth: 35*fem,
                                ),
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.0918749173*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: '58K\n',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 20*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.3102499008*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                      TextSpan(
                                        text: 'Saves',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 11*ffem,
                                          fontWeight: FontWeight.w300,
                                          height: 1.0918749896*ffem/fem,
                                          letterSpacing: 0.055*fem,
                                          color: Color(0xff959595),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                // line11JG (94:2621)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.33*fem),
                                width: double.infinity,
                                height: 1*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xb2979797),
                                ),
                              ),
                              Container(
                                // kfollowers7s6 (94:2623)
                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                constraints: BoxConstraints (
                                  maxWidth: 48*fem,
                                ),
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 18*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.171875*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: '20K\n',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 20*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.1725*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                      TextSpan(
                                        text: 'Followers',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 11*ffem,
                                          fontWeight: FontWeight.w300,
                                          height: 1.1725*ffem/fem,
                                          letterSpacing: 0.055*fem,
                                          color: Color(0xff959595),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group14bvg (94:2627)
                    left: 11*fem,
                    top: 183*fem,
                    child: Container(
                      width: 129*fem,
                      height: 164*fem,
                      decoration: BoxDecoration (
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x26000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 15*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group10vTA (94:2628)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(21*fem),
                        ),
                        child: Container(
                          // group18rrc (94:2629)
                          padding: EdgeInsets.fromLTRB(42*fem, 25*fem, 40*fem, 29*fem),
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff8f9fc),
                            borderRadius: BorderRadius.circular(21*fem),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group20aXi (94:2635)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 20*fem),
                                padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                                decoration: BoxDecoration (
                                  color: Color(0xffe8e5f2),
                                  borderRadius: BorderRadius.circular(12*fem),
                                ),
                                child: Center(
                                  // image19Ftk (94:2637)
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-19.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group18ntg (94:2631)
                                margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                                decoration: BoxDecoration (
                                  color: Color(0xffe8e5f2),
                                  borderRadius: BorderRadius.circular(12*fem),
                                ),
                                child: Center(
                                  // image16WZn (94:2633)
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-16-Qc8.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}