import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // companyapply13nGG (94:2181)
        width: double.infinity,
        height: 654*fem,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.only (
            topLeft: Radius.circular(8*fem),
            topRight: Radius.circular(8*fem),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // background4ja (94:2182)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 571*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // chatwoN (94:2184)
              left: 192*fem,
              top: 12*fem,
              child: Align(
                child: SizedBox(
                  width: 28*fem,
                  height: 16*fem,
                  child: Text(
                    'Chat',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame3SEL (94:2185)
              left: 385.25*fem,
              top: 15.25*fem,
              child: Align(
                child: SizedBox(
                  width: 9.5*fem,
                  height: 9.5*fem,
                  child: Image.asset(
                    'assets/page-1/images/frame-3-BFE.png',
                    width: 9.5*fem,
                    height: 9.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // background8cx (94:2187)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 654*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group29C72 (94:2188)
              left: 146*fem,
              top: 12*fem,
              child: Container(
                width: 248.75*fem,
                height: 16*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // fullstackdevelopervHv (94:2190)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 118.25*fem, 0*fem),
                      child: Text(
                        'Full Stack Developer',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xff161722),
                        ),
                      ),
                    ),
                    Container(
                      // frame7SGG (94:2191)
                      width: 9.5*fem,
                      height: 9.5*fem,
                      child: Image.asset(
                        'assets/page-1/images/frame-7-Wq6.png',
                        width: 9.5*fem,
                        height: 9.5*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // buttontealAi4 (94:2193)
              left: 165*fem,
              top: 591*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 85*fem,
                  height: 40*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(6*fem),
                    gradient: LinearGradient (
                      begin: Alignment(-1, -1),
                      end: Alignment(1, 1),
                      colors: <Color>[Color(0xff0dae87), Color(0xff1350c6)],
                      stops: <double>[0, 1],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x26000000),
                        offset: Offset(0*fem, 1*fem),
                        blurRadius: 1.5*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Apply',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.25*ffem/fem,
                        letterSpacing: -0.16*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundXh2 (94:2194)
              left: 0*fem,
              top: 637*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 17*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xffd0d1d3),
                          offset: Offset(0*fem, -0.3300000131*fem),
                          blurRadius: 0*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group30dVA (94:2195)
              left: 16*fem,
              top: 57*fem,
              child: Container(
                width: 384*fem,
                height: 97*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15wVr (94:2196)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 89*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10DTN (94:2197)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18a32 (94:2198)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5jgc (94:2199)
                              child: SizedBox(
                                width: double.infinity,
                                height: 89*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // advancediplomabachelorsdegreep (94:2201)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 342*fem,
                          height: 39*fem,
                          child: Text(
                            'Advance Diploma, Bachelor\'s Degree, Professional Degree, Master\'s Degree in IT/ Computer Science/ Computer engineering/ Information System or any IT related fields.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // qualificationtT2 (94:2203)
                      left: 14*fem,
                      top: 11*fem,
                      child: Align(
                        child: SizedBox(
                          width: 116*fem,
                          height: 24*fem,
                          child: Text(
                            'Qualification',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group31AvL (94:2204)
              left: 16*fem,
              top: 164*fem,
              child: Container(
                width: 384*fem,
                height: 84*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15JWk (94:2205)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 81*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10D7v (94:2206)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18aDN (94:2207)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle591a (94:2208)
                              child: SizedBox(
                                width: double.infinity,
                                height: 81*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // designandimplementresponsivewe (94:2210)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 355*fem,
                          height: 26*fem,
                          child: Text(
                            'Design and implement responsive web & mobile applications from front to back using open source frameworks like MEAN, Ionic and Swagger.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // jobscopeX28 (94:2212)
                      left: 14*fem,
                      top: 11*fem,
                      child: Align(
                        child: SizedBox(
                          width: 96*fem,
                          height: 24*fem,
                          child: Text(
                            'Job Scope',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group32pG8 (94:2213)
              left: 16*fem,
              top: 261*fem,
              child: Container(
                width: 384*fem,
                height: 97*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15Yhv (94:2214)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 91*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10E4x (94:2215)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18wzx (94:2216)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5K6Q (94:2217)
                              child: SizedBox(
                                width: double.infinity,
                                height: 91*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // candidatesprovenhandsonexperie (94:2219)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 354*fem,
                          height: 39*fem,
                          child: Text(
                            'Candidates proven hands-on experience with Javascript (preferably popular frameworks like AngularJS, React, KnockoutJS etc.), HTML5 & CSS.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // lookingfor7HA (94:2221)
                      left: 14*fem,
                      top: 12*fem,
                      child: Align(
                        child: SizedBox(
                          width: 104*fem,
                          height: 24*fem,
                          child: Text(
                            'Looking for',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group34zrk (94:2261)
              left: 16*fem,
              top: 363*fem,
              child: Container(
                width: 384*fem,
                height: 199*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15Y7a (94:2262)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 195*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group101Wx (94:2263)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18YFz (94:2264)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5Vwv (94:2265)
                              child: SizedBox(
                                width: double.infinity,
                                height: 195*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // candidatesexperiencedeveloping (94:2267)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 355*fem,
                          height: 117*fem,
                          child: Text(
                            'Candidates experience developing mobile applications would be considered an advantage.\nExperience with NodeJS, Swagger, MongoDB, PostgreSQL and MS SQL Server would be considered an advantage.\nPreferably 2-3 years of working experience.\nCandidates who are able to start work immediately will have an added advantage.\nFresh graduates with enthusiasm for learning new skills and technologies are encouraged to apply.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // prefernJk (94:2269)
                      left: 14*fem,
                      top: 10*fem,
                      child: Align(
                        child: SizedBox(
                          width: 57*fem,
                          height: 24*fem,
                          child: Text(
                            'Prefer',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}