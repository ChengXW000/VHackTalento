import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 255.5;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // disc2i4G (6:1413)
        padding: EdgeInsets.fromLTRB(15.5*fem, 20*fem, 20*fem, 20*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff7b61ff)),
          borderRadius: BorderRadius.circular(5*fem),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextButton(
              // property1default1ZA (6:1414)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 49*fem,
                height: 49*fem,
                child: Container(
                  // frame11M7E (6:1415)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(24.5*fem),
                    gradient: SweepGradient (
                      center: Alignment(0, 0),
                      startAngle: 1.55,
                      endAngle: 7.83,
                      tileMode: TileMode.repeated,
                      colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                      stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                    ),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        // ellipse2QrC (6:1417)
                        left: 5.4182128906*fem,
                        top: 5.4183349609*fem,
                        child: Align(
                          child: SizedBox(
                            width: 38.16*fem,
                            height: 38.16*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-2-3L4.png',
                              width: 38.16*fem,
                              height: 38.16*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // ellipse3hKW (6:1418)
                        left: 5.4182128906*fem,
                        top: 5.4183959961*fem,
                        child: Align(
                          child: SizedBox(
                            width: 38.16*fem,
                            height: 38.16*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-3-fnY.png',
                              width: 38.16*fem,
                              height: 38.16*fem,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 8*fem,
            ),
            TextButton(
              // property1variant2wzY (6:1419)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 49*fem,
                height: 49*fem,
                child: Container(
                  // frame11tet (6:1420)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(24.5*fem),
                    gradient: SweepGradient (
                      center: Alignment(0, 0),
                      startAngle: 1.55,
                      endAngle: 7.83,
                      tileMode: TileMode.repeated,
                      colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                      stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                    ),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        // ellipse2ZW8 (6:1422)
                        left: 5.4182128906*fem,
                        top: 5.4183349609*fem,
                        child: Align(
                          child: SizedBox(
                            width: 38.16*fem,
                            height: 38.16*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-2-kHe.png',
                              width: 38.16*fem,
                              height: 38.16*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // ellipse33gC (6:1423)
                        left: 5.4182128906*fem,
                        top: 5.4183959961*fem,
                        child: Align(
                          child: SizedBox(
                            width: 38.16*fem,
                            height: 38.16*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-3-o5z.png',
                              width: 38.16*fem,
                              height: 38.16*fem,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 8*fem,
            ),
            TextButton(
              // property1variant3Ycx (6:1424)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 49*fem,
                height: 49*fem,
                child: Container(
                  // frame11HqS (6:1425)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(24.5*fem),
                    gradient: SweepGradient (
                      center: Alignment(0, 0),
                      startAngle: 1.55,
                      endAngle: 7.83,
                      tileMode: TileMode.repeated,
                      colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                      stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                    ),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        // ellipse2Nbz (6:1427)
                        left: 5.4184570312*fem,
                        top: 5.4183959961*fem,
                        child: Align(
                          child: SizedBox(
                            width: 38.16*fem,
                            height: 38.16*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-2-uGL.png',
                              width: 38.16*fem,
                              height: 38.16*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // ellipse3f5J (6:1428)
                        left: 5.4184570312*fem,
                        top: 5.4182739258*fem,
                        child: Align(
                          child: SizedBox(
                            width: 38.16*fem,
                            height: 38.16*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-3.png',
                              width: 38.16*fem,
                              height: 38.16*fem,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 8*fem,
            ),
            TextButton(
              // property1variant4Y96 (6:1429)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 49*fem,
                height: 49*fem,
                child: Container(
                  // frame11592 (6:1430)
                  width: 50.69*fem,
                  height: 50.69*fem,
                  decoration: BoxDecoration (
                    image: DecorationImage (
                      fit: BoxFit.cover,
                      image: AssetImage (
                        'assets/page-1/images/ellipse-1-dLL.png',
                      ),
                    ),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        // ellipse2Bxk (6:1432)
                        left: 6.2963867188*fem,
                        top: 6.2965087891*fem,
                        child: Align(
                          child: SizedBox(
                            width: 38.1*fem,
                            height: 38.1*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-2.png',
                              width: 38.1*fem,
                              height: 38.1*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // ellipse3HF6 (6:1433)
                        left: 6.2963867188*fem,
                        top: 6.2966308594*fem,
                        child: Align(
                          child: SizedBox(
                            width: 38.1*fem,
                            height: 38.1*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-3-YTz.png',
                              width: 38.1*fem,
                              height: 38.1*fem,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}