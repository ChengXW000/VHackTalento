import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // companyapply21X5J (94:2453)
        width: double.infinity,
        height: 654*fem,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.only (
            topLeft: Radius.circular(8*fem),
            topRight: Radius.circular(8*fem),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // background2Xr (94:2454)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 571*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // chat856 (94:2456)
              left: 192*fem,
              top: 12*fem,
              child: Align(
                child: SizedBox(
                  width: 28*fem,
                  height: 16*fem,
                  child: Text(
                    'Chat',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame3E88 (94:2457)
              left: 385.25*fem,
              top: 15.25*fem,
              child: Align(
                child: SizedBox(
                  width: 9.5*fem,
                  height: 9.5*fem,
                  child: Image.asset(
                    'assets/page-1/images/frame-3-zhN.png',
                    width: 9.5*fem,
                    height: 9.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundvme (94:2459)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 654*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group29rQQ (94:2460)
              left: 101*fem,
              top: 12*fem,
              child: Container(
                width: 293.75*fem,
                height: 16*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // freshgraduatesoftwareengineerx (94:2462)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 73.25*fem, 0*fem),
                      child: Text(
                        'Fresh Graduate - Software Engineer',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xff161722),
                        ),
                      ),
                    ),
                    Container(
                      // frame7FSY (94:2463)
                      width: 9.5*fem,
                      height: 9.5*fem,
                      child: Image.asset(
                        'assets/page-1/images/frame-7-E3r.png',
                        width: 9.5*fem,
                        height: 9.5*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // buttontealNXA (94:2465)
              left: 165*fem,
              top: 591*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 85*fem,
                  height: 40*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(6*fem),
                    gradient: LinearGradient (
                      begin: Alignment(-1, -1),
                      end: Alignment(1, 1),
                      colors: <Color>[Color(0xff0dae87), Color(0xff1350c6)],
                      stops: <double>[0, 1],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x26000000),
                        offset: Offset(0*fem, 1*fem),
                        blurRadius: 1.5*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Apply',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.25*ffem/fem,
                        letterSpacing: -0.16*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundggG (94:2466)
              left: 0*fem,
              top: 637*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 17*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xffd0d1d3),
                          offset: Offset(0*fem, -0.3300000131*fem),
                          blurRadius: 0*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group30xtg (94:2467)
              left: 16*fem,
              top: 57*fem,
              child: Container(
                width: 384*fem,
                height: 84*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15R1a (94:2468)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 81*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10Kck (94:2469)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18suA (94:2470)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5FFW (94:2471)
                              child: SizedBox(
                                width: double.infinity,
                                height: 81*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // abachelorsdegreeininformationt (94:2473)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 343*fem,
                          height: 26*fem,
                          child: Text(
                            'A Bachelor’s Degree in Information Technology, Computer Science or equivalent education. (CGPA > 3.5)',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // qualificationphv (94:2475)
                      left: 14*fem,
                      top: 11*fem,
                      child: Align(
                        child: SizedBox(
                          width: 116*fem,
                          height: 24*fem,
                          child: Text(
                            'Qualification',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group31Jsz (94:2476)
              left: 16*fem,
              top: 154*fem,
              child: Container(
                width: 384*fem,
                height: 79*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15ctg (94:2477)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 70*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group107Ke (94:2478)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18sZi (94:2479)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5R5S (94:2480)
                              child: SizedBox(
                                width: double.infinity,
                                height: 70*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // carryoutthedeveloperroleinascr (94:2482)
                      left: 14*fem,
                      top: 34*fem,
                      child: Align(
                        child: SizedBox(
                          width: 355*fem,
                          height: 26*fem,
                          child: Text(
                            'Carry out the developer role in a Scrum Team and translate user stories into technical implementation.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // jobscopeCVW (94:2484)
                      left: 14*fem,
                      top: 5*fem,
                      child: Align(
                        child: SizedBox(
                          width: 96*fem,
                          height: 24*fem,
                          child: Text(
                            'Job Scope',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group32H1A (94:2485)
              left: 16*fem,
              top: 238*fem,
              child: Container(
                width: 384*fem,
                height: 174*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15cJL (94:2486)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 173*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10tWk (94:2487)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18SoA (94:2488)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5otc (94:2489)
                              child: SizedBox(
                                width: double.infinity,
                                height: 173*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // candidateswithgoodcommandofeng (94:2491)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 354*fem,
                          height: 91*fem,
                          child: Text(
                            'Candidates with good command of English (spoken and written) as well as communication / convincing skills\nCandidate’s ability and willingness to learn new things - Strong ability to pickup new technical topics quickly and apply them to assignments\nCandidates experience Conceptional and analytical skills with hands-on software development experience (e.g Java, APEX, C# or equivalent)',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // lookingforfJY (94:2493)
                      left: 14*fem,
                      top: 12*fem,
                      child: Align(
                        child: SizedBox(
                          width: 104*fem,
                          height: 24*fem,
                          child: Text(
                            'Looking for',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group33yKE (94:2494)
              left: 16*fem,
              top: 425*fem,
              child: Container(
                width: 384*fem,
                height: 123*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group154ba (94:2495)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 114*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10nnU (94:2496)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18Xzx (94:2497)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5WCg (94:2498)
                              child: SizedBox(
                                width: double.infinity,
                                height: 114*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // showuswhatyouaremadeofandwewil (94:2500)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 355*fem,
                          height: 65*fem,
                          child: Text(
                            'Show us what you are made of, and we will offer you opportunities to move around the business – to work abroad, experience different job functions and tackle different markets. It is a wonderful way to find the right match for your ambitions and achieve the exciting career you are after.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // benefitsJ24 (94:2502)
                      left: 14*fem,
                      top: 8*fem,
                      child: Align(
                        child: SizedBox(
                          width: 76*fem,
                          height: 24*fem,
                          child: Text(
                            'Benefits',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}