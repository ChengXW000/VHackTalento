import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 255.5;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // discKXN (6:1396)
        padding: EdgeInsets.fromLTRB(15.5*fem, 20*fem, 20*fem, 20*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff7b61ff)),
          borderRadius: BorderRadius.circular(5*fem),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextButton(
              // property1defaultVTn (6:1397)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 49*fem,
                height: 49*fem,
                child: Container(
                  // frame11zvL (6:1398)
                  padding: EdgeInsets.fromLTRB(5.42*fem, 5.42*fem, 5.42*fem, 5.42*fem),
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(24.5*fem),
                    gradient: SweepGradient (
                      center: Alignment(0, 0),
                      startAngle: 1.55,
                      endAngle: 7.83,
                      tileMode: TileMode.repeated,
                      colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                      stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                    ),
                  ),
                  child: Center(
                    // ellipse2zJ4 (6:1400)
                    child: SizedBox(
                      width: 38.16*fem,
                      height: 38.16*fem,
                      child: Image.asset(
                        'assets/page-1/images/ellipse-2-ud2.png',
                        width: 38.16*fem,
                        height: 38.16*fem,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 8*fem,
            ),
            TextButton(
              // property1variant2rDn (6:1401)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 49*fem,
                height: 49*fem,
                child: Container(
                  // frame11z56 (6:1402)
                  padding: EdgeInsets.fromLTRB(5.42*fem, 5.42*fem, 5.42*fem, 5.42*fem),
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(24.5*fem),
                    gradient: SweepGradient (
                      center: Alignment(0, 0),
                      startAngle: 1.55,
                      endAngle: 7.83,
                      tileMode: TileMode.repeated,
                      colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                      stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                    ),
                  ),
                  child: Center(
                    // ellipse2Ek8 (6:1404)
                    child: SizedBox(
                      width: 38.16*fem,
                      height: 38.16*fem,
                      child: Image.asset(
                        'assets/page-1/images/ellipse-2-NfJ.png',
                        width: 38.16*fem,
                        height: 38.16*fem,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 8*fem,
            ),
            TextButton(
              // property1variant3jB6 (6:1405)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 49*fem,
                height: 49*fem,
                child: Container(
                  // frame11qzp (6:1406)
                  padding: EdgeInsets.fromLTRB(5.42*fem, 5.42*fem, 5.42*fem, 5.42*fem),
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(24.5*fem),
                    gradient: SweepGradient (
                      center: Alignment(0, 0),
                      startAngle: 1.55,
                      endAngle: 7.83,
                      tileMode: TileMode.repeated,
                      colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                      stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                    ),
                  ),
                  child: Center(
                    // ellipse2h1S (6:1408)
                    child: SizedBox(
                      width: 38.16*fem,
                      height: 38.16*fem,
                      child: Image.asset(
                        'assets/page-1/images/ellipse-2-8Me.png',
                        width: 38.16*fem,
                        height: 38.16*fem,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 8*fem,
            ),
            TextButton(
              // property1variant4oaG (6:1409)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 49*fem,
                height: 49*fem,
                child: Container(
                  // frame11hvY (6:1410)
                  padding: EdgeInsets.fromLTRB(6.3*fem, 6.3*fem, 6.3*fem, 6.3*fem),
                  width: 50.69*fem,
                  height: 50.69*fem,
                  decoration: BoxDecoration (
                    image: DecorationImage (
                      fit: BoxFit.cover,
                      image: AssetImage (
                        'assets/page-1/images/ellipse-1.png',
                      ),
                    ),
                  ),
                  child: Center(
                    // ellipse2c1v (6:1412)
                    child: SizedBox(
                      width: 38.1*fem,
                      height: 38.1*fem,
                      child: Image.asset(
                        'assets/page-1/images/ellipse-2-B9J.png',
                        width: 38.1*fem,
                        height: 38.1*fem,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}