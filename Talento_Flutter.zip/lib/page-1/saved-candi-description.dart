import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // savedcandidescriptionZkC (94:2857)
        width: double.infinity,
        height: 583*fem,
        child: Stack(
          children: [
            Positioned(
              // backgroundVNx (94:2858)
              left: 0*fem,
              top: 50*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 533*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundzKi (94:2859)
              left: 0*fem,
              top: 566*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 17*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xffd0d1d3),
                          offset: Offset(0*fem, -0.3300000131*fem),
                          blurRadius: 0*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group17Ukg (94:2864)
              left: 14*fem,
              top: 172*fem,
              child: Container(
                width: 384*fem,
                height: 355*fem,
                decoration: BoxDecoration (
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group10baQ (94:2865)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Container(
                    // group18MZa (94:2866)
                    padding: EdgeInsets.fromLTRB(26*fem, 255*fem, 26*fem, 20*fem),
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xfff8f9fc),
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Align(
                      // image24oAg (108:3371)
                      alignment: Alignment.bottomLeft,
                      child: SizedBox(
                        width: 80*fem,
                        height: 80*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-24.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame17HrY (94:2878)
              left: 180*fem,
              top: 243*fem,
              child: Container(
                width: 128*fem,
                height: 51*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      // companynasayUU (94:2879)
                      'Company: NASA',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // roleastronautgdn (94:2880)
                      'Role         : Astronaut ',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // period2017presentbEx (94:2881)
                      'Period     : 2017 - Present',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // frame18LCY (108:3366)
              left: 180*fem,
              top: 339*fem,
              child: Container(
                width: 128*fem,
                height: 51*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      // companyusnavyrwa (108:3367)
                      'Company: US Navy',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // rolesealacg (108:3368)
                      'Role         : Seal ',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // period2002present7Mi (108:3369)
                      'Period     : 2002 - Present',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // frame19S96 (108:3372)
              left: 180*fem,
              top: 441*fem,
              child: Container(
                width: 173*fem,
                height: 64*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // companymassachusettsgeneralhos (108:3373)
                      constraints: BoxConstraints (
                        maxWidth: 173*fem,
                      ),
                      child: Text(
                        'Company: Massachusetts General \n                   Hospital',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 11*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xff86878b),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // rolemedicaldoctorSYQ (108:3374)
                      'Role         : Medical Doctor',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // period20162017Zsv (108:3375)
                      'Period     : 2016 - 2017',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // image23WHN (108:3365)
              left: 40*fem,
              top: 325*fem,
              child: Align(
                child: SizedBox(
                  width: 80*fem,
                  height: 80*fem,
                  child: Image.asset(
                    'assets/page-1/images/image-23.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // image22SB2 (108:3363)
              left: 30*fem,
              top: 225*fem,
              child: Align(
                child: SizedBox(
                  width: 100*fem,
                  height: 100*fem,
                  child: Image.asset(
                    'assets/page-1/images/image-22.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // experiencewda (94:2883)
              left: 29*fem,
              top: 180*fem,
              child: Align(
                child: SizedBox(
                  width: 101*fem,
                  height: 24*fem,
                  child: Text(
                    'Experience',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame5pxG (94:2890)
              left: 388.25*fem,
              top: 68.25*fem,
              child: Align(
                child: SizedBox(
                  width: 9.5*fem,
                  height: 9.5*fem,
                  child: Image.asset(
                    'assets/page-1/images/frame-5-aEk.png',
                    width: 9.5*fem,
                    height: 9.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse3x2t (94:2894)
              left: 157*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 100*fem,
                  height: 100*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(50*fem),
                      border: Border.all(color: Color(0xffffffff)),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-3-bg-LTr.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // mdusnavyastronautegQ (94:2895)
              left: 130*fem,
              top: 141*fem,
              child: Align(
                child: SizedBox(
                  width: 154*fem,
                  height: 20*fem,
                  child: Text(
                    '#MD #USNavy #Astronaut',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.5*ffem/fem,
                      color: Color(0x99000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // jonnykimw9i (94:2896)
              left: 159*fem,
              top: 112*fem,
              child: Align(
                child: SizedBox(
                  width: 96*fem,
                  height: 24*fem,
                  child: Text(
                    'Jonny Kim',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}