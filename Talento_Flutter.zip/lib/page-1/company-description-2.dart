import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // companydescription2nrL (94:2350)
        width: double.infinity,
        height: 583*fem,
        child: Stack(
          children: [
            Positioned(
              // backgroundiEC (94:2351)
              left: 0*fem,
              top: 50*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 533*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group151j6 (94:2352)
              left: 13*fem,
              top: 169*fem,
              child: Container(
                width: 384*fem,
                height: 118*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group10hrp (94:2353)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Container(
                    // group18fYk (94:2354)
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Center(
                      // rectangle5E64 (94:2355)
                      child: SizedBox(
                        width: double.infinity,
                        height: 118*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfff8f9fc),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group16xXr (94:2356)
              left: 13*fem,
              top: 298*fem,
              child: Container(
                width: 384*fem,
                height: 242*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group10GYY (94:2357)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Container(
                    // group18bqi (94:2358)
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Center(
                      // rectangle5kyW (94:2359)
                      child: SizedBox(
                        width: double.infinity,
                        height: 242*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfff8f9fc),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundGgx (94:2360)
              left: 0*fem,
              top: 566*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 17*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xffd0d1d3),
                          offset: Offset(0*fem, -0.3300000131*fem),
                          blurRadius: 0*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame5Njz (94:2361)
              left: 388.25*fem,
              top: 68.25*fem,
              child: Align(
                child: SizedBox(
                  width: 9.5*fem,
                  height: 9.5*fem,
                  child: Image.asset(
                    'assets/page-1/images/frame-5-vo2.png',
                    width: 9.5*fem,
                    height: 9.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse3fj6 (94:2365)
              left: 157*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 100*fem,
                  height: 100*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(50*fem),
                      border: Border.all(color: Color(0xff060606)),
                      image: DecorationImage (
                        fit: BoxFit.contain,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-3-bg-ohr.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame16YH6 (94:2366)
              left: 179*fem,
              top: 212*fem,
              child: Container(
                width: 201*fem,
                height: 45*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // focusconstructions4U (94:2367)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                      child: Text(
                        'Focus : Construction ',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 11*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xff86878b),
                        ),
                      ),
                    ),
                    Container(
                      // specializesengineeringpowertoo (94:2368)
                      constraints: BoxConstraints (
                        maxWidth: 201*fem,
                      ),
                      child: Text(
                        'Specializes : Engineering, Power Tools,  \n                        Services, Quality\n',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 11*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xff86878b),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // constructionengineeringsoftwar (94:2369)
              left: 94*fem,
              top: 141*fem,
              child: Align(
                child: SizedBox(
                  width: 225*fem,
                  height: 20*fem,
                  child: Text(
                    '#construction #engineering #software',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.5*ffem/fem,
                      color: Color(0x99000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // hiltikXa (94:2370)
              left: 185*fem,
              top: 112*fem,
              child: Align(
                child: SizedBox(
                  width: 45*fem,
                  height: 29*fem,
                  child: Text(
                    'Hilti',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // hiringQc8 (94:2372)
              left: 30*fem,
              top: 308*fem,
              child: Align(
                child: SizedBox(
                  width: 56*fem,
                  height: 24*fem,
                  child: Text(
                    'Hiring',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // aboutusXAx (94:2373)
              left: 29*fem,
              top: 180*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 24*fem,
                  child: Text(
                    'About Us',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // aboutusS32 (94:2374)
              left: 29*fem,
              top: 180*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 24*fem,
                  child: Text(
                    'About Us',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group21L8Q (94:2375)
              left: 43*fem,
              top: 343*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 324*fem,
                  height: 35*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        // group17e96 (94:2376)
                        left: 0*fem,
                        top: 0*fem,
                        child: Container(
                          width: 324*fem,
                          height: 35*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x26000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 15*fem,
                              ),
                            ],
                          ),
                          child: Container(
                            // group10jRS (94:2377)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Container(
                              // group18VfW (94:2378)
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(8*fem),
                              ),
                              child: Center(
                                // rectangle5Ed6 (94:2379)
                                child: SizedBox(
                                  width: double.infinity,
                                  height: 35*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(8*fem),
                                      color: Color(0xfff8f9fc),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // freshgraduatesoftwareengineerM (94:2380)
                        left: 45.5*fem,
                        top: 10*fem,
                        child: Align(
                          child: SizedBox(
                            width: 238*fem,
                            height: 18*fem,
                            child: Text(
                              'Fresh Graduate - Software Engineer',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1725*ffem/fem,
                                color: Color(0xff161722),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // group22dfE (94:2381)
              left: 43*fem,
              top: 390*fem,
              child: Container(
                width: 324*fem,
                height: 35*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // group17xSc (94:2382)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 324*fem,
                        height: 35*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group103ix (94:2383)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18ngY (94:2384)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5kdN (94:2385)
                              child: SizedBox(
                                width: double.infinity,
                                height: 35*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // freshgraduateitbusinessanalyst (94:2386)
                      left: 38.5*fem,
                      top: 10*fem,
                      child: Align(
                        child: SizedBox(
                          width: 247*fem,
                          height: 18*fem,
                          child: Text(
                            'Fresh Graduate - IT Business Analyst',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group23Mt4 (94:2387)
              left: 43*fem,
              top: 437*fem,
              child: Container(
                width: 324*fem,
                height: 35*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // group17Hmi (94:2388)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 324*fem,
                        height: 35*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10zAL (94:2389)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18MFn (94:2390)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5v3z (94:2391)
                              child: SizedBox(
                                width: double.infinity,
                                height: 35*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // freshgraduateitsupportFc4 (94:2392)
                      left: 71.5*fem,
                      top: 10*fem,
                      child: Align(
                        child: SizedBox(
                          width: 186*fem,
                          height: 18*fem,
                          child: Text(
                            'Fresh Graduate - IT Support',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // image20Yr4 (94:2452)
              left: 29*fem,
              top: 213*fem,
              child: Align(
                child: SizedBox(
                  width: 130*fem,
                  height: 30.54*fem,
                  child: Image.asset(
                    'assets/page-1/images/image-20.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}