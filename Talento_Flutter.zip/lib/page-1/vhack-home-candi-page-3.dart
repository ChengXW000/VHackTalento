import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // vhackhomecandipage39a8 (31:626)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          height: 896*fem,
          decoration: BoxDecoration (
            image: DecorationImage (
              fit: BoxFit.cover,
              image: AssetImage (
                'assets/page-1/images/gif1-bg-V8L.png',
              ),
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                // noteso8t (31:629)
                left: 292.5*fem,
                top: 676.5*fem,
                child: Align(
                  child: SizedBox(
                    width: 81.55*fem,
                    height: 113.16*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Image.asset(
                        'assets/page-1/images/notes-KfW.png',
                        width: 81.55*fem,
                        height: 113.16*fem,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // disc6tg (31:630)
                left: 358.4063720703*fem,
                top: 749.1066894531*fem,
                child: TextButton(
                  onPressed: () {},
                  style: TextButton.styleFrom (
                    padding: EdgeInsets.zero,
                  ),
                  child: Container(
                    width: 49*fem,
                    height: 49*fem,
                    child: Container(
                      // frame11qbN (I31:630;6:1398)
                      padding: EdgeInsets.fromLTRB(5.42*fem, 5.42*fem, 5.42*fem, 5.42*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(24.5*fem),
                        gradient: SweepGradient (
                          center: Alignment(0, 0),
                          startAngle: 1.55,
                          endAngle: 7.83,
                          tileMode: TileMode.repeated,
                          colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                          stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                        ),
                      ),
                      child: Center(
                        // ellipse21eG (I31:630;6:1400)
                        child: SizedBox(
                          width: 38.16*fem,
                          height: 38.16*fem,
                          child: Image.asset(
                            'assets/page-1/images/ellipse-2-65v.png',
                            width: 38.16*fem,
                            height: 38.16*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // headerMCL (31:653)
                left: 90*fem,
                top: 56*fem,
                child: Container(
                  width: 234*fem,
                  height: 19*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        // candidatesG4Q (31:654)
                        'Candidates',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                      SizedBox(
                        width: 35*fem,
                      ),
                      SizedBox(
                        width: 35*fem,
                      ),
                      TextButton(
                        // companiesvue (31:656)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Text(
                          'Companies',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1725*ffem/fem,
                            color: Color(0x99ffffff),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // barsstatusbariphonexSNC (31:660)
                left: 0*fem,
                top: 0*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                  width: 414*fem,
                  height: 44*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // timestylejs6 (31:679)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                        padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                        height: double.infinity,
                        child: Text(
                          '9:41',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'SF Pro Text',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.2575*ffem/fem,
                            letterSpacing: -0.3000000119*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                      Container(
                        // mobilesignalNv4 (31:674)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                        width: 18.77*fem,
                        height: 10.67*fem,
                        child: Image.asset(
                          'assets/page-1/images/mobile-signal-Zh2.png',
                          width: 18.77*fem,
                          height: 10.67*fem,
                        ),
                      ),
                      Container(
                        // wifi65N (31:670)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                        width: 16.86*fem,
                        height: 10.97*fem,
                        child: Image.asset(
                          'assets/page-1/images/wifi-BAQ.png',
                          width: 16.86*fem,
                          height: 10.97*fem,
                        ),
                      ),
                      Container(
                        // batterycZW (31:662)
                        margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                        width: 24.5*fem,
                        height: 10.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/battery-Tyz.png',
                          width: 24.5*fem,
                          height: 10.5*fem,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // mainpageiconKyi (78:640)
                left: 359*fem,
                top: 433*fem,
                child: Container(
                  width: 50*fem,
                  height: 272*fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // userrik (78:644)
                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 2*fem, 18*fem),
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: double.infinity,
                            child: Center(
                              // ellipse3bRS (78:645)
                              child: SizedBox(
                                width: double.infinity,
                                height: 47*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(23.5*fem),
                                    border: Border.all(color: Color(0xffffffff)),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/ellipse-3-bg-v3r.png',
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        // autogroup4xhzfgC (KweTGYhZ6o5474BC744Xhz)
                        width: double.infinity,
                        height: 70*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // savedpZ6 (78:646)
                              left: 0*fem,
                              top: 0*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 50*fem,
                                  height: 54*fem,
                                  child: Center(
                                    // jvx (I78:646;72:1727;72:1636)
                                    child: SizedBox(
                                      width: 50*fem,
                                      height: 54*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/-QcG.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // likesgbJ (78:648)
                              left: 6.5*fem,
                              top: 16*fem,
                              child: Opacity(
                                opacity: 0.9,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(6.5*fem, 38*fem, 6*fem, 0*fem),
                                  width: 35.5*fem,
                                  height: 54*fem,
                                  child: Text(
                                    '888',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 13*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroup81t4ZQC (KweTTHtehzS7eK7nCF81t4)
                        padding: EdgeInsets.fromLTRB(2*fem, 7*fem, 3*fem, 0*fem),
                        width: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // image10hWQ (78:647)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 45*fem,
                                  height: 45*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-10-r3r.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // image11APz (78:653)
                              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 11*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 40*fem,
                                  height: 40*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-11-tCx.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // chatVBN (78:643)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                              child: Text(
                                'Chat',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 13*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1725*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // infocWt (78:718)
                left: 12*fem,
                top: 704*fem,
                child: Container(
                  width: 255*fem,
                  height: 49*fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // samcheng1289Fv (78:719)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                        child: RichText(
                          text: TextSpan(
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.171875*ffem/fem,
                            ),
                            children: [
                              TextSpan(
                                text: '@SamCheng · ',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 17*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1725*ffem/fem,
                                ),
                              ),
                              TextSpan(
                                text: '1-28',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1725*ffem/fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Text(
                        // internengineeringeeoperationsw (78:720)
                        '#intern #engineering(EE) #operations',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.3*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // bottomnav5ap (116:453)
                left: 0*fem,
                top: 803*fem,
                child: Container(
                  width: 889*fem,
                  height: 93*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // subtractC9e (I116:453;25:2300)
                        left: 0*fem,
                        top: 27*fem,
                        child: Align(
                          child: SizedBox(
                            width: 889*fem,
                            height: 66*fem,
                            child: Image.asset(
                              'assets/page-1/images/subtract-N9e.png',
                              width: 889*fem,
                              height: 66*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsKk4 (I116:453;25:2301)
                        left: 29*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 60*fem,
                            height: 60*fem,
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-QgY.png',
                              width: 60*fem,
                              height: 60*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsdkk (I116:453;25:2302)
                        left: 112.75*fem,
                        top: 40*fem,
                        child: Align(
                          child: SizedBox(
                            width: 40*fem,
                            height: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Image.asset(
                                'assets/page-1/images/bottom-nav-icons-qct.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsHqJ (I116:453;25:2303)
                        left: 186.5*fem,
                        top: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                            width: 40*fem,
                            height: 40*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(60*fem),
                            ),
                            child: Center(
                              // image13PtL (I116:453;25:2303;78:413)
                              child: SizedBox(
                                width: 26*fem,
                                height: 26*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-13-X5J.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsVwN (I116:453;25:2304)
                        left: 260.25*fem,
                        top: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                            width: 40*fem,
                            height: 40*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(60*fem),
                            ),
                            child: Center(
                              // image9ox4 (I116:453;25:2304;72:1830)
                              child: SizedBox(
                                width: 34*fem,
                                height: 31.66*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-9-hoe.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsYPr (I116:453;25:2305)
                        left: 334*fem,
                        top: 40*fem,
                        child: Align(
                          child: SizedBox(
                            width: 40*fem,
                            height: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Image.asset(
                                'assets/page-1/images/bottom-nav-icons-UFA.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}