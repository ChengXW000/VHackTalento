import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // chatcandi3q2g (78:690)
        width: double.infinity,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.only (
            topLeft: Radius.circular(8*fem),
            topRight: Radius.circular(8*fem),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupl4paZDa (KweS5zqSZ8kEoHDBLFL4PA)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.33*fem),
              width: double.infinity,
              height: 571*fem,
              decoration: BoxDecoration (
                color: Color(0xfff5f5f4),
                borderRadius: BorderRadius.only (
                  topLeft: Radius.circular(8*fem),
                  topRight: Radius.circular(8*fem),
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // chatRma (78:693)
                    left: 192*fem,
                    top: 12*fem,
                    child: Align(
                      child: SizedBox(
                        width: 28*fem,
                        height: 16*fem,
                        child: Text(
                          'Chat',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 13*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff161722),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame3L7r (78:694)
                    left: 385.25*fem,
                    top: 15.25*fem,
                    child: Align(
                      child: SizedBox(
                        width: 9.5*fem,
                        height: 9.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/frame-3-mDi.png',
                          width: 9.5*fem,
                          height: 9.5*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // backgroundo1S (78:701)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 571*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xfff5f5f4),
                            borderRadius: BorderRadius.only (
                              topLeft: Radius.circular(8*fem),
                              topRight: Radius.circular(8*fem),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group45h6p (132:331)
                    left: 18*fem,
                    top: 70*fem,
                    child: Container(
                      width: 267*fem,
                      height: 138*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffebebeb),
                        borderRadius: BorderRadius.only (
                          topRight: Radius.circular(16*fem),
                          bottomRight: Radius.circular(16*fem),
                          bottomLeft: Radius.circular(16*fem),
                        ),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // bhz (132:333)
                            left: 234*fem,
                            top: 121*fem,
                            child: Center(
                              child: Align(
                                child: SizedBox(
                                  width: 25*fem,
                                  height: 12*fem,
                                  child: Text(
                                    '03:50',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xff535353),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ourcompanyisworkontraininginte (132:334)
                            left: 10*fem,
                            top: 10*fem,
                            child: Align(
                              child: SizedBox(
                                width: 245*fem,
                                height: 118*fem,
                                child: RichText(
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: 'Our company is work on training International Certificate in Ethical Hacking and other Cybersecurity courses. Also, we can accept Malaysian university students for internship to work as web backend developer or work in marketing section. We cannot pay money (salary) for internship. If you are interested in our courses to register or work as an internship, you can message me for more information. WhatsApp: +60173605097 Montana Education and Training (Malaysia) ',
                                      ),
                                      TextSpan(
                                        text: 'https://www.montana.com.my/',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 10*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.1725*ffem/fem,
                                          decoration: TextDecoration.underline,
                                          color: Color(0xff000000),
                                          decorationColor: Color(0xff000000),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // chatdCk (78:703)
                    left: 192*fem,
                    top: 12*fem,
                    child: Align(
                      child: SizedBox(
                        width: 28*fem,
                        height: 16*fem,
                        child: Text(
                          'Chat',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 13*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff161722),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame7iV6 (78:704)
                    left: 385.25*fem,
                    top: 15.25*fem,
                    child: Align(
                      child: SizedBox(
                        width: 9.5*fem,
                        height: 9.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/frame-7-bha.png',
                          width: 9.5*fem,
                          height: 9.5*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // bottombarSR6 (78:696)
              width: double.infinity,
              height: 82.67*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0xffd0d1d3),
                    offset: Offset(0*fem, -0.3300000131*fem),
                    blurRadius: 0*fem,
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Positioned(
                    // typemessageLWU (78:698)
                    left: 18*fem,
                    top: 14.669921875*fem,
                    child: Align(
                      child: SizedBox(
                        width: 113*fem,
                        height: 18*fem,
                        child: Text(
                          'Type Message ...',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff86878b),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // emojistrokeiconbhJ (78:699)
                    left: 375.0620117188*fem,
                    top: 15.169921875*fem,
                    child: Align(
                      child: SizedBox(
                        width: 22*fem,
                        height: 22*fem,
                        child: Image.asset(
                          'assets/page-1/images/emoji-stroke-icon-tMW.png',
                          width: 22*fem,
                          height: 22*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // adsignstrokeiconWpG (78:700)
                    left: 331*fem,
                    top: 15.169921875*fem,
                    child: Align(
                      child: SizedBox(
                        width: 22*fem,
                        height: 22*fem,
                        child: Image.asset(
                          'assets/page-1/images/ad-sign-stroke-icon-JAL.png',
                          width: 22*fem,
                          height: 22*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottombarqrY (78:706)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(18*fem, 14.67*fem, 16.94*fem, 14.67*fem),
                      width: 414*fem,
                      height: 82.67*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xffd0d1d3),
                            offset: Offset(0*fem, -0.3300000131*fem),
                            blurRadius: 0*fem,
                          ),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // typemessage73N (78:708)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 200*fem, 0*fem),
                            child: Text(
                              'Type Message ...',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1725*ffem/fem,
                                color: Color(0xff86878b),
                              ),
                            ),
                          ),
                          Container(
                            // adsignstrokeicon1eY (78:710)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 22.06*fem, 0*fem),
                            width: 22*fem,
                            height: 22*fem,
                            child: Image.asset(
                              'assets/page-1/images/ad-sign-stroke-icon-hdr.png',
                              width: 22*fem,
                              height: 22*fem,
                            ),
                          ),
                          Container(
                            // emojistrokeiconKfE (78:709)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                            width: 22*fem,
                            height: 22*fem,
                            child: Image.asset(
                              'assets/page-1/images/emoji-stroke-icon-Dqr.png',
                              width: 22*fem,
                              height: 22*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}