import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // vhackhomecandipage2Sde (31:530)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          height: 896*fem,
          decoration: BoxDecoration (
            image: DecorationImage (
              fit: BoxFit.cover,
              image: AssetImage (
                'assets/page-1/images/gif1-bg-ttG.png',
              ),
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                // notesvoi (31:533)
                left: 292.5*fem,
                top: 676.5*fem,
                child: Align(
                  child: SizedBox(
                    width: 81.55*fem,
                    height: 113.16*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Image.asset(
                        'assets/page-1/images/notes-oje.png',
                        width: 81.55*fem,
                        height: 113.16*fem,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // discQit (31:534)
                left: 358.4063720703*fem,
                top: 749.1066894531*fem,
                child: TextButton(
                  onPressed: () {},
                  style: TextButton.styleFrom (
                    padding: EdgeInsets.zero,
                  ),
                  child: Container(
                    width: 49*fem,
                    height: 49*fem,
                    child: Container(
                      // frame11LsS (I31:534;6:1398)
                      padding: EdgeInsets.fromLTRB(5.42*fem, 5.42*fem, 5.42*fem, 5.42*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(24.5*fem),
                        gradient: SweepGradient (
                          center: Alignment(0, 0),
                          startAngle: 1.55,
                          endAngle: 7.83,
                          tileMode: TileMode.repeated,
                          colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                          stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                        ),
                      ),
                      child: Center(
                        // ellipse2bHa (I31:534;6:1400)
                        child: SizedBox(
                          width: 38.16*fem,
                          height: 38.16*fem,
                          child: Image.asset(
                            'assets/page-1/images/ellipse-2-YQp.png',
                            width: 38.16*fem,
                            height: 38.16*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // headervak (31:557)
                left: 90*fem,
                top: 56*fem,
                child: Container(
                  width: 234*fem,
                  height: 19*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        // candidatesDZr (31:558)
                        'Candidates',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                      SizedBox(
                        width: 35*fem,
                      ),
                      SizedBox(
                        width: 35*fem,
                      ),
                      TextButton(
                        // companiesGo2 (31:560)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Text(
                          'Companies',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1725*ffem/fem,
                            color: Color(0x99ffffff),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // barshomeindicatorCgg (31:561)
                left: 0*fem,
                top: 861*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(140*fem, 20*fem, 140*fem, 10*fem),
                  width: 414*fem,
                  height: 35*fem,
                  child: Center(
                    // lineiuv (31:563)
                    child: SizedBox(
                      width: double.infinity,
                      height: 5*fem,
                      child: Container(
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(100*fem),
                          color: Color(0xffe9e9e9),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // barsstatusbariphonex3xC (31:564)
                left: 0*fem,
                top: 0*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                  width: 414*fem,
                  height: 44*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // timestyleXcU (31:583)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                        padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                        height: double.infinity,
                        child: Text(
                          '9:41',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'SF Pro Text',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.2575*ffem/fem,
                            letterSpacing: -0.3000000119*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                      Container(
                        // mobilesignalCTi (31:578)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                        width: 18.77*fem,
                        height: 10.67*fem,
                        child: Image.asset(
                          'assets/page-1/images/mobile-signal-o1A.png',
                          width: 18.77*fem,
                          height: 10.67*fem,
                        ),
                      ),
                      Container(
                        // wifi7qa (31:574)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                        width: 16.86*fem,
                        height: 10.97*fem,
                        child: Image.asset(
                          'assets/page-1/images/wifi-NBi.png',
                          width: 16.86*fem,
                          height: 10.97*fem,
                        ),
                      ),
                      Container(
                        // batteryR5a (31:566)
                        margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                        width: 24.5*fem,
                        height: 10.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/battery-HTn.png',
                          width: 24.5*fem,
                          height: 10.5*fem,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // mainpageiconLTS (78:608)
                left: 359*fem,
                top: 433*fem,
                child: Container(
                  width: 50*fem,
                  height: 272*fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // userF4c (78:612)
                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 2*fem, 18*fem),
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: double.infinity,
                            child: Center(
                              // ellipse3BDA (78:613)
                              child: SizedBox(
                                width: double.infinity,
                                height: 47*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(23.5*fem),
                                    border: Border.all(color: Color(0xffffffff)),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/ellipse-3-bg-BS8.png',
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        // autogrouppg8q6qv (KweXvL7hF7m8tGwTGSPG8Q)
                        width: double.infinity,
                        height: 70*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // savedqHi (78:614)
                              left: 0*fem,
                              top: 0*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 50*fem,
                                  height: 54*fem,
                                  child: Center(
                                    // MG4 (I78:614;72:1727;72:1636)
                                    child: SizedBox(
                                      width: 50*fem,
                                      height: 54*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/-bUk.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // likesf1r (78:616)
                              left: 6.5*fem,
                              top: 16*fem,
                              child: Opacity(
                                opacity: 0.9,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(6.5*fem, 38*fem, 6*fem, 0*fem),
                                  width: 35.5*fem,
                                  height: 54*fem,
                                  child: Text(
                                    '178',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 13*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroup7wklXJx (KweY7KoNhgyFCmiX8G7wkL)
                        padding: EdgeInsets.fromLTRB(2*fem, 7*fem, 3*fem, 0*fem),
                        width: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // image10TiQ (78:615)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 45*fem,
                                  height: 45*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-10-iKr.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // image11Mon (78:621)
                              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 11*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 40*fem,
                                  height: 40*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/image-11-jUC.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // chatUdW (78:611)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                              child: Text(
                                'Chat',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 13*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1725*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // infoCpQ (78:715)
                left: 12*fem,
                top: 704*fem,
                child: Container(
                  width: 292*fem,
                  height: 49*fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // suetjin128WKJ (78:716)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                        child: RichText(
                          text: TextSpan(
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                            children: [
                              TextSpan(
                                text: '@suetjin',
                              ),
                              TextSpan(
                                text: ' · ',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 17*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1725*ffem/fem,
                                  color: Color(0x99ffffff),
                                ),
                              ),
                              TextSpan(
                                text: '1-28',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1725*ffem/fem,
                                  color: Color(0x99ffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Text(
                        // internengineeringeeengineering (78:717)
                        '#intern #engineering(EE) #engineering(SE)',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.3*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // bottomnav1Hz (116:439)
                left: 0*fem,
                top: 804*fem,
                child: Container(
                  width: 889*fem,
                  height: 93*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // subtractLLG (I116:439;25:2300)
                        left: 0*fem,
                        top: 27*fem,
                        child: Align(
                          child: SizedBox(
                            width: 889*fem,
                            height: 66*fem,
                            child: Image.asset(
                              'assets/page-1/images/subtract-vyn.png',
                              width: 889*fem,
                              height: 66*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsf7e (I116:439;25:2301)
                        left: 35*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 60*fem,
                            height: 60*fem,
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-kjJ.png',
                              width: 60*fem,
                              height: 60*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsXQk (I116:439;25:2302)
                        left: 118.75*fem,
                        top: 40*fem,
                        child: Align(
                          child: SizedBox(
                            width: 40*fem,
                            height: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Image.asset(
                                'assets/page-1/images/bottom-nav-icons-GxY.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconseEU (I116:439;25:2303)
                        left: 192.5*fem,
                        top: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                            width: 40*fem,
                            height: 40*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(60*fem),
                            ),
                            child: Center(
                              // image136cG (I116:439;25:2303;78:413)
                              child: SizedBox(
                                width: 26*fem,
                                height: 26*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-13-UxQ.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsDB6 (I116:439;25:2304)
                        left: 266.25*fem,
                        top: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                            width: 40*fem,
                            height: 40*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(60*fem),
                            ),
                            child: Center(
                              // image9JiL (I116:439;25:2304;72:1830)
                              child: SizedBox(
                                width: 34*fem,
                                height: 31.66*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-9-8tY.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsFNg (I116:439;25:2305)
                        left: 340*fem,
                        top: 40*fem,
                        child: Align(
                          child: SizedBox(
                            width: 40*fem,
                            height: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Image.asset(
                                'assets/page-1/images/bottom-nav-icons-3cC.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}