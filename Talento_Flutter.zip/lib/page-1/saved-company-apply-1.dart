import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // savedcompanyapply1cqW (94:2687)
        width: double.infinity,
        height: 654*fem,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.only (
            topLeft: Radius.circular(8*fem),
            topRight: Radius.circular(8*fem),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // backgroundJiL (94:2688)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 571*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // chat28Y (94:2690)
              left: 192*fem,
              top: 12*fem,
              child: Align(
                child: SizedBox(
                  width: 28*fem,
                  height: 16*fem,
                  child: Text(
                    'Chat',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame3Goa (94:2691)
              left: 385.25*fem,
              top: 15.25*fem,
              child: Align(
                child: SizedBox(
                  width: 9.5*fem,
                  height: 9.5*fem,
                  child: Image.asset(
                    'assets/page-1/images/frame-3-wDa.png',
                    width: 9.5*fem,
                    height: 9.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundmkL (94:2693)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 654*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group29Gwz (94:2694)
              left: 100*fem,
              top: 12*fem,
              child: Container(
                width: 294.75*fem,
                height: 16*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // seniorstartupecosystemexecutiv (94:2696)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 72.25*fem, 0*fem),
                      child: Text(
                        'Senior Startup Ecosystem Executive',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xff161722),
                        ),
                      ),
                    ),
                    Container(
                      // frame7hGc (94:2697)
                      width: 9.5*fem,
                      height: 9.5*fem,
                      child: Image.asset(
                        'assets/page-1/images/frame-7-cTA.png',
                        width: 9.5*fem,
                        height: 9.5*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // buttontealdg4 (94:2699)
              left: 165*fem,
              top: 591*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 85*fem,
                  height: 40*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(6*fem),
                    gradient: LinearGradient (
                      begin: Alignment(-1, -1),
                      end: Alignment(1, 1),
                      colors: <Color>[Color(0xff0dae87), Color(0xff1350c6)],
                      stops: <double>[0, 1],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x26000000),
                        offset: Offset(0*fem, 1*fem),
                        blurRadius: 1.5*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Apply',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.25*ffem/fem,
                        letterSpacing: -0.16*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundCMn (94:2700)
              left: 0*fem,
              top: 637*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 17*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xffd0d1d3),
                          offset: Offset(0*fem, -0.3300000131*fem),
                          blurRadius: 0*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group30He8 (94:2701)
              left: 16*fem,
              top: 57*fem,
              child: Container(
                width: 384*fem,
                height: 84*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15p8G (94:2702)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 81*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10uvQ (94:2703)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18sMS (94:2704)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5ESt (94:2705)
                              child: SizedBox(
                                width: double.infinity,
                                height: 81*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tertiaryeducationinanyfieldwit (94:2707)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 310*fem,
                          height: 26*fem,
                          child: Text(
                            'Tertiary education in any field with preference for those with a business, communication or technology degree.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // qualificationqSg (94:2709)
                      left: 14*fem,
                      top: 11*fem,
                      child: Align(
                        child: SizedBox(
                          width: 116*fem,
                          height: 24*fem,
                          child: Text(
                            'Qualification',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group31hDz (94:2710)
              left: 16*fem,
              top: 154*fem,
              child: Container(
                width: 384*fem,
                height: 79*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15DCL (94:2711)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 74*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group10vsS (94:2712)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18Hxt (94:2713)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5eYY (94:2714)
                              child: SizedBox(
                                width: double.infinity,
                                height: 74*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // abilitytoperformplanningandexe (94:2716)
                      left: 14*fem,
                      top: 34*fem,
                      child: Align(
                        child: SizedBox(
                          width: 353*fem,
                          height: 26*fem,
                          child: Text(
                            'Ability to perform planning and execution of startup programs in many areas. Comfortable to engage with stakeholders of the ecosystem',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // jobscopedvG (94:2718)
                      left: 14*fem,
                      top: 5*fem,
                      child: Align(
                        child: SizedBox(
                          width: 96*fem,
                          height: 24*fem,
                          child: Text(
                            'Job Scope',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group32JWc (94:2719)
              left: 16*fem,
              top: 240*fem,
              child: Container(
                width: 384*fem,
                height: 122*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15Ev4 (94:2720)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 113*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group108Ek (94:2721)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18Gbr (94:2722)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5Bip (94:2723)
                              child: SizedBox(
                                width: double.infinity,
                                height: 113*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // candidateswithgoodwrittenandsp (94:2725)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 355*fem,
                          height: 52*fem,
                          child: Text(
                            'Candidates with good written and spoken English and Bahasa Malaysia. Written Mandarin, Tamil and other languages is a plus.\nCandidate experience in event planning and management.\nCandidates ready to be based in Penang (not negotiable).',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // lookingfor8Gg (94:2727)
                      left: 14*fem,
                      top: 12*fem,
                      child: Align(
                        child: SizedBox(
                          width: 104*fem,
                          height: 24*fem,
                          child: Text(
                            'Looking for',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group33qgt (94:2728)
              left: 16*fem,
              top: 367*fem,
              child: Container(
                width: 384*fem,
                height: 186*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group15WY8 (94:2729)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 178*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x26000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 15*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // group101zg (94:2730)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Container(
                            // group18P68 (94:2731)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Center(
                              // rectangle5wtL (94:2732)
                              child: SizedBox(
                                width: double.infinity,
                                height: 178*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    color: Color(0xfff8f9fc),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // previousexperienceinsimilarrol (94:2734)
                      left: 14*fem,
                      top: 39*fem,
                      child: Align(
                        child: SizedBox(
                          width: 334*fem,
                          height: 104*fem,
                          child: Text(
                            'Previous experience in similar role in any government or private startup ecosystem development company is a plus.\nDemonstrate interest and experience in the tech startup space.\nProfessional with good communication skills. Able to articulate yourself clearly.\nRespectful and have good interpersonal skills with people.\nLearn quickly, adapt fast with good self-discipline and organization capabilities.',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 11*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // prefercsz (94:2736)
                      left: 14*fem,
                      top: 8*fem,
                      child: Align(
                        child: SizedBox(
                          width: 57*fem,
                          height: 24*fem,
                          child: Text(
                            'Prefer',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}