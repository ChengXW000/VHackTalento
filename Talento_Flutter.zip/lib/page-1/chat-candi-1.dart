import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // chatcandi14Wc (78:463)
        width: double.infinity,
        height: 654*fem,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.only (
            topLeft: Radius.circular(8*fem),
            topRight: Radius.circular(8*fem),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupq1haZiG (KwebuJKB9bm7B7CgEGQ1Ha)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                width: 414*fem,
                height: 571*fem,
                decoration: BoxDecoration (
                  color: Color(0xfff5f5f4),
                  borderRadius: BorderRadius.only (
                    topLeft: Radius.circular(8*fem),
                    topRight: Radius.circular(8*fem),
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // chatEpQ (78:466)
                      left: 192*fem,
                      top: 12*fem,
                      child: Align(
                        child: SizedBox(
                          width: 28*fem,
                          height: 16*fem,
                          child: Text(
                            'Chat',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 13*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // frame3te4 (78:467)
                      left: 385.25*fem,
                      top: 15.25*fem,
                      child: Align(
                        child: SizedBox(
                          width: 9.5*fem,
                          height: 9.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/frame-3-L9n.png',
                            width: 9.5*fem,
                            height: 9.5*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // backgroundC8x (78:659)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 414*fem,
                          height: 571*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xfff5f5f4),
                              borderRadius: BorderRadius.only (
                                topLeft: Radius.circular(8*fem),
                                topRight: Radius.circular(8*fem),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // chat712 (78:661)
                      left: 192*fem,
                      top: 12*fem,
                      child: Align(
                        child: SizedBox(
                          width: 28*fem,
                          height: 16*fem,
                          child: Text(
                            'Chat',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 13*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff161722),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // frame71cC (78:662)
                      left: 385.25*fem,
                      top: 15.25*fem,
                      child: Align(
                        child: SizedBox(
                          width: 9.5*fem,
                          height: 9.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/frame-7-MFW.png',
                            width: 9.5*fem,
                            height: 9.5*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // group45GHE (132:324)
                      left: 18*fem,
                      top: 70*fem,
                      child: Container(
                        width: 267*fem,
                        height: 68*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffebebeb),
                          borderRadius: BorderRadius.only (
                            topRight: Radius.circular(16*fem),
                            bottomRight: Radius.circular(16*fem),
                            bottomLeft: Radius.circular(16*fem),
                          ),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // kTJ (132:326)
                              left: 232*fem,
                              top: 55*fem,
                              child: Center(
                                child: Align(
                                  child: SizedBox(
                                    width: 25*fem,
                                    height: 12*fem,
                                    child: Text(
                                      '12:00',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 10*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff535353),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // dearjayeimreachingouttoseeifyo (132:330)
                              left: 10*fem,
                              top: 10*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 247*fem,
                                  height: 47*fem,
                                  child: Text(
                                    'Dear Jaye, I’m reaching out to see if you’d be interested in a Product Intern role. Please let me know if you are available to discuss as we have a position which very much may interest you',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // bottombarEFz (78:602)
              left: 0*fem,
              top: 571.3300018311*fem,
              child: Container(
                width: 414*fem,
                height: 82.67*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0xffd0d1d3),
                      offset: Offset(0*fem, -0.3300000131*fem),
                      blurRadius: 0*fem,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // typemessageusv (78:604)
                      left: 18*fem,
                      top: 14.6699981689*fem,
                      child: Align(
                        child: SizedBox(
                          width: 113*fem,
                          height: 18*fem,
                          child: Text(
                            'Type Message ...',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff86878b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // emojistrokeiconoyJ (78:605)
                      left: 375.0620117188*fem,
                      top: 15.1699981689*fem,
                      child: Align(
                        child: SizedBox(
                          width: 22*fem,
                          height: 22*fem,
                          child: Image.asset(
                            'assets/page-1/images/emoji-stroke-icon-m1i.png',
                            width: 22*fem,
                            height: 22*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // adsignstrokeiconhHz (78:606)
                      left: 331*fem,
                      top: 15.1699981689*fem,
                      child: Align(
                        child: SizedBox(
                          width: 22*fem,
                          height: 22*fem,
                          child: Image.asset(
                            'assets/page-1/images/ad-sign-stroke-icon-SwS.png',
                            width: 22*fem,
                            height: 22*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottombarb8U (78:664)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(18*fem, 14.67*fem, 16.94*fem, 14.67*fem),
                        width: 414*fem,
                        height: 82.67*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xffd0d1d3),
                              offset: Offset(0*fem, -0.3300000131*fem),
                              blurRadius: 0*fem,
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // typemessageeMe (78:666)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 200*fem, 0*fem),
                              child: Text(
                                'Type Message ...',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1725*ffem/fem,
                                  color: Color(0xff86878b),
                                ),
                              ),
                            ),
                            Container(
                              // adsignstrokeiconmBN (78:668)
                              margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 22.06*fem, 0*fem),
                              width: 22*fem,
                              height: 22*fem,
                              child: Image.asset(
                                'assets/page-1/images/ad-sign-stroke-icon-gJk.png',
                                width: 22*fem,
                                height: 22*fem,
                              ),
                            ),
                            Container(
                              // emojistrokeiconVNG (78:667)
                              margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                              width: 22*fem,
                              height: 22*fem,
                              child: Image.asset(
                                'assets/page-1/images/emoji-stroke-icon-UKi.png',
                                width: 22*fem,
                                height: 22*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // gutsbubblerighto84 (132:344)
              left: 170*fem,
              top: 164*fem,
              child: Container(
                width: 241*fem,
                height: 44*fem,
                decoration: BoxDecoration (
                  color: Color(0xff00bf9c),
                  borderRadius: BorderRadius.only (
                    topLeft: Radius.circular(24*fem),
                    bottomRight: Radius.circular(24*fem),
                    bottomLeft: Radius.circular(24*fem),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x14000000),
                      offset: Offset(0*fem, -1*fem),
                      blurRadius: 0.5*fem,
                    ),
                    BoxShadow(
                      color: Color(0x28000000),
                      offset: Offset(0*fem, 2*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x3d000000),
                      offset: Offset(0*fem, 0*fem),
                      blurRadius: 0.5*fem,
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    'Thank you for pm me, I will consider about it.',
                    textAlign: TextAlign.right,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 10*ffem,
                      fontWeight: FontWeight.w400,
                      height: 2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}