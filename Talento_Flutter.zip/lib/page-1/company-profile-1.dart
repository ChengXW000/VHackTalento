import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // companyprofile1WFi (88:1859)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupapj6aFa (KweH7b7uY2s5ho6hLdAPj6)
              width: double.infinity,
              height: 384*fem,
              child: Stack(
                children: [
                  Positioned(
                    // topbarWQ8 (88:1861)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 414*fem,
                      height: 87.67*fem,
                      child: Center(
                        // backgroundemE (88:1862)
                        child: SizedBox(
                          width: double.infinity,
                          height: 87.67*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0xffd0d1d3),
                                  offset: Offset(0*fem, 0.3300000131*fem),
                                  blurRadius: 0*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // maskgroupkZN (88:1863)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 249*fem,
                        child: Image.asset(
                          'assets/page-1/images/mask-group-PEx.png',
                          width: 414*fem,
                          height: 249*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // barsstatusbariphonexUVN (88:1866)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                      width: 414*fem,
                      height: 44*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timestyleMJG (88:1885)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                            height: double.infinity,
                            child: Text(
                              '9:41',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'SF Pro Text',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2575*ffem/fem,
                                letterSpacing: -0.3000000119*fem,
                                color: Color(0xff171717),
                              ),
                            ),
                          ),
                          Container(
                            // mobilesignalD5a (88:1880)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                            width: 18.77*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/mobile-signal-g8x.png',
                              width: 18.77*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // wifiWqN (88:1876)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                            width: 16.86*fem,
                            height: 10.97*fem,
                            child: Image.asset(
                              'assets/page-1/images/wifi-oJG.png',
                              width: 16.86*fem,
                              height: 10.97*fem,
                            ),
                          ),
                          Container(
                            // batteryRhS (88:1868)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                            width: 24.5*fem,
                            height: 10.5*fem,
                            child: Image.asset(
                              'assets/page-1/images/battery-uix.png',
                              width: 24.5*fem,
                              height: 10.5*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group8xBa (88:1887)
                    left: 18*fem,
                    top: 48*fem,
                    child: Align(
                      child: SizedBox(
                        width: 22*fem,
                        height: 16.04*fem,
                        child: Image.asset(
                          'assets/page-1/images/group-8-F8t.png',
                          width: 22*fem,
                          height: 16.04*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle5s3e (88:1889)
                    left: 11*fem,
                    top: 118*fem,
                    child: Align(
                      child: SizedBox(
                        width: 393*fem,
                        height: 265*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(33*fem),
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x2d30007e),
                                offset: Offset(0*fem, 10*fem),
                                blurRadius: 25*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // fusionexisaglobalmultiawardwin (88:1893)
                    left: 58*fem,
                    top: 202*fem,
                    child: Align(
                      child: SizedBox(
                        width: 302*fem,
                        height: 31*fem,
                        child: Text(
                          'Fusionex is a global, multi-award winning data technology provider with a strong worldwide presence.',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w300,
                            height: 1.2625480036*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // fusionexgroupBCk (88:1894)
                    left: 137*fem,
                    top: 170*fem,
                    child: Align(
                      child: SizedBox(
                        width: 141*fem,
                        height: 24*fem,
                        child: Text(
                          'Fusionex Group',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle7Ewi (88:1896)
                    left: 224*fem,
                    top: 319*fem,
                    child: Align(
                      child: SizedBox(
                        width: 168*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0xff084fff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group114Zyz (123:312)
                    left: 36*fem,
                    top: 319*fem,
                    child: Container(
                      width: 168*fem,
                      height: 45*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff084fff),
                        borderRadius: BorderRadius.circular(12*fem),
                      ),
                      child: Center(
                        child: Text(
                          'Website',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.8*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // followE4Y (88:1898)
                    left: 276*fem,
                    top: 330*fem,
                    child: Align(
                      child: SizedBox(
                        width: 64*fem,
                        height: 24*fem,
                        child: Text(
                          'Follow',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.8*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame18XJY (88:1931)
                    left: 148*fem,
                    top: 259*fem,
                    child: Container(
                      width: 119*fem,
                      height: 45*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group14e8G (88:1933)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // image15KVJ (88:1935)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-15-MXv.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // group17s12 (88:1939)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // image16oQU (88:1941)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-16-EC8.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse39jE (88:2010)
                    left: 160*fem,
                    top: 63*fem,
                    child: Align(
                      child: SizedBox(
                        width: 100*fem,
                        height: 100*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(50*fem),
                            border: Border.all(color: Color(0xff060606)),
                            image: DecorationImage (
                              fit: BoxFit.contain,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-3-bg-uC4.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroups4cx2HE (KweHfEsqNQeVAgJg9PS4Cx)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
              width: double.infinity,
              height: 502*fem,
              child: Stack(
                children: [
                  Positioned(
                    // ellipse38bA (88:1899)
                    left: 151*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            border: Border.all(color: Color(0xff000000)),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-3-bg-Y7i.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse42Ak (88:1900)
                    left: 220*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            border: Border.all(color: Color(0xff000000)),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-4-bg-rXi.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse5LBS (88:1901)
                    left: 285*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(22.5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/ellipse-5-bg-uD2.png',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse6xTi (88:1902)
                    left: 351*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(22.5*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-6-bg-PqA.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group14Wk (88:1903)
                    left: 150*fem,
                    top: 124*fem,
                    child: Container(
                      width: 250*fem,
                      height: 377*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupbununxY (KweHwpEYqj5LEqR6rfbUnU)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11.58*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle6jct (88:1904)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.62*fem, 0*fem),
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-6-i2t.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // rectangle7UKa (88:1907)
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-7-6YG.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupz2z6puE (KweJ2jG2aoNcFCBrKmZ2Z6)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11.58*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle8YaL (88:1905)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.62*fem, 0*fem),
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-8-nCx.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // rectangle9nUg (88:1908)
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-9-GdW.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupbnhnwMa (KweJ74U9LfN76fLpL4bnHN)
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle10hLk (88:1906)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.62*fem, 0*fem),
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-10-3n8.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // rectangle11Eba (88:1909)
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-11-YLx.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // peoplealsofollowedPDa (88:1910)
                    left: 150*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 174*fem,
                        height: 22*fem,
                        child: Text(
                          'People Also Followed',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // galleryUVv (88:1911)
                    left: 147*fem,
                    top: 96*fem,
                    child: Align(
                      child: SizedBox(
                        width: 57*fem,
                        height: 22*fem,
                        child: Text(
                          'Gallery',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // backgroundAtY (88:1942)
                    left: 0*fem,
                    top: 470*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 32*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xffd0d1d3),
                                offset: Offset(0*fem, -0.3300000131*fem),
                                blurRadius: 0*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group274U8 (88:2014)
                    left: 11*fem,
                    top: 6*fem,
                    child: Container(
                      width: 129*fem,
                      height: 147*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(21*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group10YPJ (88:1913)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(21*fem),
                        ),
                        child: Container(
                          // group18txx (88:1914)
                          padding: EdgeInsets.fromLTRB(28*fem, 28*fem, 28*fem, 29*fem),
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff8f9fc),
                            borderRadius: BorderRadius.circular(21*fem),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // ksavesPui (88:1918)
                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 4.67*fem),
                                constraints: BoxConstraints (
                                  maxWidth: 35*fem,
                                ),
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.0918749173*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: '88K\n',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 20*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.3102499008*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                      TextSpan(
                                        text: 'Saves',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 11*ffem,
                                          fontWeight: FontWeight.w300,
                                          height: 1.0918749896*ffem/fem,
                                          letterSpacing: 0.055*fem,
                                          color: Color(0xff959595),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                // line1n4g (88:1917)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.33*fem),
                                width: double.infinity,
                                height: 1*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xb2979797),
                                ),
                              ),
                              Container(
                                // kfollowersXHA (88:1943)
                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                constraints: BoxConstraints (
                                  maxWidth: 48*fem,
                                ),
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 18*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.171875*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: '99K\n',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 20*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.1725*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                      TextSpan(
                                        text: 'Followers',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 11*ffem,
                                          fontWeight: FontWeight.w300,
                                          height: 1.1725*ffem/fem,
                                          letterSpacing: 0.055*fem,
                                          color: Color(0xff959595),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group14zKA (88:1920)
                    left: 11*fem,
                    top: 183*fem,
                    child: Container(
                      width: 129*fem,
                      height: 164*fem,
                      decoration: BoxDecoration (
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x26000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 15*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group1067J (88:1921)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(21*fem),
                        ),
                        child: Container(
                          // group182me (88:1922)
                          padding: EdgeInsets.fromLTRB(42*fem, 25*fem, 40*fem, 29*fem),
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff8f9fc),
                            borderRadius: BorderRadius.circular(21*fem),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group20LXS (88:1928)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 20*fem),
                                padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                                decoration: BoxDecoration (
                                  color: Color(0xffe8e5f2),
                                  borderRadius: BorderRadius.circular(12*fem),
                                ),
                                child: Center(
                                  // image19S4g (88:2012)
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-19-ArL.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group18xoi (88:1924)
                                margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                                decoration: BoxDecoration (
                                  color: Color(0xffe8e5f2),
                                  borderRadius: BorderRadius.circular(12*fem),
                                ),
                                child: Center(
                                  // image16VHr (88:1926)
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-16-Rjv.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}