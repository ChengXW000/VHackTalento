import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // vhacklatestinfoKRa (133:302)
        width: double.infinity,
        height: 896*fem,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0, -1),
            end: Alignment(0, 1),
            colors: <Color>[Color(0xa5eb9dd9), Color(0xa5eb9de3), Color(0xa5a79deb), Color(0xa5a79deb), Color(0xa5a79deb)],
            stops: <double>[0, 0.214, 0.516, 0.698, 0.964],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // group34wC4 (157:737)
              left: 20*fem,
              top: 269*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(32*fem, 12*fem, 61*fem, 4*fem),
                width: 373*fem,
                height: 155*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff3e3fd8)),
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(20*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group28Jgp (157:741)
                      margin: EdgeInsets.fromLTRB(76*fem, 0*fem, 46.72*fem, 5.8*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // maskgroupCnC (157:743)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.19*fem, 0*fem),
                            width: 31.08*fem,
                            height: 18.7*fem,
                          ),
                          Container(
                            // fusionexgroupkHv (157:742)
                            margin: EdgeInsets.fromLTRB(0*fem, 2.2*fem, 0*fem, 0*fem),
                            child: Text(
                              'Fusionex Group',
                              style: SafeGoogleFont (
                                'Jost',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.445*ffem/fem,
                                color: Color(0xff61646b),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group29rrk (157:746)
                      margin: EdgeInsets.fromLTRB(91*fem, 0*fem, 85.81*fem, 11.13*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // Cfi (157:748)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.07*fem, 0*fem),
                            width: 32.12*fem,
                            height: 19.94*fem,
                            child: Image.asset(
                              'assets/page-1/images/-Av4.png',
                              fit: BoxFit.contain,
                            ),
                          ),
                          Container(
                            // ongoingjvY (157:747)
                            margin: EdgeInsets.fromLTRB(0*fem, 1.87*fem, 0*fem, 0*fem),
                            child: Text(
                              'Ongoing',
                              style: SafeGoogleFont (
                                'Jost',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.445*ffem/fem,
                                color: Color(0xff61646b),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // blockchaintechnologywithcrypto (157:740)
                      constraints: BoxConstraints (
                        maxWidth: 280*fem,
                      ),
                      child: Text(
                        'Blockchain Technology With Cryptocurrency',
                        style: SafeGoogleFont (
                          'Jost',
                          fontSize: 22*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.445*ffem/fem,
                          color: Color(0xff2e323b),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group368hn (157:766)
              left: 20*fem,
              top: 441*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(32*fem, 12*fem, 40*fem, 4*fem),
                width: 373*fem,
                height: 155*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff3e3fd8)),
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(20*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group287Zi (157:769)
                      margin: EdgeInsets.fromLTRB(76*fem, 0*fem, 102.72*fem, 5.8*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // maskgroupTNg (157:771)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.19*fem, 0*fem),
                            width: 31.08*fem,
                            height: 18.7*fem,
                          ),
                          Container(
                            // hiltigroupbzg (157:770)
                            margin: EdgeInsets.fromLTRB(0*fem, 2.2*fem, 0*fem, 0*fem),
                            child: Text(
                              'Hilti Group',
                              style: SafeGoogleFont (
                                'Jost',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.445*ffem/fem,
                                color: Color(0xff61646b),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group29ipQ (157:773)
                      margin: EdgeInsets.fromLTRB(91*fem, 0*fem, 57.81*fem, 11.13*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // Gb2 (157:775)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.07*fem, 0*fem),
                            width: 32.12*fem,
                            height: 19.94*fem,
                            child: Image.asset(
                              'assets/page-1/images/-23A.png',
                              fit: BoxFit.contain,
                            ),
                          ),
                          Container(
                            // march2023CDn (157:774)
                            margin: EdgeInsets.fromLTRB(0*fem, 1.87*fem, 0*fem, 0*fem),
                            child: Text(
                              '13 March 2023',
                              style: SafeGoogleFont (
                                'Jost',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.445*ffem/fem,
                                color: Color(0xff61646b),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // hiltiventuresoutsidetheboxwith (157:768)
                      constraints: BoxConstraints (
                        maxWidth: 301*fem,
                      ),
                      child: Text(
                        'Hilti Ventures outside the box with robotics company Canvas',
                        style: SafeGoogleFont (
                          'Jost',
                          fontSize: 22*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.445*ffem/fem,
                          color: Color(0xff2e323b),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group37Mkt (157:778)
              left: 23*fem,
              top: 613*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(30*fem, 12*fem, 30*fem, 22*fem),
                width: 373*fem,
                height: 155*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff3e3fd8)),
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(20*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group2814k (157:781)
                      margin: EdgeInsets.fromLTRB(78*fem, 0*fem, 142.72*fem, 5.8*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // maskgroupYqN (157:783)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.19*fem, 0*fem),
                            width: 31.08*fem,
                            height: 18.7*fem,
                          ),
                          Container(
                            // aramcoGWU (157:782)
                            margin: EdgeInsets.fromLTRB(0*fem, 2.2*fem, 0*fem, 0*fem),
                            child: Text(
                              'aramco',
                              style: SafeGoogleFont (
                                'Jost',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.445*ffem/fem,
                                color: Color(0xff61646b),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group29Cf2 (157:785)
                      margin: EdgeInsets.fromLTRB(93*fem, 0*fem, 67.81*fem, 25.13*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // Wvc (157:787)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.07*fem, 0*fem),
                            width: 32.12*fem,
                            height: 19.94*fem,
                            child: Image.asset(
                              'assets/page-1/images/-FpC.png',
                              fit: BoxFit.contain,
                            ),
                          ),
                          Container(
                            // march2023Tax (157:786)
                            margin: EdgeInsets.fromLTRB(0*fem, 1.87*fem, 0*fem, 0*fem),
                            child: Text(
                              '13 March 2023',
                              style: SafeGoogleFont (
                                'Jost',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.445*ffem/fem,
                                color: Color(0xff61646b),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // the2022annualreportB1A (157:780)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 64*fem, 0*fem),
                      child: Text(
                        'The 2022 Annual Report',
                        style: SafeGoogleFont (
                          'Jost',
                          fontSize: 22*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.445*ffem/fem,
                          color: Color(0xff2e323b),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group38UW4 (157:796)
              left: 20*fem,
              top: 785*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(30*fem, 12*fem, 30*fem, 22*fem),
                width: 373*fem,
                height: 155*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff3e3fd8)),
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(20*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group28uLU (157:799)
                      margin: EdgeInsets.fromLTRB(78*fem, 0*fem, 162.72*fem, 5.8*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // maskgroupRpc (157:801)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.19*fem, 0*fem),
                            width: 31.08*fem,
                            height: 18.7*fem,
                          ),
                          Container(
                            // upmybE (157:800)
                            margin: EdgeInsets.fromLTRB(0*fem, 2.2*fem, 0*fem, 0*fem),
                            child: Text(
                              'UPM',
                              style: SafeGoogleFont (
                                'Jost',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.445*ffem/fem,
                                color: Color(0xff61646b),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group297Be (157:803)
                      margin: EdgeInsets.fromLTRB(93*fem, 0*fem, 67.81*fem, 25.13*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // TWQ (157:805)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.07*fem, 0*fem),
                            width: 32.12*fem,
                            height: 19.94*fem,
                            child: Image.asset(
                              'assets/page-1/images/-zJc.png',
                              fit: BoxFit.contain,
                            ),
                          ),
                          Container(
                            // march2023bsW (157:804)
                            margin: EdgeInsets.fromLTRB(0*fem, 1.87*fem, 0*fem, 0*fem),
                            child: Text(
                              '13 March 2023',
                              style: SafeGoogleFont (
                                'Jost',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.445*ffem/fem,
                                color: Color(0xff61646b),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // the2022annualreportKHi (157:798)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 64*fem, 0*fem),
                      child: Text(
                        'The 2022 Annual Report',
                        style: SafeGoogleFont (
                          'Jost',
                          fontSize: 22*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.445*ffem/fem,
                          color: Color(0xff2e323b),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group30r2k (157:725)
              left: 20*fem,
              top: 114*fem,
              child: Container(
                width: 373*fem,
                height: 155*fem,
                decoration: BoxDecoration (
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // rectangle25Xeg (157:726)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 373*fem,
                          height: 136*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(20*fem),
                              border: Border.all(color: Color(0xff3e3fd8)),
                              color: Color(0xffffffff),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x0c000000),
                                  offset: Offset(4*fem, 4*fem),
                                  blurRadius: 25*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // vhack2023competition1pk (157:728)
                      left: 33*fem,
                      top: 95*fem,
                      child: Align(
                        child: SizedBox(
                          width: 252*fem,
                          height: 32*fem,
                          child: Text(
                            'Vhack 2023 Competition',
                            style: SafeGoogleFont (
                              'Jost',
                              fontSize: 22*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.445*ffem/fem,
                              color: Color(0xff2e323b),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // group28uQL (157:729)
                      left: 87*fem,
                      top: 23*fem,
                      child: Container(
                        width: 228.26*fem,
                        height: 27*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // maskgroupPqJ (157:731)
                              margin: EdgeInsets.fromLTRB(0*fem, 0.8*fem, 0.29*fem, 0*fem),
                              width: 46.97*fem,
                              height: 18.7*fem,
                            ),
                            Text(
                              // varsityhackathon2023wbv (157:730)
                              'Varsity Hackathon 2023',
                              style: SafeGoogleFont (
                                'Jost',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.445*ffem/fem,
                                color: Color(0xff61646b),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // group29ryn (157:734)
                      left: 131*fem,
                      top: 59*fem,
                      child: Container(
                        width: 103.19*fem,
                        height: 28.87*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // xX2 (157:736)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.07*fem, 0*fem),
                              width: 32.12*fem,
                              height: 19.94*fem,
                              child: Image.asset(
                                'assets/page-1/images/-uWG-gX2.png',
                                fit: BoxFit.contain,
                              ),
                            ),
                            Container(
                              // ongoinghUc (157:735)
                              margin: EdgeInsets.fromLTRB(0*fem, 1.87*fem, 0*fem, 0*fem),
                              child: Text(
                                'Ongoing',
                                style: SafeGoogleFont (
                                  'Jost',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.445*ffem/fem,
                                  color: Color(0xff61646b),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // latestinfoRfW (157:712)
              left: 90*fem,
              top: 44*fem,
              child: Align(
                child: SizedBox(
                  width: 234*fem,
                  height: 70*fem,
                  child: Text(
                    'Latest Info',
                    style: SafeGoogleFont (
                      'Jost',
                      fontSize: 48*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.445*ffem/fem,
                      color: Color(0xff2e323b),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // personWgx (157:745)
              left: 56*fem,
              top: 286*fem,
              child: Align(
                child: SizedBox(
                  width: 67.74*fem,
                  height: 70*fem,
                  child: Image.asset(
                    'assets/page-1/images/person.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // unsplash8yg31xn4dswRov (157:751)
              left: 59*fem,
              top: 620*fem,
              child: Align(
                child: SizedBox(
                  width: 331.56*fem,
                  height: 124.64*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(20*fem),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // barsstatusbariphonexLAC (158:302)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                width: 414*fem,
                height: 44*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timestyleduz (158:321)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                      padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                      height: double.infinity,
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro Text',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2575*ffem/fem,
                          letterSpacing: -0.3000000119*fem,
                          color: Color(0xff171717),
                        ),
                      ),
                    ),
                    Container(
                      // mobilesignaliwS (158:316)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                      width: 18.77*fem,
                      height: 10.67*fem,
                      child: Image.asset(
                        'assets/page-1/images/mobile-signal-ryN.png',
                        width: 18.77*fem,
                        height: 10.67*fem,
                      ),
                    ),
                    Container(
                      // wifiFgU (158:312)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                      width: 16.86*fem,
                      height: 10.97*fem,
                      child: Image.asset(
                        'assets/page-1/images/wifi-CKr.png',
                        width: 16.86*fem,
                        height: 10.97*fem,
                      ),
                    ),
                    Container(
                      // batteryycU (158:304)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                      width: 24.5*fem,
                      height: 10.5*fem,
                      child: Image.asset(
                        'assets/page-1/images/battery-jh2.png',
                        width: 24.5*fem,
                        height: 10.5*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // image38Qhn (157:777)
              left: 58*fem,
              top: 469*fem,
              child: Align(
                child: SizedBox(
                  width: 59*fem,
                  height: 59*fem,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10*fem),
                    child: Image.asset(
                      'assets/page-1/images/image-38.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // image39X1i (157:795)
              left: 49*fem,
              top: 632*fem,
              child: Align(
                child: SizedBox(
                  width: 70*fem,
                  height: 70*fem,
                  child: Image.asset(
                    'assets/page-1/images/image-39.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // image40pmW (157:807)
              left: 39*fem,
              top: 792*fem,
              child: Align(
                child: SizedBox(
                  width: 70*fem,
                  height: 70*fem,
                  child: Image.asset(
                    'assets/page-1/images/image-40.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle59xMv (157:765)
              left: 53*fem,
              top: 132*fem,
              child: Align(
                child: SizedBox(
                  width: 70*fem,
                  height: 70*fem,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10*fem),
                    child: Image.asset(
                      'assets/page-1/images/rectangle-59-3je.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // bottomnavdyr (25:2286)
              left: 0*fem,
              top: 803*fem,
              child: Container(
                width: 889*fem,
                height: 93*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // subtractNRe (I25:2286;25:2314)
                      left: 0*fem,
                      top: 27*fem,
                      child: Align(
                        child: SizedBox(
                          width: 889*fem,
                          height: 66*fem,
                          child: Image.asset(
                            'assets/page-1/images/subtract-v5v.png',
                            width: 889*fem,
                            height: 66*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnavicons43a (I25:2286;25:2315)
                      left: 39*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-tRv.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsvba (I25:2286;25:2316)
                      left: 112.75*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-UU8.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsdF6 (I25:2286;25:2317)
                      left: 177*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 12*fem),
                        width: 60*fem,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(30*fem),
                        ),
                        child: Center(
                          // image12XLU (I25:2286;25:2317;77:405)
                          child: SizedBox(
                            width: 35*fem,
                            height: 35*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-12-6yn.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconssfE (I25:2286;25:2318)
                      left: 260.25*fem,
                      top: 40*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                          width: 40*fem,
                          height: 40*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(60*fem),
                          ),
                          child: Center(
                            // image9mEp (I25:2286;25:2318;72:1830)
                            child: SizedBox(
                              width: 34*fem,
                              height: 31.66*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-9-e1W.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconstqE (I25:2286;25:2319)
                      left: 334*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-6hE.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}