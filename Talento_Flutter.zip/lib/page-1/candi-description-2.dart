import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // candidescription2pk8 (69:1518)
        width: double.infinity,
        height: 761*fem,
        child: Stack(
          children: [
            Positioned(
              // rectangle609nQ (152:315)
              left: 30*fem,
              top: 504*fem,
              child: Align(
                child: SizedBox(
                  width: 60*fem,
                  height: 60*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffd9d9d9),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle61gGY (152:327)
              left: 55*fem,
              top: 504*fem,
              child: Align(
                child: SizedBox(
                  width: 79*fem,
                  height: 60*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffd9d9d9),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundp7r (69:1519)
              left: 0*fem,
              top: 228*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 533*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundhBe (88:1737)
              left: 0*fem,
              top: 744*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 17*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xffd0d1d3),
                          offset: Offset(0*fem, -0.3300000131*fem),
                          blurRadius: 0*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // educationboxPKN (88:1673)
              left: 13*fem,
              top: 347*fem,
              child: Container(
                width: 384*fem,
                height: 118*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group10392 (88:1674)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Container(
                    // group18CGp (88:1675)
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Center(
                      // rectangle5Z7N (88:1676)
                      child: SizedBox(
                        width: double.infinity,
                        height: 118*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfff8f9fc),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // experienceboxgBz (88:1677)
              left: 14*fem,
              top: 471*fem,
              child: Container(
                width: 384*fem,
                height: 110*fem,
                decoration: BoxDecoration (
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // group10YV6 (88:1678)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 384*fem,
                        height: 110*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                        ),
                        child: Container(
                          // group185E8 (88:1679)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Center(
                            // rectangle5cjr (88:1680)
                            child: SizedBox(
                              width: double.infinity,
                              height: 110*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(8*fem),
                                  color: Color(0xfff8f9fc),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle59jZa (152:328)
                      left: 46*fem,
                      top: 33*fem,
                      child: Align(
                        child: SizedBox(
                          width: 60*fem,
                          height: 60*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-59.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // skillsboxqsW (88:1681)
              left: 14*fem,
              top: 587*fem,
              child: Container(
                width: 384*fem,
                height: 99*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group10Z2p (88:1682)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Container(
                    // group18igQ (88:1683)
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Center(
                      // rectangle5HjW (88:1684)
                      child: SizedBox(
                        width: double.infinity,
                        height: 99*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfff8f9fc),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // upmlogoDdA (88:1685)
              left: 0*fem,
              top: 329*fem,
              child: Container(
                width: 238*fem,
                height: 167*fem,
                decoration: BoxDecoration (
                  image: DecorationImage (
                    fit: BoxFit.cover,
                    image: AssetImage (
                      'assets/page-1/images/upm-logo-bg.png',
                    ),
                  ),
                ),
                child: Center(
                  // image29mi (88:1686)
                  child: SizedBox(
                    width: 238*fem,
                    height: 167*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-2-w9S.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // educationdescriptionUoz (88:1687)
              left: 187*fem,
              top: 387*fem,
              child: Container(
                width: 199*fem,
                height: 64*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // coursecomputerandcommunication (88:1688)
                      constraints: BoxConstraints (
                        maxWidth: 199*fem,
                      ),
                      child: Text(
                        'Course: Computer and Communication  \n               System Engineering',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 11*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xff86878b),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // statusongoing1styearTvp (88:1689)
                      'Status : Ongoing (1st Year)    ',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // yog2026y8U (88:1690)
                      'YOG     : 2026',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // educationJAk (88:1695)
              left: 29*fem,
              top: 352*fem,
              child: Align(
                child: SizedBox(
                  width: 90*fem,
                  height: 24*fem,
                  child: Text(
                    'Education',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // experienceyng (88:1696)
              left: 28*fem,
              top: 477*fem,
              child: Align(
                child: SizedBox(
                  width: 101*fem,
                  height: 24*fem,
                  child: Text(
                    'Experience',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // skillsqZz (88:1697)
              left: 29*fem,
              top: 594*fem,
              child: Align(
                child: SizedBox(
                  width: 51*fem,
                  height: 24*fem,
                  child: Text(
                    'Skills',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // figmapickS4 (88:1698)
              left: 305*fem,
              top: 627*fem,
              child: Align(
                child: SizedBox(
                  width: 29.97*fem,
                  height: 44.95*fem,
                  child: Image.asset(
                    'assets/page-1/images/figma-pic.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // cpic2uN (88:1700)
              left: 74*fem,
              top: 627*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 44.95*fem,
                  child: Image.asset(
                    'assets/page-1/images/c-pic.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // asmpicx2L (88:1701)
              left: 147*fem,
              top: 627*fem,
              child: Align(
                child: SizedBox(
                  width: 44.95*fem,
                  height: 44.95*fem,
                  child: Image.asset(
                    'assets/page-1/images/asm-pic.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // pythonimgGHv (88:1702)
              left: 225*fem,
              top: 627*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 44.95*fem,
                  child: Image.asset(
                    'assets/page-1/images/python-img.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // buttontealCSU (88:1703)
              left: 162*fem,
              top: 695*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 91*fem,
                  height: 40*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(6*fem),
                    gradient: LinearGradient (
                      begin: Alignment(-1, -1),
                      end: Alignment(1, 1),
                      colors: <Color>[Color(0xff0dae87), Color(0xff1350c6)],
                      stops: <double>[0, 1],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x26000000),
                        offset: Offset(0*fem, 1*fem),
                        blurRadius: 1.5*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'OFFER',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.25*ffem/fem,
                        letterSpacing: -0.16*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // tabupperjqi (69:1520)
              left: 388.25*fem,
              top: 246.25*fem,
              child: Align(
                child: SizedBox(
                  width: 9.5*fem,
                  height: 9.5*fem,
                  child: Image.asset(
                    'assets/page-1/images/tab-upper-99S.png',
                    width: 9.5*fem,
                    height: 9.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse3Qgx (69:1524)
              left: 157*fem,
              top: 178*fem,
              child: Align(
                child: SizedBox(
                  width: 100*fem,
                  height: 100*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(50*fem),
                      border: Border.all(color: Color(0xffffffff)),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-3-bg-tT2.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // internengineeringeeengineering (69:1538)
              left: 80*fem,
              top: 319*fem,
              child: Align(
                child: SizedBox(
                  width: 253*fem,
                  height: 20*fem,
                  child: Text(
                    '#intern #engineering(EE) #engineering(SE)',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.5*ffem/fem,
                      color: Color(0x99000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // suetjinnxQ (69:1539)
              left: 162*fem,
              top: 290*fem,
              child: Align(
                child: SizedBox(
                  width: 90*fem,
                  height: 29*fem,
                  child: Text(
                    'Suet Jin',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // experiencediscriptionG6t (152:321)
              left: 187*fem,
              top: 504*fem,
              child: Container(
                width: 146*fem,
                height: 51*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      // companyvhackPhJ (152:322)
                      'Company: Vhack',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // roleparticipantXHi (152:323)
                      'Role         : Participant     ',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                    SizedBox(
                      height: 6*fem,
                    ),
                    Text(
                      // periodfeb2023presentrat (152:324)
                      'Period     : Feb2023 - Present',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}