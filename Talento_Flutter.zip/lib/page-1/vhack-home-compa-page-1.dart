import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // vhackhomecompapage1EQp (18:1997)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration (
            color: Color(0xffc4c4c4),
            image: DecorationImage (
              fit: BoxFit.cover,
              image: AssetImage (
                'assets/page-1/images/background-bg-iYp.png',
              ),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                // vhackpage2umr (11:1748)
                padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                width: double.infinity,
                height: 44*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timestyle1Zz (11:1767)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                      padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                      height: double.infinity,
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro Text',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2575*ffem/fem,
                          letterSpacing: -0.3000000119*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // mobilesignalrac (11:1762)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                      width: 18.77*fem,
                      height: 10.67*fem,
                      child: Image.asset(
                        'assets/page-1/images/mobile-signal-ecg.png',
                        width: 18.77*fem,
                        height: 10.67*fem,
                      ),
                    ),
                    Container(
                      // wifimxU (11:1758)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                      width: 16.86*fem,
                      height: 10.97*fem,
                      child: Image.asset(
                        'assets/page-1/images/wifi-rS4.png',
                        width: 16.86*fem,
                        height: 10.97*fem,
                      ),
                    ),
                    Container(
                      // batteryWQG (11:1750)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                      width: 24.5*fem,
                      height: 10.5*fem,
                      child: Image.asset(
                        'assets/page-1/images/battery-Hqa.png',
                        width: 24.5*fem,
                        height: 10.5*fem,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // autogroupwcyg27i (KweNHrfFYJj1e7qNP9wCYg)
                padding: EdgeInsets.fromLTRB(12*fem, 12*fem, 5*fem, 4.89*fem),
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      // header8gY (11:1741)
                      margin: EdgeInsets.fromLTRB(81*fem, 0*fem, 82*fem, 358*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          TextButton(
                            // candidates55z (11:1742)
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Text(
                              'Candidates',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1725*ffem/fem,
                                color: Color(0x99ffffff),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 35*fem,
                          ),
                          SizedBox(
                            width: 35*fem,
                          ),
                          Text(
                            // companiesA7S (11:1743)
                            'Companies',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.1000000015*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group24tJL (88:2004)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 48.5*fem),
                      width: 50*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // mainpageiconBHS (88:1954)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // useriHN (88:1958)
                                  margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 2*fem, 18*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: double.infinity,
                                      child: Center(
                                        // ellipse3reU (88:1959)
                                        child: SizedBox(
                                          width: double.infinity,
                                          height: 47*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(23.5*fem),
                                              border: Border.all(color: Color(0xffffffff)),
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-3-bg-TS8.png',
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group259da (88:2005)
                                  width: double.infinity,
                                  height: 70*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // savedHUt (88:1960)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: TextButton(
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: 50*fem,
                                            height: 54*fem,
                                            child: Center(
                                              // 1Qt (I88:1960;72:1727;72:1636)
                                              child: SizedBox(
                                                width: 50*fem,
                                                height: 54*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/-Wfi.png',
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // likes8kQ (88:1962)
                                        left: 6.5*fem,
                                        top: 16*fem,
                                        child: Opacity(
                                          opacity: 0.9,
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(6.5*fem, 38*fem, 5*fem, 0*fem),
                                            width: 35.5*fem,
                                            height: 54*fem,
                                            child: Text(
                                              '88K',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Roboto',
                                                fontSize: 13*ffem,
                                                fontWeight: FontWeight.w900,
                                                height: 1.1725*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          TextButton(
                            // image18Bya (88:2003)
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-18-kde.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupcmpe8P2 (KweMihwpbfsKVocWxbcMPe)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                      width: double.infinity,
                      height: 121.61*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // infopme (88:2046)
                            margin: EdgeInsets.fromLTRB(0*fem, 27.5*fem, 102.5*fem, 45.11*fem),
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // fusionexgroup1289Z2 (88:2047)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                                  child: RichText(
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 17*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '@FusionexGroup',
                                        ),
                                        TextSpan(
                                          text: ' · ',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 17*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0x99ffffff),
                                          ),
                                        ),
                                        TextSpan(
                                          text: '1-28',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 15*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0x99ffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Text(
                                  // itservicesconsultingrkG (88:2048)
                                  '#IT #services #consulting',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupegb2bSx (KweMqsQZ18n2XJuaMPegB2)
                            width: 112.5*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // notes2Ysz (11:1695)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 81.55*fem,
                                      height: 113.16*fem,
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Image.asset(
                                          'assets/page-1/images/notes2-v4p.png',
                                          width: 81.55*fem,
                                          height: 113.16*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // disc2QvC (11:1696)
                                  left: 63.5*fem,
                                  top: 72.6066894531*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: 49*fem,
                                      height: 49*fem,
                                      child: Container(
                                        // frame11w9S (I11:1696;6:1415)
                                        width: double.infinity,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(24.5*fem),
                                          gradient: SweepGradient (
                                            center: Alignment(0, 0),
                                            startAngle: 1.55,
                                            endAngle: 7.83,
                                            tileMode: TileMode.repeated,
                                            colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                                            stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                                          ),
                                        ),
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // ellipse2BJg (I11:1696;6:1417)
                                              left: 5.4182128906*fem,
                                              top: 5.4183197021*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 38.16*fem,
                                                  height: 38.16*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/ellipse-2-3qr.png',
                                                    width: 38.16*fem,
                                                    height: 38.16*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // ellipse3Gqv (I11:1696;6:1418)
                                              left: 5.4182128906*fem,
                                              top: 5.4183807373*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 38.16*fem,
                                                  height: 38.16*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/ellipse-3-Si4.png',
                                                    width: 38.16*fem,
                                                    height: 38.16*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // autogroupaw6xPvY (KweN5HBsh1pw3n6byzaw6x)
                width: 889*fem,
                height: 93*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // subtract992 (31:396)
                      left: 0*fem,
                      top: 27*fem,
                      child: Align(
                        child: SizedBox(
                          width: 889*fem,
                          height: 66*fem,
                          child: Image.asset(
                            'assets/page-1/images/subtract-xoi.png',
                            width: 889*fem,
                            height: 66*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsqnY (31:397)
                      left: 23*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 60*fem,
                          height: 60*fem,
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-jwe.png',
                            width: 60*fem,
                            height: 60*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsmRJ (31:398)
                      left: 106.75*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-MUU.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsT3E (31:399)
                      left: 180.5*fem,
                      top: 40*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                          width: 40*fem,
                          height: 40*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(60*fem),
                          ),
                          child: Center(
                            // image13MPW (I31:399;78:413)
                            child: SizedBox(
                              width: 26*fem,
                              height: 26*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-13-p3J.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsJJk (31:400)
                      left: 254.25*fem,
                      top: 40*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                          width: 40*fem,
                          height: 40*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(60*fem),
                          ),
                          child: Center(
                            // image9LWL (I31:400;72:1830)
                            child: SizedBox(
                              width: 34*fem,
                              height: 31.66*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-9-LDE.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsfoW (31:401)
                      left: 328*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-YZe.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}