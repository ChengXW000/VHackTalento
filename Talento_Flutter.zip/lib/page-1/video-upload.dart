import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // videouploadbbv (6:563)
        width: double.infinity,
        height: 896*fem,
        child: Stack(
          children: [
            Positioned(
              // disc1LpQ (6:564)
              left: 277.5*fem,
              top: 692*fem,
              child: Opacity(
                opacity: 0,
                child: Container(
                  width: 137*fem,
                  height: 121*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // ellipse34FRa (6:565)
                        left: 81.5*fem,
                        top: 67.5*fem,
                        child: Align(
                          child: SizedBox(
                            width: 47*fem,
                            height: 47*fem,
                            child: Container(
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(23.5*fem),
                                color: Color(0xff181818),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // disc1mep (6:566)
                        left: 0*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 137*fem,
                            height: 121*fem,
                            child: Image.asset(
                              'assets/page-1/images/disc-1.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundeCp (6:567)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 896*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // camerawhi (6:573)
              left: 0*fem,
              top: 38*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(8*fem, 12*fem, 8*fem, 33*fem),
                width: 414*fem,
                height: 756*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(12*fem),
                  image: DecorationImage (
                    fit: BoxFit.cover,
                    image: AssetImage (
                      'assets/page-1/images/background-bg.png',
                    ),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // rectangle32PZi (6:624)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                      width: double.infinity,
                      height: 6*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(3*fem),
                        color: Color(0x19000000),
                      ),
                    ),
                    Container(
                      // autogroupfernXfv (KwdshbTztQMG8hFKuPfERN)
                      margin: EdgeInsets.fromLTRB(12*fem, 0*fem, 4.5*fem, 253*fem),
                      width: double.infinity,
                      height: 353*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // frame7riC (6:575)
                            margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 334*fem, 0*fem),
                            width: 16.5*fem,
                            height: 16.5*fem,
                            child: Image.asset(
                              'assets/page-1/images/frame-7.png',
                              width: 16.5*fem,
                              height: 16.5*fem,
                            ),
                          ),
                          Opacity(
                            // camerasettingsC1N (6:577)
                            opacity: 0.9,
                            child: Container(
                              width: 31*fem,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x33000000),
                                    offset: Offset(0*fem, 0.3300000131*fem),
                                    blurRadius: 2*fem,
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroupbvjc5qr (KwdstAzhvgUxV8JG9VbvJC)
                                    padding: EdgeInsets.fromLTRB(1*fem, 0*fem, 2*fem, 19.6*fem),
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // flip1Di (6:578)
                                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 20*fem),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // flipicon6kx (6:579)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.5*fem),
                                                width: 27*fem,
                                                height: 22*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/flip-icon.png',
                                                  width: 27*fem,
                                                  height: 22*fem,
                                                ),
                                              ),
                                              Container(
                                                // flipBGc (6:580)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                                child: Text(
                                                  'Flip',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont (
                                                    'Roboto',
                                                    fontSize: 10*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1725*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // speedV2Q (6:581)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // speediconqMA (6:582)
                                                margin: EdgeInsets.fromLTRB(1.21*fem, 0*fem, 0*fem, 6.5*fem),
                                                width: 24.21*fem,
                                                height: 24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/speed-icon.png',
                                                  width: 24.21*fem,
                                                  height: 24*fem,
                                                ),
                                              ),
                                              Text(
                                                // speedLoi (6:583)
                                                'Speed',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1725*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // beautytaL (6:584)
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // magicpeniconqEg (6:585)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.03*fem, 6.24*fem),
                                          width: 24.97*fem,
                                          height: 24.16*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/magic-pen-icon.png',
                                            width: 24.97*fem,
                                            height: 24.16*fem,
                                          ),
                                        ),
                                        Text(
                                          // beautyMTv (6:586)
                                          'Beauty',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroupfpunhXn (Kwdt2vF8is5dnUZ25dFpuN)
                                    padding: EdgeInsets.fromLTRB(1*fem, 20.5*fem, 2*fem, 0*fem),
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // filtersbdA (6:587)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20.5*fem),
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // filtersiconYoJ (6:588)
                                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 6.5*fem),
                                                width: 24*fem,
                                                height: 23*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/filters-icon.png',
                                                  width: 24*fem,
                                                  height: 23*fem,
                                                ),
                                              ),
                                              Text(
                                                // filtersGUQ (6:589)
                                                'Filters',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1725*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // timerQ4p (6:590)
                                          margin: EdgeInsets.fromLTRB(1.5*fem, 0*fem, 0.5*fem, 19.5*fem),
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // timericon9YC (6:591)
                                                margin: EdgeInsets.fromLTRB(0.58*fem, 0*fem, 0*fem, 6.5*fem),
                                                width: 22.58*fem,
                                                height: 24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/timer-icon.png',
                                                  width: 22.58*fem,
                                                  height: 24*fem,
                                                ),
                                              ),
                                              Text(
                                                // timer5Ax (6:592)
                                                'Timer',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1725*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // flashDnx (6:593)
                                          margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 1*fem, 0*fem),
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // unionMeG (6:594)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.37*fem, 6.44*fem),
                                                width: 18.63*fem,
                                                height: 24.06*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/union.png',
                                                  width: 18.63*fem,
                                                  height: 24.06*fem,
                                                ),
                                              ),
                                              Text(
                                                // flashfex (6:595)
                                                'Flash',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1725*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // camerabuttons1yi (6:599)
                      margin: EdgeInsets.fromLTRB(159*fem, 0*fem, 57.5*fem, 0*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // recordbuttonmCC (6:600)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66.5*fem, 0*fem),
                            width: 80*fem,
                            height: 80*fem,
                            child: Image.asset(
                              'assets/page-1/images/record-button.png',
                              width: 80*fem,
                              height: 80*fem,
                            ),
                          ),
                          Container(
                            // uploadh5r (6:612)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4.75*fem),
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // uploadillustrationpwA (6:613)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 6.25*fem),
                                      width: 32*fem,
                                      height: 32*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/upload-illustration.png',
                                        width: 32*fem,
                                        height: 32*fem,
                                      ),
                                    ),
                                    Text(
                                      // uploadvDW (6:623)
                                      'Upload',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 11*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // barsstatusbariphonexpJt (6:628)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                width: 414*fem,
                height: 44*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timestyleVvp (6:647)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                      padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                      height: double.infinity,
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro Text',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2575*ffem/fem,
                          letterSpacing: -0.3000000119*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // mobilesignalB2x (6:642)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                      width: 18.77*fem,
                      height: 10.67*fem,
                      child: Image.asset(
                        'assets/page-1/images/mobile-signal-LLY.png',
                        width: 18.77*fem,
                        height: 10.67*fem,
                      ),
                    ),
                    Container(
                      // wifiJ7a (6:638)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                      width: 16.86*fem,
                      height: 10.97*fem,
                      child: Image.asset(
                        'assets/page-1/images/wifi-56g.png',
                        width: 16.86*fem,
                        height: 10.97*fem,
                      ),
                    ),
                    Container(
                      // batteryc8G (6:630)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                      width: 24.5*fem,
                      height: 10.5*fem,
                      child: Image.asset(
                        'assets/page-1/images/battery-EsJ.png',
                        width: 24.5*fem,
                        height: 10.5*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // bottomnavjTn (25:2297)
              left: 0*fem,
              top: 803*fem,
              child: Container(
                width: 889*fem,
                height: 93*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // subtractsK6 (I25:2297;25:2328)
                      left: 0*fem,
                      top: 27*fem,
                      child: Align(
                        child: SizedBox(
                          width: 889*fem,
                          height: 66*fem,
                          child: Image.asset(
                            'assets/page-1/images/subtract-guW.png',
                            width: 889*fem,
                            height: 66*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsBKn (I25:2297;25:2329)
                      left: 42*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-Z1r.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsq9S (I25:2297;25:2330)
                      left: 115.75*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-vwr.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconskXJ (I25:2297;25:2331)
                      left: 189.5*fem,
                      top: 40*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                          width: 40*fem,
                          height: 40*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(60*fem),
                          ),
                          child: Center(
                            // image13Cu6 (I25:2297;25:2331;78:413)
                            child: SizedBox(
                              width: 26*fem,
                              height: 26*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-13-aTJ.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconskfi (I25:2297;25:2332)
                      left: 263.25*fem,
                      top: 40*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                          width: 40*fem,
                          height: 40*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(60*fem),
                          ),
                          child: Center(
                            // image927S (I25:2297;25:2332;72:1830)
                            child: SizedBox(
                              width: 34*fem,
                              height: 31.66*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-9-tNc.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsNBJ (I25:2297;25:2333)
                      left: 326*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 60*fem,
                          height: 60*fem,
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-712.png',
                            width: 60*fem,
                            height: 60*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}