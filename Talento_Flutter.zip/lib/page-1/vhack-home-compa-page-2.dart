import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // vhackhomecompapage2cnC (18:2002)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration (
            color: Color(0xffc4c4c4),
            image: DecorationImage (
              fit: BoxFit.cover,
              image: AssetImage (
                'assets/page-1/images/background-bg-xLg.png',
              ),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                // vhackpage3tUp (18:2058)
                padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                width: double.infinity,
                height: 44*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timestyleD1J (18:2077)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                      padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                      height: double.infinity,
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro Text',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2575*ffem/fem,
                          letterSpacing: -0.3000000119*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // mobilesignalSPr (18:2072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                      width: 18.77*fem,
                      height: 10.67*fem,
                      child: Image.asset(
                        'assets/page-1/images/mobile-signal-rqn.png',
                        width: 18.77*fem,
                        height: 10.67*fem,
                      ),
                    ),
                    Container(
                      // wifiLVE (18:2068)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                      width: 16.86*fem,
                      height: 10.97*fem,
                      child: Image.asset(
                        'assets/page-1/images/wifi-9dr.png',
                        width: 16.86*fem,
                        height: 10.97*fem,
                      ),
                    ),
                    Container(
                      // battery3eY (18:2060)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                      width: 24.5*fem,
                      height: 10.5*fem,
                      child: Image.asset(
                        'assets/page-1/images/battery-nw2.png',
                        width: 24.5*fem,
                        height: 10.5*fem,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // autogroup2uhnvyE (KweFgxpv2pZu8FP3Ys2UHN)
                padding: EdgeInsets.fromLTRB(12*fem, 11*fem, 5*fem, 9.89*fem),
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      // header55S (31:381)
                      margin: EdgeInsets.fromLTRB(81*fem, 0*fem, 82*fem, 359*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          TextButton(
                            // candidatesbJg (31:382)
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Text(
                              'Candidates',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1725*ffem/fem,
                                color: Color(0x99ffffff),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 35*fem,
                          ),
                          SizedBox(
                            width: 35*fem,
                          ),
                          Text(
                            // companiesh6p (31:384)
                            'Companies',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.1000000015*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group24ovY (94:2407)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 48.5*fem),
                      width: 50*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // mainpageiconKP6 (94:2408)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // user34C (94:2409)
                                  margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 2*fem, 18*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: double.infinity,
                                      child: Center(
                                        // ellipse3kUQ (94:2410)
                                        child: SizedBox(
                                          width: double.infinity,
                                          height: 47*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(23.5*fem),
                                              border: Border.all(color: Color(0xffffffff)),
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-3-bg-diG.png',
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group25sov (94:2411)
                                  width: double.infinity,
                                  height: 70*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // savedcWc (94:2412)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: TextButton(
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: 50*fem,
                                            height: 54*fem,
                                            child: Center(
                                              // V4c (I94:2412;72:1727;72:1636)
                                              child: SizedBox(
                                                width: 50*fem,
                                                height: 54*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/-vg8.png',
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // likesdgc (94:2413)
                                        left: 6.5*fem,
                                        top: 16*fem,
                                        child: Opacity(
                                          opacity: 0.9,
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(6.5*fem, 38*fem, 5*fem, 0*fem),
                                            width: 35.5*fem,
                                            height: 54*fem,
                                            child: Text(
                                              '88K',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Roboto',
                                                fontSize: 13*ffem,
                                                fontWeight: FontWeight.w900,
                                                height: 1.1725*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          TextButton(
                            // image18hwN (94:2418)
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-18-SuW.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupvbvyFT6 (KweFB4X5A5hq832R8XVBvY)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                      width: double.infinity,
                      height: 121.61*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // infomRS (94:2555)
                            margin: EdgeInsets.fromLTRB(0*fem, 27.5*fem, 20.5*fem, 45.11*fem),
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // hilti1285wv (94:2556)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                                  child: RichText(
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 17*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '@Hilti',
                                        ),
                                        TextSpan(
                                          text: ' · ',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 17*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0x99ffffff),
                                          ),
                                        ),
                                        TextSpan(
                                          text: '1-28',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 15*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0x99ffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Text(
                                  // constructionengineeringsoftwar (94:2557)
                                  '#construction #engineering #software',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupqiqgyxk (KweFJ4KQzdPAxiRpgEQiQg)
                            width: 112.5*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // notes2jBE (18:2005)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 81.55*fem,
                                      height: 113.16*fem,
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Image.asset(
                                          'assets/page-1/images/notes2-t6t.png',
                                          width: 81.55*fem,
                                          height: 113.16*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // disc2D6Q (18:2006)
                                  left: 63.5*fem,
                                  top: 72.6066894531*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: 49*fem,
                                      height: 49*fem,
                                      child: Container(
                                        // frame11oaQ (I18:2006;6:1415)
                                        width: double.infinity,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(24.5*fem),
                                          gradient: SweepGradient (
                                            center: Alignment(0, 0),
                                            startAngle: 1.55,
                                            endAngle: 7.83,
                                            tileMode: TileMode.repeated,
                                            colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                                            stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                                          ),
                                        ),
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // ellipse24FS (I18:2006;6:1417)
                                              left: 5.4182128906*fem,
                                              top: 5.4183349609*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 38.16*fem,
                                                  height: 38.16*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/ellipse-2-BzY.png',
                                                    width: 38.16*fem,
                                                    height: 38.16*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // ellipse3wa8 (I18:2006;6:1418)
                                              left: 5.4182128906*fem,
                                              top: 5.4183349609*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 38.16*fem,
                                                  height: 38.16*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/ellipse-3-kHW.png',
                                                    width: 38.16*fem,
                                                    height: 38.16*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // autogroupazncqvQ (KweFVoUr1L8RcviKqxAzNC)
                width: 889*fem,
                height: 93*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // subtractb8t (31:428)
                      left: 0*fem,
                      top: 27*fem,
                      child: Align(
                        child: SizedBox(
                          width: 889*fem,
                          height: 66*fem,
                          child: Image.asset(
                            'assets/page-1/images/subtract-Py2.png',
                            width: 889*fem,
                            height: 66*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsijJ (31:429)
                      left: 23*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 60*fem,
                          height: 60*fem,
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-w4U.png',
                            width: 60*fem,
                            height: 60*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconspnL (31:430)
                      left: 106.75*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-R3E.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnavicons5CU (31:431)
                      left: 180.5*fem,
                      top: 40*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                          width: 40*fem,
                          height: 40*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(60*fem),
                          ),
                          child: Center(
                            // image13af2 (I31:431;78:413)
                            child: SizedBox(
                              width: 26*fem,
                              height: 26*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-13-Afa.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsXqA (31:432)
                      left: 254.25*fem,
                      top: 40*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                          width: 40*fem,
                          height: 40*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(60*fem),
                          ),
                          child: Center(
                            // image9P6g (I31:432;72:1830)
                            child: SizedBox(
                              width: 34*fem,
                              height: 31.66*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-9-MMa.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsjRS (31:433)
                      left: 328*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-KAG.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}