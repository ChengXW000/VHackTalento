import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // candiprofile39Pn (80:1372)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroup5ywjTfN (KwePfehdPv6z3dQvnR5YwJ)
              width: double.infinity,
              height: 384*fem,
              child: Stack(
                children: [
                  Positioned(
                    // topbarLz4 (80:1374)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 414*fem,
                      height: 87.67*fem,
                      child: Center(
                        // background6CY (80:1375)
                        child: SizedBox(
                          width: double.infinity,
                          height: 87.67*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0xffd0d1d3),
                                  offset: Offset(0*fem, 0.3300000131*fem),
                                  blurRadius: 0*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // backgroundpicPSY (80:1376)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 249*fem,
                        child: Image.asset(
                          'assets/page-1/images/background-pic.png',
                          width: 414*fem,
                          height: 249*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // barsstatusbariphonex77e (80:1379)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                      width: 414*fem,
                      height: 44*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timestyleYye (80:1398)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                            height: double.infinity,
                            child: Text(
                              '9:41',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'SF Pro Text',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2575*ffem/fem,
                                letterSpacing: -0.3000000119*fem,
                                color: Color(0xff171717),
                              ),
                            ),
                          ),
                          Container(
                            // mobilesignalbBE (80:1393)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                            width: 18.77*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/mobile-signal-prU.png',
                              width: 18.77*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // wifi7QU (80:1389)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                            width: 16.86*fem,
                            height: 10.97*fem,
                            child: Image.asset(
                              'assets/page-1/images/wifi-atY.png',
                              width: 16.86*fem,
                              height: 10.97*fem,
                            ),
                          ),
                          Container(
                            // batterycs2 (80:1381)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                            width: 24.5*fem,
                            height: 10.5*fem,
                            child: Image.asset(
                              'assets/page-1/images/battery-1hz.png',
                              width: 24.5*fem,
                              height: 10.5*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // back84g (80:1400)
                    left: 18*fem,
                    top: 48*fem,
                    child: Align(
                      child: SizedBox(
                        width: 22*fem,
                        height: 16.04*fem,
                        child: Image.asset(
                          'assets/page-1/images/back.png',
                          width: 22*fem,
                          height: 16.04*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // profilebox3xL (80:1403)
                    left: 11*fem,
                    top: 118*fem,
                    child: Align(
                      child: SizedBox(
                        width: 393*fem,
                        height: 265*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(33*fem),
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x2d30007e),
                                offset: Offset(0*fem, 10*fem),
                                blurRadius: 25*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // profilepickrk (80:1404)
                    left: 159*fem,
                    top: 70*fem,
                    child: Align(
                      child: SizedBox(
                        width: 95*fem,
                        height: 95*fem,
                        child: Image.asset(
                          'assets/page-1/images/profile-pic.png',
                          width: 95*fem,
                          height: 95*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // currentlyastudentpursuingcompu (80:1407)
                    left: 51*fem,
                    top: 202*fem,
                    child: Align(
                      child: SizedBox(
                        width: 316*fem,
                        height: 46*fem,
                        child: Text(
                          'Currently a student pursuing Computer and Communication System Engineering in University Putra Malaysia. Passionate about technology, science, engineering and investing.',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w300,
                            height: 1.2625480036*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // samuelchengf6Y (80:1408)
                    left: 142*fem,
                    top: 170*fem,
                    child: Align(
                      child: SizedBox(
                        width: 131*fem,
                        height: 24*fem,
                        child: Text(
                          'Samuel Cheng',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // followboxy7E (80:1410)
                    left: 224*fem,
                    top: 319*fem,
                    child: Align(
                      child: SizedBox(
                        width: 168*fem,
                        height: 45*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0xff084fff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group113rB2 (116:792)
                    left: 36*fem,
                    top: 319*fem,
                    child: Container(
                      width: 168*fem,
                      height: 45*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff084fff),
                        borderRadius: BorderRadius.circular(12*fem),
                      ),
                      child: Center(
                        child: Text(
                          'Resume',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.8*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // followuf6 (80:1412)
                    left: 276*fem,
                    top: 330*fem,
                    child: Align(
                      child: SizedBox(
                        width: 64*fem,
                        height: 24*fem,
                        child: Text(
                          'Follow',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.8*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // linksPaG (80:1446)
                    left: 111*fem,
                    top: 259*fem,
                    child: Container(
                      width: 193*fem,
                      height: 45*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group14Kyi (80:1448)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // image15Tq2 (80:1450)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-15-5tk.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 29*fem,
                          ),
                          Container(
                            // group16AzL (80:1451)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // instagramicon1Hp4 (80:1453)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/instagramicon-1-ePA.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 29*fem,
                          ),
                          Container(
                            // group17aoA (80:1454)
                            padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffe8e5f2),
                              borderRadius: BorderRadius.circular(12*fem),
                            ),
                            child: Center(
                              // image1672Q (80:1456)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-16-4Jc.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouperdiFeQ (KweQCJVDpnWCPZGzWeeRdi)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
              width: double.infinity,
              height: 502*fem,
              child: Stack(
                children: [
                  Positioned(
                    // following1B2G (80:1413)
                    left: 151*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(22.5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/following-1-bg.png',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // following2GZW (80:1414)
                    left: 220*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(22.5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/following-2-bg.png',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // following3uMa (80:1415)
                    left: 285*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(22.5*fem),
                              border: Border.all(color: Color(0xff000000)),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/following-3-bg.png',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // following4cFz (80:1416)
                    left: 351*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(22.5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/following-4-bg.png',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // gallerypicT1i (80:1417)
                    left: 150*fem,
                    top: 124*fem,
                    child: Container(
                      width: 250*fem,
                      height: 377*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupkebaPAG (KweQWD93qSmxxKWdzdkEbA)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11.58*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle66qN (80:1418)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.62*fem, 0*fem),
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-6-1XW.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // rectangle7SPS (80:1421)
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-7-8At.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogrouppaf2bGL (KweQbHpv9SJc9WB3Jppaf2)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11.58*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle8jdS (80:1419)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.62*fem, 0*fem),
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-8-JwJ.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // rectangle9dip (80:1422)
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-9-snG.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupc8ws9hA (KweQfNYT3vT4DjVXYVC8wS)
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle10uwE (80:1420)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.62*fem, 0*fem),
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-10-RfN.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // rectangle11edv (80:1423)
                                  width: 120.69*fem,
                                  height: 117.94*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle-11-ESt.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // gallerybZA (80:1425)
                    left: 147*fem,
                    top: 96*fem,
                    child: Align(
                      child: SizedBox(
                        width: 57*fem,
                        height: 22*fem,
                        child: Text(
                          'Gallery',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // dataGvC (80:1426)
                    left: 11*fem,
                    top: 6*fem,
                    child: Container(
                      width: 129*fem,
                      height: 214*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(21*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x26000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 15*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group10aR6 (80:1427)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(21*fem),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // group18hkc (80:1428)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(28*fem, 71.67*fem, 26*fem, 69.67*fem),
                                width: 129*fem,
                                height: 214*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfff8f9fc),
                                  borderRadius: BorderRadius.circular(21*fem),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // line16Gx (80:1431)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 70.67*fem),
                                      width: 73*fem,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xb2979797),
                                      ),
                                    ),
                                    Container(
                                      // line2ox4 (80:1430)
                                      margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                      width: 73*fem,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xb2979797),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // savesZAY (80:1432)
                              left: 49.5*fem,
                              top: 29.0678710938*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 34*fem,
                                  height: 39*fem,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 24*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.0918749173*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '888\n',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.3102499008*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'Saves',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 11*ffem,
                                            fontWeight: FontWeight.w300,
                                            height: 1.0918749896*ffem/fem,
                                            letterSpacing: 0.055*fem,
                                            color: Color(0xff959595),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // followers8Fa (80:1434)
                              left: 41*fem,
                              top: 159*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 48*fem,
                                  height: 37*fem,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 18*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.171875*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '0\n',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'Followers',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 11*ffem,
                                            fontWeight: FontWeight.w300,
                                            height: 1.1725*ffem/fem,
                                            letterSpacing: 0.055*fem,
                                            color: Color(0xff959595),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // kfollowingc4G (80:1545)
                              left: 42.5*fem,
                              top: 89*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 47*fem,
                                  height: 37*fem,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 18*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.171875*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '10K\n',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'Following',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 11*ffem,
                                            fontWeight: FontWeight.w300,
                                            height: 1.1725*ffem/fem,
                                            letterSpacing: 0.055*fem,
                                            color: Color(0xff959595),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // linksGHE (80:1435)
                    left: 11*fem,
                    top: 242*fem,
                    child: Container(
                      width: 129*fem,
                      height: 164*fem,
                      decoration: BoxDecoration (
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x26000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 15*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group10Buz (80:1436)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(21*fem),
                        ),
                        child: Container(
                          // group189rp (80:1437)
                          padding: EdgeInsets.fromLTRB(42*fem, 25*fem, 40*fem, 29*fem),
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff8f9fc),
                            borderRadius: BorderRadius.circular(21*fem),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group20oAg (80:1443)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 20*fem),
                                padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                                decoration: BoxDecoration (
                                  color: Color(0xffe8e5f2),
                                  borderRadius: BorderRadius.circular(12*fem),
                                ),
                                child: Center(
                                  // image177x4 (80:1445)
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-17-LNU.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group18U1v (80:1439)
                                margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 5*fem, 5*fem),
                                decoration: BoxDecoration (
                                  color: Color(0xffe8e5f2),
                                  borderRadius: BorderRadius.circular(12*fem),
                                ),
                                child: Center(
                                  // image16zW4 (80:1441)
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 35*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-16-2ba.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // background984 (80:1457)
                    left: 0*fem,
                    top: 470*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 32*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xffd0d1d3),
                                offset: Offset(0*fem, -0.3300000131*fem),
                                blurRadius: 0*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // following2he (116:749)
                    left: 150*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 78*fem,
                        height: 22*fem,
                        child: Text(
                          'Following',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}