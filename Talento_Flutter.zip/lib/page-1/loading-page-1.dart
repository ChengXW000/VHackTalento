import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // loadingpage1KvG (100:3251)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          height: 896*fem,
          child: Stack(
            children: [
              Positioned(
                // topbarcuN (100:3253)
                left: 0*fem,
                top: 0*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18.67*fem),
                  width: 414*fem,
                  height: 87.67*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffffffff),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xffd0d1d3),
                        offset: Offset(0*fem, 0.3300000131*fem),
                        blurRadius: 0*fem,
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // barsstatusbariphonexqGL (100:3258)
                        padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                        width: double.infinity,
                        height: 44*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // timestyle928 (100:3277)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                              padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                              height: double.infinity,
                              child: Text(
                                '9:41',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'SF Pro Text',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.2575*ffem/fem,
                                  letterSpacing: -0.3000000119*fem,
                                  color: Color(0xff171717),
                                ),
                              ),
                            ),
                            Container(
                              // mobilesignalZLk (100:3272)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                              width: 18.77*fem,
                              height: 10.67*fem,
                              child: Image.asset(
                                'assets/page-1/images/mobile-signal-EUx.png',
                                width: 18.77*fem,
                                height: 10.67*fem,
                              ),
                            ),
                            Container(
                              // wifigAU (100:3268)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                              width: 16.86*fem,
                              height: 10.97*fem,
                              child: Image.asset(
                                'assets/page-1/images/wifi-aic.png',
                                width: 16.86*fem,
                                height: 10.97*fem,
                              ),
                            ),
                            Container(
                              // batterynDW (100:3260)
                              margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                              width: 24.5*fem,
                              height: 10.5*fem,
                              child: Image.asset(
                                'assets/page-1/images/battery-aHn.png',
                                width: 24.5*fem,
                                height: 10.5*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // group8Vtc (100:3279)
                        margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 18*fem, 0*fem),
                        width: double.infinity,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // vectorS3A (100:3280)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 331*fem, 0.96*fem),
                              width: 22*fem,
                              height: 16.04*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-DJY.png',
                                width: 22*fem,
                                height: 16.04*fem,
                              ),
                            ),
                            Container(
                              // vectorAE4 (100:3281)
                              width: 25*fem,
                              height: 25*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-fnp.png',
                                width: 25*fem,
                                height: 25*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // loadingpageWHv (170:667)
                left: 0*fem,
                top: 0*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 398*fem),
                  width: 428*fem,
                  height: 911*fem,
                  decoration: BoxDecoration (
                    color: Color(0xfffffdde),
                    borderRadius: BorderRadius.circular(30*fem),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // headernFS (170:669)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 233*fem),
                        padding: EdgeInsets.fromLTRB(164*fem, 0*fem, 164*fem, 0*fem),
                        width: double.infinity,
                        height: 180*fem,
                        child: Align(
                          // untitleddesign1uL4 (170:670)
                          alignment: Alignment.topCenter,
                          child: SizedBox(
                            width: 100*fem,
                            height: 100*fem,
                            child: Image.asset(
                              'assets/page-1/images/untitled-design-1-oLL.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        // untitleddesign11phv (170:668)
                        width: 100*fem,
                        height: 100*fem,
                        child: Image.asset(
                          'assets/page-1/images/untitled-design-1-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // backgroundkrU (100:3336)
                left: 0*fem,
                top: 864*fem,
                child: Align(
                  child: SizedBox(
                    width: 414*fem,
                    height: 32*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xffd0d1d3),
                            offset: Offset(0*fem, -0.3300000131*fem),
                            blurRadius: 0*fem,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // barsstatusbariphonexjCc (157:623)
                left: 0*fem,
                top: 0*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                  width: 414*fem,
                  height: 44*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // timestylepE4 (157:642)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                        padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                        height: double.infinity,
                        child: Text(
                          '9:41',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'SF Pro Text',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.2575*ffem/fem,
                            letterSpacing: -0.3000000119*fem,
                            color: Color(0xff171717),
                          ),
                        ),
                      ),
                      Container(
                        // mobilesignalHdS (157:637)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                        width: 18.77*fem,
                        height: 10.67*fem,
                        child: Image.asset(
                          'assets/page-1/images/mobile-signal-RT6.png',
                          width: 18.77*fem,
                          height: 10.67*fem,
                        ),
                      ),
                      Container(
                        // wifiorg (157:633)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                        width: 16.86*fem,
                        height: 10.97*fem,
                        child: Image.asset(
                          'assets/page-1/images/wifi-Jjz.png',
                          width: 16.86*fem,
                          height: 10.97*fem,
                        ),
                      ),
                      Container(
                        // battery8tx (157:625)
                        margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                        width: 24.5*fem,
                        height: 10.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/battery-8i4.png',
                          width: 24.5*fem,
                          height: 10.5*fem,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // backgroundSek (157:644)
                left: 0*fem,
                top: 864*fem,
                child: Align(
                  child: SizedBox(
                    width: 417*fem,
                    height: 32*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xffd0d1d3),
                            offset: Offset(0*fem, -0.3300000131*fem),
                            blurRadius: 0*fem,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}