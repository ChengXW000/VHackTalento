import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // vhacksavedcandipage1ThJ (94:2807)
        width: double.infinity,
        height: 896*fem,
        decoration: BoxDecoration (
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/gif1-bg.png',
            ),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // notes82k (94:2809)
              left: 292.5*fem,
              top: 676.5*fem,
              child: Align(
                child: SizedBox(
                  width: 81.55*fem,
                  height: 113.16*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/notes.png',
                      width: 81.55*fem,
                      height: 113.16*fem,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // discPUU (94:2810)
              left: 358.40625*fem,
              top: 749.106628418*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 49*fem,
                  height: 49*fem,
                  child: Container(
                    // frame11X4t (I94:2810;6:1398)
                    padding: EdgeInsets.fromLTRB(5.42*fem, 5.42*fem, 5.42*fem, 5.42*fem),
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24.5*fem),
                      gradient: SweepGradient (
                        center: Alignment(0, 0),
                        startAngle: 1.55,
                        endAngle: 7.83,
                        tileMode: TileMode.repeated,
                        colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                        stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                      ),
                    ),
                    child: Center(
                      // ellipse2NrC (I94:2810;6:1400)
                      child: SizedBox(
                        width: 38.16*fem,
                        height: 38.16*fem,
                        child: Image.asset(
                          'assets/page-1/images/ellipse-2-ZAY.png',
                          width: 38.16*fem,
                          height: 38.16*fem,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // infoJzk (94:2811)
              left: 12*fem,
              top: 701*fem,
              child: Container(
                width: 177*fem,
                height: 52*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // jonnykim128RJg (94:2814)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                      child: RichText(
                        text: TextSpan(
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 17*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1725*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                          children: [
                            TextSpan(
                              text: '@Jonny Kim',
                            ),
                            TextSpan(
                              text: ' · ',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 17*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1725*ffem/fem,
                                color: Color(0x99ffffff),
                              ),
                            ),
                            TextSpan(
                              text: '1-28',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1725*ffem/fem,
                                color: Color(0x99ffffff),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      // autogroupmzj2w44 (Kwe9yTgccTzyh7AXKHmzj2)
                      width: double.infinity,
                      height: 20*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // mdusnavyastronautFqS (94:2813)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 177*fem,
                                height: 20*fem,
                                child: Text(
                                  '#MD #USNavy #Astronaut',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ZbE (94:2815)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 9*fem,
                                height: 20*fem,
                                child: Text(
                                  '#',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // headerTwW (94:2816)
              left: 90*fem,
              top: 56*fem,
              child: Container(
                width: 234*fem,
                height: 19*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      // candidatesnD6 (94:2817)
                      'Candidates',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                    SizedBox(
                      width: 35*fem,
                    ),
                    SizedBox(
                      width: 35*fem,
                    ),
                    TextButton(
                      // companieseFJ (94:2819)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Text(
                        'Companies',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0x99ffffff),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // barsstatusbariphonexZ7N (94:2820)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                width: 414*fem,
                height: 44*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timestyleRvG (94:2839)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                      padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                      height: double.infinity,
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro Text',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2575*ffem/fem,
                          letterSpacing: -0.3000000119*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // mobilesignalKVr (94:2834)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                      width: 18.77*fem,
                      height: 10.67*fem,
                      child: Image.asset(
                        'assets/page-1/images/mobile-signal-Egx.png',
                        width: 18.77*fem,
                        height: 10.67*fem,
                      ),
                    ),
                    Container(
                      // wifiEMv (94:2830)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                      width: 16.86*fem,
                      height: 10.97*fem,
                      child: Image.asset(
                        'assets/page-1/images/wifi-JtQ.png',
                        width: 16.86*fem,
                        height: 10.97*fem,
                      ),
                    ),
                    Container(
                      // batteryint (94:2822)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                      width: 24.5*fem,
                      height: 10.5*fem,
                      child: Image.asset(
                        'assets/page-1/images/battery-tt8.png',
                        width: 24.5*fem,
                        height: 10.5*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // mainpageiconFH2 (94:2843)
              left: 359*fem,
              top: 433*fem,
              child: Container(
                width: 50*fem,
                height: 272*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // uservPA (94:2847)
                      margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 2*fem, 18*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: double.infinity,
                          child: Center(
                            // ellipse3ScQ (94:2848)
                            child: SizedBox(
                              width: double.infinity,
                              height: 47*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(23.5*fem),
                                  border: Border.all(color: Color(0xffffffff)),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/ellipse-3-bg-VNQ.png',
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // autogroupforay6Y (KweAHnVR3RMADw8JQzfoRa)
                      width: double.infinity,
                      height: 70*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // saved7yS (94:2849)
                            left: 0*fem,
                            top: 0*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: 50*fem,
                                height: 54*fem,
                                child: Center(
                                  // fVA (I94:2849;72:1727;72:1636)
                                  child: SizedBox(
                                    width: 50*fem,
                                    height: 54*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/-BkC.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // likesZKe (94:2851)
                            left: 6.5*fem,
                            top: 16*fem,
                            child: Opacity(
                              opacity: 0.9,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(2.5*fem, 38*fem, 2*fem, 0*fem),
                                width: 35.5*fem,
                                height: 54*fem,
                                child: Text(
                                  '100K',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupvh1ac32 (KweAUCMjWnFVPYHap1Vh1A)
                      padding: EdgeInsets.fromLTRB(2*fem, 7*fem, 3*fem, 0*fem),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // image10u28 (94:2850)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18*fem),
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: 45*fem,
                                height: 45*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-10.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // image11DHi (94:2856)
                            margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 11*fem),
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: 40*fem,
                                height: 40*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-11.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // chatJ4G (94:2846)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                            child: Text(
                              'Chat',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1725*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // bottomnav2FA (94:3125)
              left: 0*fem,
              top: 803*fem,
              child: Container(
                width: 889*fem,
                height: 93*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // subtract8Z6 (I94:3125;25:2321)
                      left: 0*fem,
                      top: 27*fem,
                      child: Align(
                        child: SizedBox(
                          width: 889*fem,
                          height: 66*fem,
                          child: Image.asset(
                            'assets/page-1/images/subtract-hdr.png',
                            width: 889*fem,
                            height: 66*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnavicons4he (I94:3125;25:2322)
                      left: 39*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-5uz.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnaviconsK7n (I94:3125;25:2323)
                      left: 112.75*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-oTv.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnavicons1mJ (I94:3125;25:2324)
                      left: 186.5*fem,
                      top: 40*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                          width: 40*fem,
                          height: 40*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(60*fem),
                          ),
                          child: Center(
                            // image13JEc (I94:3125;25:2324;78:413)
                            child: SizedBox(
                              width: 26*fem,
                              height: 26*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-13-YXA.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnavicons3hz (I94:3125;25:2325)
                      left: 251*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(7*fem, 8*fem, 8*fem, 7*fem),
                        width: 60*fem,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(30*fem),
                        ),
                        child: Center(
                          // k6c (I94:3125;25:2325;72:1854)
                          child: SizedBox(
                            width: 45*fem,
                            height: 45*fem,
                            child: Image.asset(
                              'assets/page-1/images/-nzk.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bottomnavicons6AU (I94:3125;25:2326)
                      left: 334*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-Y8G.png',
                              width: 40*fem,
                              height: 40*fem,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}