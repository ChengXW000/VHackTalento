import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 386;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // notesAhW (6:1434)
        padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 20*fem, 20*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff7b61ff)),
          borderRadius: BorderRadius.circular(5*fem),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // property1default53n (6:1435)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 77*fem,
                  height: 107*fem,
                  child: Image.asset(
                    'assets/page-1/images/property-1default-fpC.png',
                    width: 77*fem,
                    height: 107*fem,
                  ),
                ),
              ),
            ),
            Container(
              // property1defaultMmz (6:1443)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 77*fem,
                  height: 107*fem,
                  child: Image.asset(
                    'assets/page-1/images/property-1default-hHJ.png',
                    width: 77*fem,
                    height: 107*fem,
                  ),
                ),
              ),
            ),
            Container(
              // property1defaultcC8 (6:1451)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 77*fem,
                  height: 107*fem,
                  child: Image.asset(
                    'assets/page-1/images/property-1default-ns2.png',
                    width: 77*fem,
                    height: 107*fem,
                  ),
                ),
              ),
            ),
            TextButton(
              // property1defaultK6Y (6:1459)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 77*fem,
                height: 107*fem,
                child: Image.asset(
                  'assets/page-1/images/property-1default.png',
                  width: 77*fem,
                  height: 107*fem,
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}