import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // chatcandi29Lc (78:669)
        width: double.infinity,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.only (
            topLeft: Radius.circular(8*fem),
            topRight: Radius.circular(8*fem),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupqwag3Rz (KweWq2bqaNCKxWXVeuqwAg)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.33*fem),
              width: double.infinity,
              height: 571*fem,
              decoration: BoxDecoration (
                color: Color(0xfff5f5f4),
                borderRadius: BorderRadius.only (
                  topLeft: Radius.circular(8*fem),
                  topRight: Radius.circular(8*fem),
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // chatSyv (78:672)
                    left: 192*fem,
                    top: 12*fem,
                    child: Align(
                      child: SizedBox(
                        width: 28*fem,
                        height: 16*fem,
                        child: Text(
                          'Chat',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 13*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff161722),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame3wvg (78:673)
                    left: 385.25*fem,
                    top: 15.25*fem,
                    child: Align(
                      child: SizedBox(
                        width: 9.5*fem,
                        height: 9.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/frame-3-BSp.png',
                          width: 9.5*fem,
                          height: 9.5*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // backgroundsJY (78:680)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 414*fem,
                        height: 571*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xfff5f5f4),
                            borderRadius: BorderRadius.only (
                              topLeft: Radius.circular(8*fem),
                              topRight: Radius.circular(8*fem),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // chatYvU (78:682)
                    left: 192*fem,
                    top: 12*fem,
                    child: Align(
                      child: SizedBox(
                        width: 28*fem,
                        height: 16*fem,
                        child: Text(
                          'Chat',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 13*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff161722),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame7pNC (78:683)
                    left: 385.25*fem,
                    top: 15.25*fem,
                    child: Align(
                      child: SizedBox(
                        width: 9.5*fem,
                        height: 9.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/frame-7-3bW.png',
                          width: 9.5*fem,
                          height: 9.5*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // bottombar7cC (78:675)
              width: double.infinity,
              height: 82.67*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0xffd0d1d3),
                    offset: Offset(0*fem, -0.3300000131*fem),
                    blurRadius: 0*fem,
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Positioned(
                    // typemessagebnG (78:677)
                    left: 18*fem,
                    top: 14.6700439453*fem,
                    child: Align(
                      child: SizedBox(
                        width: 113*fem,
                        height: 18*fem,
                        child: Text(
                          'Type Message ...',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff86878b),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // emojistrokeicongYp (78:678)
                    left: 375.0620117188*fem,
                    top: 15.1700439453*fem,
                    child: Align(
                      child: SizedBox(
                        width: 22*fem,
                        height: 22*fem,
                        child: Image.asset(
                          'assets/page-1/images/emoji-stroke-icon-aYG.png',
                          width: 22*fem,
                          height: 22*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // adsignstrokeiconcBa (78:679)
                    left: 331*fem,
                    top: 15.1700439453*fem,
                    child: Align(
                      child: SizedBox(
                        width: 22*fem,
                        height: 22*fem,
                        child: Image.asset(
                          'assets/page-1/images/ad-sign-stroke-icon-aAt.png',
                          width: 22*fem,
                          height: 22*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottombar78L (78:685)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(18*fem, 14.67*fem, 16.94*fem, 14.67*fem),
                      width: 414*fem,
                      height: 82.67*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xffd0d1d3),
                            offset: Offset(0*fem, -0.3300000131*fem),
                            blurRadius: 0*fem,
                          ),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // typemessageNKA (78:687)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 200*fem, 0*fem),
                            child: Text(
                              'Type Message ...',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1725*ffem/fem,
                                color: Color(0xff86878b),
                              ),
                            ),
                          ),
                          Container(
                            // adsignstrokeicontHW (78:689)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 22.06*fem, 0*fem),
                            width: 22*fem,
                            height: 22*fem,
                            child: Image.asset(
                              'assets/page-1/images/ad-sign-stroke-icon-hbN.png',
                              width: 22*fem,
                              height: 22*fem,
                            ),
                          ),
                          Container(
                            // emojistrokeiconntg (78:688)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                            width: 22*fem,
                            height: 22*fem,
                            child: Image.asset(
                              'assets/page-1/images/emoji-stroke-icon-FNQ.png',
                              width: 22*fem,
                              height: 22*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}