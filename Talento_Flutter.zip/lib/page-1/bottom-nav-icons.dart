import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 200;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // bottomnaviconshaG (25:2224)
        width: double.infinity,
        height: 403*fem,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff7b61ff)),
          borderRadius: BorderRadius.circular(5*fem),
        ),
        child: Stack(
          children: [
            Positioned(
              // namehomeiconselectednocx8 (25:2225)
              left: 133*fem,
              top: 22*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 40*fem,
                  child: Image.asset(
                    'assets/page-1/images/namehome-icon-selectedno.png',
                    width: 40*fem,
                    height: 40*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // nameprofileiconselectednost4 (25:2227)
              left: 133*fem,
              top: 96*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 40*fem,
                  child: Image.asset(
                    'assets/page-1/images/nameprofile-icon-selectedno.png',
                    width: 40*fem,
                    height: 40*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // namefaviconselectednoKzx (25:2229)
              left: 133*fem,
              top: 171*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                width: 40*fem,
                height: 40*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(60*fem),
                ),
                child: Center(
                  // image9E6L (72:1830)
                  child: SizedBox(
                    width: 34*fem,
                    height: 31.66*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-9-kjz.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // namemusiciconselectednoxo2 (25:2231)
              left: 133*fem,
              top: 246*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                width: 40*fem,
                height: 40*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(60*fem),
                ),
                child: Center(
                  // image13TDz (78:413)
                  child: SizedBox(
                    width: 26*fem,
                    height: 26*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-13.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // namevideoiconselectednozji (25:2233)
              left: 133*fem,
              top: 322*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 40*fem,
                  child: Image.asset(
                    'assets/page-1/images/namevideo-icon-selectedno.png',
                    width: 40*fem,
                    height: 40*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // namehomeiconselectedyes5FN (25:2235)
              left: 20*fem,
              top: 12*fem,
              child: Align(
                child: SizedBox(
                  width: 60*fem,
                  height: 60*fem,
                  child: Image.asset(
                    'assets/page-1/images/namehome-icon-selectedyes.png',
                    width: 60*fem,
                    height: 60*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // nameprofileiconselectedyesQ2k (25:2239)
              left: 20*fem,
              top: 86*fem,
              child: Align(
                child: SizedBox(
                  width: 60*fem,
                  height: 60*fem,
                  child: Image.asset(
                    'assets/page-1/images/nameprofile-icon-selectedyes.png',
                    width: 60*fem,
                    height: 60*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // namefaviconselectedyesuEQ (25:2241)
              left: 20*fem,
              top: 161*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(7*fem, 8*fem, 8*fem, 7*fem),
                width: 60*fem,
                height: 60*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(30*fem),
                ),
                child: Center(
                  // 1oE (72:1854)
                  child: SizedBox(
                    width: 45*fem,
                    height: 45*fem,
                    child: Image.asset(
                      'assets/page-1/images/-8xp.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // namemusiciconselectedyesARE (25:2243)
              left: 20*fem,
              top: 236*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 12*fem),
                width: 60*fem,
                height: 60*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(30*fem),
                ),
                child: Center(
                  // image12Rc4 (77:405)
                  child: SizedBox(
                    width: 35*fem,
                    height: 35*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-12.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // namevideoiconselectedyesXf6 (25:2245)
              left: 20*fem,
              top: 311*fem,
              child: Align(
                child: SizedBox(
                  width: 60*fem,
                  height: 60*fem,
                  child: Image.asset(
                    'assets/page-1/images/namevideo-icon-selectedyes.png',
                    width: 60*fem,
                    height: 60*fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}