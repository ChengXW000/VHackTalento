import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 415;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // bottomnavnik (25:2298)
        padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 20*fem, 20*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff7b61ff)),
          borderRadius: BorderRadius.circular(5*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // property1homeskC (25:2299)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 53*fem),
              width: double.infinity,
              height: 66*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtractzpp (25:2300)
                    left: -20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract-YUp.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsVma (25:2301)
                    left: 10*fem,
                    top: -20*fem,
                    child: Align(
                      child: SizedBox(
                        width: 60*fem,
                        height: 60*fem,
                        child: Image.asset(
                          'assets/page-1/images/bottom-nav-icons-iPz.png',
                          width: 60*fem,
                          height: 60*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconscbJ (25:2302)
                    left: 93.75*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-uUk.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsKEp (25:2303)
                    left: 167.5*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image13awS (I25:2303;78:413)
                          child: SizedBox(
                            width: 26*fem,
                            height: 26*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-13-1Cc.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsXLt (25:2304)
                    left: 241.25*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image91mr (I25:2304;72:1830)
                          child: SizedBox(
                            width: 34*fem,
                            height: 31.66*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-9-zPS.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsHDa (25:2305)
                    left: 315*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-WXi.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // property1profile9ma (25:2306)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 53*fem),
              width: double.infinity,
              height: 66*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtract59S (25:2307)
                    left: -20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract-B9z.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnavicons3Eg (25:2308)
                    left: 20*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-G5E.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsJgQ (25:2309)
                    left: 84*fem,
                    top: -27*fem,
                    child: Align(
                      child: SizedBox(
                        width: 60*fem,
                        height: 60*fem,
                        child: Image.asset(
                          'assets/page-1/images/bottom-nav-icons-12G.png',
                          width: 60*fem,
                          height: 60*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsDYU (25:2310)
                    left: 167.5*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image13ugC (I25:2310;78:413)
                          child: SizedBox(
                            width: 26*fem,
                            height: 26*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-13-rp8.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnavicons1z8 (25:2311)
                    left: 241.25*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image9gKa (I25:2311;72:1830)
                          child: SizedBox(
                            width: 34*fem,
                            height: 31.66*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-9-kME.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsn7i (25:2312)
                    left: 315*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-nJt.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // property1musicH4U (25:2313)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 53*fem),
              width: double.infinity,
              height: 66*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtractQPz (25:2314)
                    left: -20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract-BtC.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsta4 (25:2315)
                    left: 20*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-iit.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsnfS (25:2316)
                    left: 93.75*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-bt4.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsfUL (25:2317)
                    left: 158*fem,
                    top: -27*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 12*fem),
                      width: 60*fem,
                      height: 60*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(30*fem),
                      ),
                      child: Center(
                        // image12n3A (I25:2317;77:405)
                        child: SizedBox(
                          width: 35*fem,
                          height: 35*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-12-ade.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsutU (25:2318)
                    left: 241.25*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image9aUp (I25:2318;72:1830)
                          child: SizedBox(
                            width: 34*fem,
                            height: 31.66*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-9-VTv.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsJQp (25:2319)
                    left: 315*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-3BE.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // property1favadE (25:2320)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 58*fem),
              width: double.infinity,
              height: 66*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtractJp8 (25:2321)
                    left: -20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsRNx (25:2322)
                    left: 20*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-b6G.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsJhe (25:2323)
                    left: 93.75*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-J64.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconspAC (25:2324)
                    left: 167.5*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image136tQ (I25:2324;78:413)
                          child: SizedBox(
                            width: 26*fem,
                            height: 26*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-13.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsDi8 (25:2325)
                    left: 232*fem,
                    top: -27*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(7*fem, 8*fem, 8*fem, 7*fem),
                      width: 60*fem,
                      height: 60*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(30*fem),
                      ),
                      child: Center(
                        // jRa (I25:2325;72:1854)
                        child: SizedBox(
                          width: 45*fem,
                          height: 45*fem,
                          child: Image.asset(
                            'assets/page-1/images/-Jmn.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsFep (25:2326)
                    left: 315*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-oQc.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // property1videoxZE (25:2327)
              width: double.infinity,
              height: 66*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtractV3N (25:2328)
                    left: -20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract-ETr.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsmma (25:2329)
                    left: 20*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-ykk.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsgNk (25:2330)
                    left: 93.75*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-Q2k.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsAoi (25:2331)
                    left: 167.5*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image13rwS (I25:2331;78:413)
                          child: SizedBox(
                            width: 26*fem,
                            height: 26*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-13-vvk.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsorg (25:2332)
                    left: 241.25*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image976g (I25:2332;72:1830)
                          child: SizedBox(
                            width: 34*fem,
                            height: 31.66*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-9-hUk.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnavicons1Sx (25:2333)
                    left: 304*fem,
                    top: -27*fem,
                    child: Align(
                      child: SizedBox(
                        width: 60*fem,
                        height: 60*fem,
                        child: Image.asset(
                          'assets/page-1/images/bottom-nav-icons-Y5N.png',
                          width: 60*fem,
                          height: 60*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}