import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 415;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // bottomnavPAp (25:2298)
        padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 20*fem, 20*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff7b61ff)),
          borderRadius: BorderRadius.circular(5*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // property1homeTRa (25:2299)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 53*fem),
              width: double.infinity,
              height: 66*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtractzAc (25:2300)
                    left: -20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract-LZe.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsVNG (25:2301)
                    left: 10*fem,
                    top: -20*fem,
                    child: Align(
                      child: SizedBox(
                        width: 60*fem,
                        height: 60*fem,
                        child: Image.asset(
                          'assets/page-1/images/bottom-nav-icons-rLG.png',
                          width: 60*fem,
                          height: 60*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconso84 (25:2302)
                    left: 93.75*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-EBz.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsVFn (25:2303)
                    left: 167.5*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image13mUC (I25:2303;78:413)
                          child: SizedBox(
                            width: 26*fem,
                            height: 26*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-13-veU.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsHhS (25:2304)
                    left: 241.25*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image9B28 (I25:2304;72:1830)
                          child: SizedBox(
                            width: 34*fem,
                            height: 31.66*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-9-4Hn.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnavicons5NQ (25:2305)
                    left: 315*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-fWx.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // property1profileNMW (25:2306)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 53*fem),
              width: double.infinity,
              height: 66*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtractt4x (25:2307)
                    left: -20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract-456.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconscWk (25:2308)
                    left: 20*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-5zQ.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsKvx (25:2309)
                    left: 84*fem,
                    top: -27*fem,
                    child: Align(
                      child: SizedBox(
                        width: 60*fem,
                        height: 60*fem,
                        child: Image.asset(
                          'assets/page-1/images/bottom-nav-icons-on8.png',
                          width: 60*fem,
                          height: 60*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsE2L (25:2310)
                    left: 167.5*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image13iCQ (I25:2310;78:413)
                          child: SizedBox(
                            width: 26*fem,
                            height: 26*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-13-NHv.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconscoa (25:2311)
                    left: 241.25*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image9hq2 (I25:2311;72:1830)
                          child: SizedBox(
                            width: 34*fem,
                            height: 31.66*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-9-aJU.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsEKA (25:2312)
                    left: 315*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-tBr.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // property1music9h2 (25:2313)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 53*fem),
              width: double.infinity,
              height: 66*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtractUzC (25:2314)
                    left: -20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsanL (25:2315)
                    left: 20*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-ud2.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconstHE (25:2316)
                    left: 93.75*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsnNc (25:2317)
                    left: 158*fem,
                    top: -27*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 12*fem),
                      width: 60*fem,
                      height: 60*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(30*fem),
                      ),
                      child: Center(
                        // image12hkU (I25:2317;77:405)
                        child: SizedBox(
                          width: 35*fem,
                          height: 35*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-12-WGp.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsqLt (25:2318)
                    left: 241.25*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image9s2g (I25:2318;72:1830)
                          child: SizedBox(
                            width: 34*fem,
                            height: 31.66*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-9.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsy5i (25:2319)
                    left: 315*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-gec.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // property1favfUL (25:2320)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 58*fem),
              width: double.infinity,
              height: 66*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtractPv8 (25:2321)
                    left: -20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract-9rp.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsvv4 (25:2322)
                    left: 20*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-vXr.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsdZa (25:2323)
                    left: 93.75*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-Qye.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsX9A (25:2324)
                    left: 167.5*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image13N9n (I25:2324;78:413)
                          child: SizedBox(
                            width: 26*fem,
                            height: 26*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-13-Bsn.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsW16 (25:2325)
                    left: 232*fem,
                    top: -27*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(7*fem, 8*fem, 8*fem, 7*fem),
                      width: 60*fem,
                      height: 60*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(30*fem),
                      ),
                      child: Center(
                        // CPi (I25:2325;72:1854)
                        child: SizedBox(
                          width: 45*fem,
                          height: 45*fem,
                          child: Image.asset(
                            'assets/page-1/images/-mFE.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsXRz (25:2326)
                    left: 315*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-oZz.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // property1videoSYx (25:2327)
              width: double.infinity,
              height: 66*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtractncp (25:2328)
                    left: -20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract-vwJ.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsKMr (25:2329)
                    left: 20*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-68G.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsySQ (25:2330)
                    left: 93.75*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-UpQ.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnavicons6X2 (25:2331)
                    left: 167.5*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image13NzL (I25:2331;78:413)
                          child: SizedBox(
                            width: 26*fem,
                            height: 26*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-13-4oi.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsJsz (25:2332)
                    left: 241.25*fem,
                    top: 13*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image9DVA (I25:2332;72:1830)
                          child: SizedBox(
                            width: 34*fem,
                            height: 31.66*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-9-jSp.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsvPa (25:2333)
                    left: 304*fem,
                    top: -27*fem,
                    child: Align(
                      child: SizedBox(
                        width: 60*fem,
                        height: 60*fem,
                        child: Image.asset(
                          'assets/page-1/images/bottom-nav-icons-DRi.png',
                          width: 60*fem,
                          height: 60*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}