import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // uploadUdE (6:433)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 153*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0, -1),
            end: Alignment(0, 1),
            colors: <Color>[Color(0xff232320), Color(0xff2d2c28), Color(0xff18181a), Color(0xff131313)],
            stops: <double>[0.042, 0.104, 0.701, 1],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // barsstatusbariphonexvk8 (6:456)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 37*fem),
              padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
              width: double.infinity,
              height: 44*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // timestyleQvC (6:475)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                    height: double.infinity,
                    child: Text(
                      '9:41',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'SF Pro Text',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2575*ffem/fem,
                        letterSpacing: -0.3000000119*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // mobilesignaltaU (6:470)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                    width: 18.77*fem,
                    height: 10.67*fem,
                    child: Image.asset(
                      'assets/page-1/images/mobile-signal-CDv.png',
                      width: 18.77*fem,
                      height: 10.67*fem,
                    ),
                  ),
                  Container(
                    // wifiDMr (6:466)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                    width: 16.86*fem,
                    height: 10.97*fem,
                    child: Image.asset(
                      'assets/page-1/images/wifi.png',
                      width: 16.86*fem,
                      height: 10.97*fem,
                    ),
                  ),
                  Container(
                    // batteryLxG (6:458)
                    margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                    width: 24.5*fem,
                    height: 10.5*fem,
                    child: Image.asset(
                      'assets/page-1/images/battery.png',
                      width: 24.5*fem,
                      height: 10.5*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame8Tmz (6:451)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 357.5*fem, 0*fem),
              width: 16.5*fem,
              height: 16.5*fem,
              child: Image.asset(
                'assets/page-1/images/frame-8.png',
                width: 16.5*fem,
                height: 16.5*fem,
              ),
            ),
            Container(
              // autogroupkepyKZJ (Kwds22mb6S81JbErPwKepY)
              padding: EdgeInsets.fromLTRB(143*fem, 3*fem, 143*fem, 13*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // march2023qXe (6:449)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 13.5*fem),
                    child: Text(
                      'March 2023',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 24*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.1725*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // selectvideotouploadAK2 (116:787)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                    child: Text(
                      'Select Video To Upload',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.1725*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // photosFrG (6:443)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 56.5*fem),
              width: double.infinity,
              height: 473.5*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // photoyXN (6:446)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 29.5*fem),
                    width: 235*fem,
                    height: 396*fem,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6*fem),
                      child: Image.asset(
                        'assets/page-1/images/photo-tZe.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 36*fem,
                  ),
                  Container(
                    // autogroupfukuSvk (KwdsFSYunKAuq4Rt2YFukU)
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // photonzc (6:445)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18.5*fem),
                          width: 248*fem,
                          height: 440*fem,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8*fem),
                            child: Image.asset(
                              'assets/page-1/images/photo.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Text(
                          // W9v (6:444)
                          '3/22',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 36*fem,
                  ),
                  Container(
                    // photoDq2 (6:447)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 29.5*fem),
                    width: 235*fem,
                    height: 394*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(6*fem),
                      gradient: RadialGradient (
                        center: Alignment(0, -0),
                        radius: 0.5,
                        colors: <Color>[Color(0xff161617), Color(0xff242422)],
                        stops: <double>[0, 1],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x19ffffff),
                          offset: Offset(0*fem, 2.5*fem),
                          blurRadius: 1*fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // buttonzjJ (6:435)
              margin: EdgeInsets.fromLTRB(72*fem, 0*fem, 72*fem, 0*fem),
              width: double.infinity,
              height: 44*fem,
              decoration: BoxDecoration (
                color: Color(0xffea4359),
                borderRadius: BorderRadius.circular(22*fem),
              ),
              child: Center(
                child: Text(
                  'Select Video',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont (
                    'Roboto',
                    fontSize: 15*ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.1725*ffem/fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}