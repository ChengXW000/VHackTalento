import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // companydescription1GSt (78:721)
        width: double.infinity,
        height: 583*fem,
        child: Stack(
          children: [
            Positioned(
              // backgroundNF2 (78:722)
              left: 0*fem,
              top: 50*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 533*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(8*fem),
                        topRight: Radius.circular(8*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group15FZi (88:1839)
              left: 13*fem,
              top: 169*fem,
              child: Container(
                width: 384*fem,
                height: 118*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group10WEk (88:1840)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Container(
                    // group18UBa (88:1841)
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Center(
                      // rectangle5DQ4 (88:1842)
                      child: SizedBox(
                        width: double.infinity,
                        height: 118*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfff8f9fc),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group16MWG (88:1843)
              left: 13*fem,
              top: 298*fem,
              child: Container(
                width: 384*fem,
                height: 242*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 15*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group10gHe (88:1844)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Container(
                    // group18RFE (88:1845)
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Center(
                      // rectangle5PC4 (88:1846)
                      child: SizedBox(
                        width: double.infinity,
                        height: 242*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xfff8f9fc),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // backgroundK5i (88:1838)
              left: 0*fem,
              top: 566*fem,
              child: Align(
                child: SizedBox(
                  width: 414*fem,
                  height: 17*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xffd0d1d3),
                          offset: Offset(0*fem, -0.3300000131*fem),
                          blurRadius: 0*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame51jE (78:723)
              left: 388.25*fem,
              top: 68.25*fem,
              child: Align(
                child: SizedBox(
                  width: 9.5*fem,
                  height: 9.5*fem,
                  child: Image.asset(
                    'assets/page-1/images/frame-5-eRe.png',
                    width: 9.5*fem,
                    height: 9.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse3itY (78:727)
              left: 157*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 100*fem,
                  height: 100*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(50*fem),
                      border: Border.all(color: Color(0xff060606)),
                      image: DecorationImage (
                        fit: BoxFit.contain,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-3-bg-uZi.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame16ndW (78:730)
              left: 179*fem,
              top: 212*fem,
              child: Container(
                width: 196*fem,
                height: 32*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // focusitservicesanditconsulting (78:731)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                      child: Text(
                        'Focus : IT Services and IT Consulting',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 11*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xff86878b),
                        ),
                      ),
                    ),
                    Text(
                      // specializesanalyticsbigdatamla (78:732)
                      'Specializes : Analytics, Big Data, ML/AI\n',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 11*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff86878b),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // itservicesconsultingKmr (78:741)
              left: 130*fem,
              top: 141*fem,
              child: Align(
                child: SizedBox(
                  width: 153*fem,
                  height: 20*fem,
                  child: Text(
                    '#IT #services #consulting',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.5*ffem/fem,
                      color: Color(0x99000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fusionexgroupowv (78:742)
              left: 122*fem,
              top: 112*fem,
              child: Align(
                child: SizedBox(
                  width: 170*fem,
                  height: 29*fem,
                  child: Text(
                    'Fusionex Group',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // image14UoA (80:751)
              left: 28*fem,
              top: 169*fem,
              child: Align(
                child: SizedBox(
                  width: 131*fem,
                  height: 137*fem,
                  child: Image.asset(
                    'assets/page-1/images/image-14.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // hiringkEt (78:739)
              left: 30*fem,
              top: 308*fem,
              child: Align(
                child: SizedBox(
                  width: 56*fem,
                  height: 24*fem,
                  child: Text(
                    'Hiring',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // aboutus4WU (78:738)
              left: 29*fem,
              top: 180*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 24*fem,
                  child: Text(
                    'About Us',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // aboutusN1N (94:2052)
              left: 29*fem,
              top: 180*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 24*fem,
                  child: Text(
                    'About Us',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff161722),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group214un (88:1852)
              left: 43*fem,
              top: 343*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 324*fem,
                  height: 35*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        // group17BzQ (88:1847)
                        left: 0*fem,
                        top: 0*fem,
                        child: Container(
                          width: 324*fem,
                          height: 35*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x26000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 15*fem,
                              ),
                            ],
                          ),
                          child: Container(
                            // group106ba (88:1848)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Container(
                              // group181yS (88:1849)
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(8*fem),
                              ),
                              child: Center(
                                // rectangle59pk (88:1850)
                                child: SizedBox(
                                  width: double.infinity,
                                  height: 35*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(8*fem),
                                      color: Color(0xfff8f9fc),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // internsoftwareengineer5Cc (88:1851)
                        left: 77*fem,
                        top: 10*fem,
                        child: Align(
                          child: SizedBox(
                            width: 175*fem,
                            height: 18*fem,
                            child: Text(
                              'Intern - Software Engineer',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1725*ffem/fem,
                                color: Color(0xff161722),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // group22BFe (88:1853)
              left: 43*fem,
              top: 390*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 324*fem,
                  height: 35*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        // group175bv (88:1854)
                        left: 0*fem,
                        top: 0*fem,
                        child: Container(
                          width: 324*fem,
                          height: 35*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x26000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 15*fem,
                              ),
                            ],
                          ),
                          child: Container(
                            // group10Pcc (88:1855)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Container(
                              // group18kxx (88:1856)
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(8*fem),
                              ),
                              child: Center(
                                // rectangle5JUg (88:1857)
                                child: SizedBox(
                                  width: double.infinity,
                                  height: 35*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(8*fem),
                                      color: Color(0xfff8f9fc),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // internwebdevelopmentqDi (88:1858)
                        left: 77.5*fem,
                        top: 10*fem,
                        child: Align(
                          child: SizedBox(
                            width: 174*fem,
                            height: 18*fem,
                            child: Text(
                              'Intern - Web Development',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1725*ffem/fem,
                                color: Color(0xff161722),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // group23wGk (88:1944)
              left: 43*fem,
              top: 437*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 324*fem,
                  height: 35*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(8*fem),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        // group171XW (88:1945)
                        left: 0*fem,
                        top: 0*fem,
                        child: Container(
                          width: 324*fem,
                          height: 35*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x26000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 15*fem,
                              ),
                            ],
                          ),
                          child: Container(
                            // group10jyJ (88:1946)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Container(
                              // group1874k (88:1947)
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(8*fem),
                              ),
                              child: Center(
                                // rectangle5sZi (88:1948)
                                child: SizedBox(
                                  width: double.infinity,
                                  height: 35*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(8*fem),
                                      color: Color(0xfff8f9fc),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // fullstackdeveloperLiC (88:1949)
                        left: 96*fem,
                        top: 10*fem,
                        child: Align(
                          child: SizedBox(
                            width: 137*fem,
                            height: 18*fem,
                            child: Text(
                              'Full Stack Developer',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1725*ffem/fem,
                                color: Color(0xff161722),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}