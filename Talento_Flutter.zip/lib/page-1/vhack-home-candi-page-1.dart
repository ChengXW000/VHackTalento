import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // vhackhomecandipage1Mha (6:1562)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          height: 896*fem,
          decoration: BoxDecoration (
            image: DecorationImage (
              fit: BoxFit.cover,
              image: AssetImage (
                'assets/page-1/images/gif1-bg-n7a.png',
              ),
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                // notes1XE (6:1565)
                left: 292.5*fem,
                top: 676.5*fem,
                child: Align(
                  child: SizedBox(
                    width: 81.55*fem,
                    height: 113.16*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Image.asset(
                        'assets/page-1/images/notes-roA.png',
                        width: 81.55*fem,
                        height: 113.16*fem,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // disc6Hn (6:1566)
                left: 358.4063720703*fem,
                top: 749.106628418*fem,
                child: TextButton(
                  onPressed: () {},
                  style: TextButton.styleFrom (
                    padding: EdgeInsets.zero,
                  ),
                  child: Container(
                    width: 49*fem,
                    height: 49*fem,
                    child: Container(
                      // frame11Rqr (I6:1566;6:1398)
                      padding: EdgeInsets.fromLTRB(5.42*fem, 5.42*fem, 5.42*fem, 5.42*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(24.5*fem),
                        gradient: SweepGradient (
                          center: Alignment(0, 0),
                          startAngle: 1.55,
                          endAngle: 7.83,
                          tileMode: TileMode.repeated,
                          colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                          stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                        ),
                      ),
                      child: Center(
                        // ellipse2SW4 (I6:1566;6:1400)
                        child: SizedBox(
                          width: 38.16*fem,
                          height: 38.16*fem,
                          child: Image.asset(
                            'assets/page-1/images/ellipse-2-uyr.png',
                            width: 38.16*fem,
                            height: 38.16*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // infon48 (6:1568)
                left: 12*fem,
                top: 704*fem,
                child: Container(
                  width: 292*fem,
                  height: 49*fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // autogroup3hbeHma (Kwed3bk32sUVTjeP5P3hbe)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                        width: 94*fem,
                        height: 20*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // jaye1281Bn (6:1569)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 94*fem,
                                  height: 20*fem,
                                  child: RichText(
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 17*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '@jaye',
                                        ),
                                        TextSpan(
                                          text: ' · ',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 17*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0x99ffffff),
                                          ),
                                        ),
                                        TextSpan(
                                          text: '1-28',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 15*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0x99ffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // jaye128Vua (88:2040)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 94*fem,
                                  height: 20*fem,
                                  child: RichText(
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 17*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '@jaye',
                                        ),
                                        TextSpan(
                                          text: ' · ',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 17*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0x99ffffff),
                                          ),
                                        ),
                                        TextSpan(
                                          text: '1-28',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 15*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0x99ffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroupjtapyCU (Kwed7WoBNSPaM95DTxJTap)
                        width: double.infinity,
                        height: 20*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // internengineeringeeengineering (6:1570)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 292*fem,
                                  height: 20*fem,
                                  child: Text(
                                    '#intern #engineering(EE) #engineering(SE)',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // internengineeringeeengineering (88:2041)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 292*fem,
                                  height: 20*fem,
                                  child: Text(
                                    '#intern #engineering(EE) #engineering(SE)',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // headerSVN (6:1608)
                left: 90*fem,
                top: 56*fem,
                child: Container(
                  width: 234*fem,
                  height: 19*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        // candidatesN88 (6:1609)
                        'Candidates',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1725*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                      SizedBox(
                        width: 35*fem,
                      ),
                      SizedBox(
                        width: 35*fem,
                      ),
                      TextButton(
                        // companiesT9a (6:1610)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Text(
                          'Companies',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1725*ffem/fem,
                            color: Color(0x99ffffff),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // barsstatusbariphonexzfJ (6:1615)
                left: 0*fem,
                top: 0*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                  width: 414*fem,
                  height: 44*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // timestyledCU (6:1634)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                        padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                        height: double.infinity,
                        child: Text(
                          '9:41',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'SF Pro Text',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.2575*ffem/fem,
                            letterSpacing: -0.3000000119*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                      Container(
                        // mobilesignalJpQ (6:1629)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                        width: 18.77*fem,
                        height: 10.67*fem,
                        child: Image.asset(
                          'assets/page-1/images/mobile-signal-zme.png',
                          width: 18.77*fem,
                          height: 10.67*fem,
                        ),
                      ),
                      Container(
                        // wifi1yi (6:1625)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                        width: 16.86*fem,
                        height: 10.97*fem,
                        child: Image.asset(
                          'assets/page-1/images/wifi-DFN.png',
                          width: 16.86*fem,
                          height: 10.97*fem,
                        ),
                      ),
                      Container(
                        // batteryMGt (6:1617)
                        margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                        width: 24.5*fem,
                        height: 10.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/battery-Z6Q.png',
                          width: 24.5*fem,
                          height: 10.5*fem,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // mainpageicon4BJ (78:607)
                left: 0*fem,
                top: 498*fem,
                child: Container(
                  width: 2420*fem,
                  height: 1493.85*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // actionbuttonsbBE (6:1571)
                        left: 0*fem,
                        top: 191*fem,
                        child: Container(
                          width: 2408*fem,
                          height: 1302.85*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // chatJbS (6:1576)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 390.85*fem),
                                width: double.infinity,
                                child: Text(
                                  'Chat',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                              Container(
                                // tiktokalbumRRA (6:692)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1994*fem, 0*fem),
                                width: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      // autogroupa84gLo2 (KwedfAZ7CpAyp2HCGia84g)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7310*fem, 0*fem),
                                      width: 414*fem,
                                      height: 996.67*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // topbarFuz (6:711)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.34*fem),
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              color: Color(0xffffffff),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0xffe3e3e4),
                                                  offset: Offset(0*fem, 0.3300000131*fem),
                                                  blurRadius: 0*fem,
                                                ),
                                              ],
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // barsstatusbariphonexXcc (6:729)
                                                  padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                                                  width: double.infinity,
                                                  height: 44*fem,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // timestyle2JU (6:748)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1928.2*fem, 0*fem),
                                                        padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                                                        width: 59.62*fem,
                                                        height: double.infinity,
                                                        child: Text(
                                                          '9:41',
                                                          textAlign: TextAlign.center,
                                                          style: SafeGoogleFont (
                                                            'SF Pro Text',
                                                            fontSize: 15*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 1.2575*ffem/fem,
                                                            letterSpacing: -0.3000000119*fem,
                                                            color: Color(0xff171717),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // wifispt (6:739)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1645.61*fem, 0.37*fem),
                                                        width: 16.86*fem,
                                                        height: 10.97*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/wifi-SkQ.png',
                                                          width: 16.86*fem,
                                                          height: 10.97*fem,
                                                        ),
                                                      ),
                                                      Container(
                                                        // mobilesignalbVz (6:743)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1668.02*fem, 0*fem),
                                                        width: 18.77*fem,
                                                        height: 10.67*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/mobile-signal-t4g.png',
                                                          width: 18.77*fem,
                                                          height: 10.67*fem,
                                                        ),
                                                      ),
                                                      Container(
                                                        // battery6Br (6:731)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                                                        width: 24.5*fem,
                                                        height: 10.5*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/battery-noS.png',
                                                          width: 24.5*fem,
                                                          height: 10.5*fem,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  // autogroup1jgknaU (KwefbMqASvsW28aAne1jGk)
                                                  padding: EdgeInsets.fromLTRB(17.79*fem, 12.49*fem, 17.4*fem, 33.33*fem),
                                                  width: double.infinity,
                                                  height: 220.33*fem,
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        // autogroupbn9nKKW (KweetP1SqABe71VeawBN9N)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 34.91*fem),
                                                        width: 378.81*fem,
                                                        height: 18.59*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/auto-group-bn9n.png',
                                                          width: 378.81*fem,
                                                          height: 18.59*fem,
                                                        ),
                                                      ),
                                                      Container(
                                                        // autogroup5jhv3WQ (KweezdL37aKqbyPcpk5JHv)
                                                        margin: EdgeInsets.fromLTRB(0.21*fem, 0*fem, 92.6*fem, 0*fem),
                                                        width: double.infinity,
                                                        height: 121*fem,
                                                        child: Row(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              // autogroupsrdsamE (Kwef7YJBffPVrErCSuSRdS)
                                                              width: 152*fem,
                                                              height: double.infinity,
                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                                children: [
                                                                  Container(
                                                                    // autogroupmxdnvKJ (KwefDhnafcv1knoLmAmxdN)
                                                                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25*fem),
                                                                    width: double.infinity,
                                                                    height: 93*fem,
                                                                    child: Column(
                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                      children: [
                                                                        Container(
                                                                          // theroundTrx (6:716)
                                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                                          child: Text(
                                                                            'The Round',
                                                                            style: SafeGoogleFont (
                                                                              'Roboto',
                                                                              fontSize: 20*ffem,
                                                                              fontWeight: FontWeight.w900,
                                                                              height: 1.1725*ffem/fem,
                                                                              color: Color(0xff161722),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          // roddyroundicch9jn (6:717)
                                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                                          child: Text(
                                                                            'Roddy Roundicch',
                                                                            style: SafeGoogleFont (
                                                                              'Roboto',
                                                                              fontSize: 13*ffem,
                                                                              fontWeight: FontWeight.w400,
                                                                              height: 1.1725*ffem/fem,
                                                                              color: Color(0xff86878b),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Text(
                                                                          // mvideosFnp (6:718)
                                                                          '1.7M videos',
                                                                          style: SafeGoogleFont (
                                                                            'Roboto',
                                                                            fontSize: 13*ffem,
                                                                            fontWeight: FontWeight.w400,
                                                                            height: 1.1725*ffem/fem,
                                                                            color: Color(0xff86878b),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    // button1GC (6:719)
                                                                    width: double.infinity,
                                                                    height: 28*fem,
                                                                    child: Stack(
                                                                      children: [
                                                                        Positioned(
                                                                          // bookmarkiconM5A (6:720)
                                                                          left: 0*fem,
                                                                          top: 7.25*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 10.5*fem,
                                                                              height: 12.9*fem,
                                                                              child: Image.asset(
                                                                                'assets/page-1/images/bookmark-icon.png',
                                                                                width: 10.5*fem,
                                                                                height: 12.9*fem,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          // addtofavoritesg7S (6:721)
                                                                          left: 0*fem,
                                                                          top: 5*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 104*fem,
                                                                              height: 17*fem,
                                                                              child: Text(
                                                                                'Add to Favorites',
                                                                                style: SafeGoogleFont (
                                                                                  'Roboto',
                                                                                  fontSize: 14*ffem,
                                                                                  fontWeight: FontWeight.w900,
                                                                                  height: 1.1725*ffem/fem,
                                                                                  color: Color(0xff161722),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          // rectangle10bEQ (6:722)
                                                                          left: 0*fem,
                                                                          top: 0*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 152*fem,
                                                                              height: 28*fem,
                                                                              child: Container(
                                                                                decoration: BoxDecoration (
                                                                                  borderRadius: BorderRadius.circular(2*fem),
                                                                                  border: Border.all(color: Color(0xffe3e3e4)),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              // albumsBv (6:723)
                                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1873*fem, 0*fem),
                                                              padding: EdgeInsets.fromLTRB(49.67*fem, 47.8*fem, 50.23*fem, 47.8*fem),
                                                              width: 120*fem,
                                                              height: 120*fem,
                                                              decoration: BoxDecoration (
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-9-bg.png',
                                                                  ),
                                                                ),
                                                              ),
                                                              child: Center(
                                                                // playiconwxU (6:725)
                                                                child: SizedBox(
                                                                  width: 20.1*fem,
                                                                  height: 24.4*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/play-icon.png',
                                                                    width: 20.1*fem,
                                                                    height: 24.4*fem,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // thumbnails4nC (6:694)
                                            width: double.infinity,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // autogroupsmny2U8 (KweduudYS34oq6bSg2SmNY)
                                                  width: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // rectangle11PJg (6:695)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1874*fem, 0*fem),
                                                        width: 137*fem,
                                                        height: 182*fem,
                                                        decoration: BoxDecoration (
                                                          border: Border.all(color: Color(0xffffffff)),
                                                          color: Color(0xffc4c4c4),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-11-bg.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // rectangle128vU (6:699)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1735.34*fem, 0*fem),
                                                        width: 137*fem,
                                                        height: 182*fem,
                                                        decoration: BoxDecoration (
                                                          border: Border.all(color: Color(0xffffffff)),
                                                          color: Color(0xffc4c4c4),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-12-bg.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // rectangle13Npp (6:703)
                                                        width: 137*fem,
                                                        height: 182*fem,
                                                        decoration: BoxDecoration (
                                                          border: Border.all(color: Color(0xffffffff)),
                                                          color: Color(0xffc4c4c4),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-13-bg.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 1.33*fem,
                                                ),
                                                Container(
                                                  // autogroupxhltFtc (Kwee3jjq7AtybuT7TAxHLt)
                                                  width: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // rectangle14mrx (6:696)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1874*fem, 0*fem),
                                                        width: 137*fem,
                                                        height: 182*fem,
                                                        decoration: BoxDecoration (
                                                          border: Border.all(color: Color(0xffffffff)),
                                                          color: Color(0xffc4c4c4),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-14-bg.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // rectangle15hEp (6:700)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1735.34*fem, 0*fem),
                                                        width: 137*fem,
                                                        height: 182*fem,
                                                        decoration: BoxDecoration (
                                                          border: Border.all(color: Color(0xffffffff)),
                                                          color: Color(0xffc4c4c4),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-15-bg.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // rectangle16A8Q (6:704)
                                                        width: 137*fem,
                                                        height: 182*fem,
                                                        decoration: BoxDecoration (
                                                          border: Border.all(color: Color(0xffffffff)),
                                                          color: Color(0xffc4c4c4),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-16-bg.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 1.33*fem,
                                                ),
                                                Container(
                                                  // autogroupfn7sfL4 (KweeEpFhrCimWpB1EYFN7S)
                                                  width: double.infinity,
                                                  height: 365.34*fem,
                                                  child: Stack(
                                                    children: [
                                                      Positioned(
                                                        // rectangle17yrY (6:697)
                                                        left: 0*fem,
                                                        top: 0*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 137*fem,
                                                            height: 182*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                border: Border.all(color: Color(0xffffffff)),
                                                                color: Color(0xffc4c4c4),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-17-bg.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        // rectangle20UoJ (6:698)
                                                        left: 0*fem,
                                                        top: 183.33984375*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 137*fem,
                                                            height: 182*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                border: Border.all(color: Color(0xffffffff)),
                                                                color: Color(0xffc4c4c4),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-20-bg.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        // rectangle18yk4 (6:701)
                                                        left: 0*fem,
                                                        top: 0*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 137*fem,
                                                            height: 182*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                border: Border.all(color: Color(0xffffffff)),
                                                                color: Color(0xffc4c4c4),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-18-bg.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        // rectangle21UB2 (6:702)
                                                        left: 0*fem,
                                                        top: 183.33984375*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 137*fem,
                                                            height: 182*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                border: Border.all(color: Color(0xffffffff)),
                                                                color: Color(0xffc4c4c4),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-21-bg.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        // rectangle19mfv (6:705)
                                                        left: 0*fem,
                                                        top: 0*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 137*fem,
                                                            height: 182*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                border: Border.all(color: Color(0xffffffff)),
                                                                color: Color(0xffc4c4c4),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-19-bg.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        // rectangle22G6t (6:706)
                                                        left: 0*fem,
                                                        top: 183.33984375*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 137*fem,
                                                            height: 182*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                border: Border.all(color: Color(0xffffffff)),
                                                                color: Color(0xffc4c4c4),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-22-bg.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        // button8et (6:707)
                                                        left: 0*fem,
                                                        top: 168.669921875*fem,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(23.34*fem, 17*fem, 21*fem, 16*fem),
                                                          width: 178*fem,
                                                          height: 52*fem,
                                                          decoration: BoxDecoration (
                                                            color: Color(0xffea4359),
                                                            borderRadius: BorderRadius.circular(26*fem),
                                                            boxShadow: [
                                                              BoxShadow(
                                                                color: Color(0x4c000000),
                                                                offset: Offset(0*fem, 4*fem),
                                                                blurRadius: 4*fem,
                                                              ),
                                                            ],
                                                          ),
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Text(
                                                                // usethissoundaFz (6:710)
                                                                'Use this sound',
                                                                style: SafeGoogleFont (
                                                                  'Roboto',
                                                                  fontSize: 16*ffem,
                                                                  fontWeight: FontWeight.w900,
                                                                  height: 1.1725*ffem/fem,
                                                                  letterSpacing: -0.25*fem,
                                                                  color: Color(0xffffffff),
                                                                ),
                                                              ),
                                                              Container(
                                                                // videocameraiconhLc (6:709)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1847.17*fem, 0.66*fem),
                                                                width: 22.49*fem,
                                                                height: 14.34*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/videocamera-icon.png',
                                                                  width: 22.49*fem,
                                                                  height: 14.34*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        // barshomeindicatorDpk (6:726)
                                                        left: 0*fem,
                                                        top: 229.669921875*fem,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(140*fem, 20*fem, 140*fem, 10*fem),
                                                          width: 414*fem,
                                                          height: 35*fem,
                                                          child: Center(
                                                            // linetfz (6:728)
                                                            child: SizedBox(
                                                              width: double.infinity,
                                                              height: 5*fem,
                                                              child: Container(
                                                                decoration: BoxDecoration (
                                                                  borderRadius: BorderRadius.circular(100*fem),
                                                                  color: Color(0xff060606),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // digitalpenang128RR2 (94:2640)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 172.85*fem),
                                      child: RichText(
                                        text: TextSpan(
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 17*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                          children: [
                                            TextSpan(
                                              text: '@DigitalPenang',
                                            ),
                                            TextSpan(
                                              text: ' · ',
                                              style: SafeGoogleFont (
                                                'Roboto',
                                                fontSize: 17*ffem,
                                                fontWeight: FontWeight.w900,
                                                height: 1.1725*ffem/fem,
                                                color: Color(0x99ffffff),
                                              ),
                                            ),
                                            TextSpan(
                                              text: '1-28',
                                              style: SafeGoogleFont (
                                                'Roboto',
                                                fontSize: 15*ffem,
                                                fontWeight: FontWeight.w900,
                                                height: 1.1725*ffem/fem,
                                                color: Color(0x99ffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        // autogroup95ccRxk (KwedQLeUh8fUCY27ws95cC)
                        left: 359*fem,
                        top: 0*fem,
                        child: Container(
                          width: 50*fem,
                          height: 70*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // savedud2 (72:1738)
                                left: 0*fem,
                                top: 0*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 50*fem,
                                    height: 54*fem,
                                    child: Center(
                                      // RbN (I72:1738;72:1727;72:1636)
                                      child: SizedBox(
                                        width: 50*fem,
                                        height: 54*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/-JPz.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // likesyMz (72:1861)
                                left: 6.5*fem,
                                top: 16*fem,
                                child: Opacity(
                                  opacity: 0.9,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(6.5*fem, 38*fem, 6*fem, 0*fem),
                                    width: 35.5*fem,
                                    height: 54*fem,
                                    child: Text(
                                      '168',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 13*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        // image10FKW (72:1860)
                        left: 361*fem,
                        top: 77*fem,
                        child: Align(
                          child: SizedBox(
                            width: 45*fem,
                            height: 45*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Image.asset(
                                'assets/page-1/images/image-10-zat.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // image119fn (72:1867)
                        left: 364*fem,
                        top: 140*fem,
                        child: Align(
                          child: SizedBox(
                            width: 40*fem,
                            height: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Image.asset(
                                'assets/page-1/images/image-11-Rjn.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // bottomnavNoS (25:2261)
                left: 0*fem,
                top: 803*fem,
                child: Container(
                  width: 889*fem,
                  height: 93*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // subtractWek (I25:2261;25:2300)
                        left: 0*fem,
                        top: 27*fem,
                        child: Align(
                          child: SizedBox(
                            width: 889*fem,
                            height: 66*fem,
                            child: Image.asset(
                              'assets/page-1/images/subtract-7HS.png',
                              width: 889*fem,
                              height: 66*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnavicons3Pn (I25:2261;25:2301)
                        left: 32*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 60*fem,
                            height: 60*fem,
                            child: Image.asset(
                              'assets/page-1/images/bottom-nav-icons-M68.png',
                              width: 60*fem,
                              height: 60*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsNS4 (I25:2261;25:2302)
                        left: 115.75*fem,
                        top: 40*fem,
                        child: Align(
                          child: SizedBox(
                            width: 40*fem,
                            height: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Image.asset(
                                'assets/page-1/images/bottom-nav-icons-KYL.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnavicons3YC (I25:2261;25:2303)
                        left: 189.5*fem,
                        top: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                            width: 40*fem,
                            height: 40*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(60*fem),
                            ),
                            child: Center(
                              // image13Yzk (I25:2261;25:2303;78:413)
                              child: SizedBox(
                                width: 26*fem,
                                height: 26*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-13-ZWG.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsgLG (I25:2261;25:2304)
                        left: 263.25*fem,
                        top: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 4.34*fem),
                            width: 40*fem,
                            height: 40*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(60*fem),
                            ),
                            child: Center(
                              // image9NTz (I25:2261;25:2304;72:1830)
                              child: SizedBox(
                                width: 34*fem,
                                height: 31.66*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-9-D7N.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // bottomnaviconsvVW (I25:2261;25:2305)
                        left: 337*fem,
                        top: 40*fem,
                        child: Align(
                          child: SizedBox(
                            width: 40*fem,
                            height: 40*fem,
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Image.asset(
                                'assets/page-1/images/bottom-nav-icons-u44.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // profileimgPdz (132:335)
                left: 360*fem,
                top: 435*fem,
                child: Align(
                  child: SizedBox(
                    width: 47*fem,
                    height: 47*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Image.asset(
                        'assets/page-1/images/profile-img.png',
                        width: 47*fem,
                        height: 47*fem,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}