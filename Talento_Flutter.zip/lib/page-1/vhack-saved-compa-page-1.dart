import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // vhacksavedcompapage1V2Y (31:896)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffc4c4c4),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/background-bg-RWQ.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // vhackpage2mVr (31:930)
              padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
              width: double.infinity,
              height: 44*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // timestyle6HE (31:949)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                    height: double.infinity,
                    child: Text(
                      '9:41',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'SF Pro Text',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2575*ffem/fem,
                        letterSpacing: -0.3000000119*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // mobilesignalaCQ (31:944)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                    width: 18.77*fem,
                    height: 10.67*fem,
                    child: Image.asset(
                      'assets/page-1/images/mobile-signal-5mr.png',
                      width: 18.77*fem,
                      height: 10.67*fem,
                    ),
                  ),
                  Container(
                    // wififzY (31:940)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                    width: 16.86*fem,
                    height: 10.97*fem,
                    child: Image.asset(
                      'assets/page-1/images/wifi-Gqe.png',
                      width: 16.86*fem,
                      height: 10.97*fem,
                    ),
                  ),
                  Container(
                    // batteryarc (31:932)
                    margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                    width: 24.5*fem,
                    height: 10.5*fem,
                    child: Image.asset(
                      'assets/page-1/images/battery-Xov.png',
                      width: 24.5*fem,
                      height: 10.5*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouplrmnVTn (Kwe4hH9TTcTadUKBj8LrMN)
              padding: EdgeInsets.fromLTRB(12*fem, 12*fem, 5*fem, 4.89*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // headerQKr (31:926)
                    margin: EdgeInsets.fromLTRB(81*fem, 0*fem, 82*fem, 358*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextButton(
                          // candidates92Y (31:927)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Text(
                            'Candidates',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              color: Color(0x99ffffff),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 35*fem,
                        ),
                        SizedBox(
                          width: 35*fem,
                        ),
                        Text(
                          // companies5qJ (31:929)
                          'Companies',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group24yfn (94:2435)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 48.5*fem),
                    width: 50*fem,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // mainpageiconJxx (94:2436)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // userSpG (94:2437)
                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 2*fem, 18*fem),
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: double.infinity,
                                    child: Center(
                                      // ellipse3a9n (94:2438)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 47*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(23.5*fem),
                                            border: Border.all(color: Color(0xffffffff)),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-vKJ.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group25gyW (94:2439)
                                width: double.infinity,
                                height: 70*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // savedbqa (94:2440)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Container(
                                          width: 50*fem,
                                          height: 54*fem,
                                          child: Center(
                                            // YF2 (I94:2440;72:1727;72:1636)
                                            child: SizedBox(
                                              width: 50*fem,
                                              height: 54*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/-Nat.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // likes3Sg (94:2441)
                                      left: 6.5*fem,
                                      top: 16*fem,
                                      child: Opacity(
                                        opacity: 0.9,
                                        child: Container(
                                          padding: EdgeInsets.fromLTRB(6.5*fem, 38*fem, 5*fem, 0*fem),
                                          width: 35.5*fem,
                                          height: 54*fem,
                                          child: Text(
                                            '58K',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 13*ffem,
                                              fontWeight: FontWeight.w900,
                                              height: 1.1725*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        TextButton(
                          // image18J7i (94:2446)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 40*fem,
                            height: 40*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-18.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupd9zsp64 (Kwe4DNnHPtMtsAePTrD9ZS)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                    width: double.infinity,
                    height: 121.61*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // infowgU (100:3354)
                          margin: EdgeInsets.fromLTRB(0*fem, 27.5*fem, 104.5*fem, 45.11*fem),
                          width: 176*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // digitalpenang128ge4 (100:3357)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                                child: RichText(
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 17*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: '@DigitalPenang',
                                      ),
                                      TextSpan(
                                        text: ' · ',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 17*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.1725*ffem/fem,
                                          color: Color(0x99ffffff),
                                        ),
                                      ),
                                      TextSpan(
                                        text: '1-28',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 15*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.1725*ffem/fem,
                                          color: Color(0x99ffffff),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupgwkcNYp (Kwe4YXu2fRruL84RnzgwkC)
                                width: double.infinity,
                                height: 20*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // itservicesconsultingKyr (100:3356)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 176*fem,
                                          height: 20*fem,
                                          child: Text(
                                            '#IT #services #consulting',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 15*ffem,
                                              fontWeight: FontWeight.w900,
                                              height: 1.3*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // DJY (100:3358)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 9*fem,
                                          height: 20*fem,
                                          child: Text(
                                            '#',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 15*ffem,
                                              fontWeight: FontWeight.w900,
                                              height: 1.3*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupagtxJ56 (Kwe4LHkRwyRZ7S6y61aGtx)
                          width: 112.5*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // notes2Dxk (31:899)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 81.55*fem,
                                    height: 113.16*fem,
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom (
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Image.asset(
                                        'assets/page-1/images/notes2.png',
                                        width: 81.55*fem,
                                        height: 113.16*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // disc295i (31:900)
                                left: 63.5*fem,
                                top: 72.6066894531*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 49*fem,
                                    height: 49*fem,
                                    child: Container(
                                      // frame117we (I31:900;6:1415)
                                      width: double.infinity,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(24.5*fem),
                                        gradient: SweepGradient (
                                          center: Alignment(0, 0),
                                          startAngle: 1.55,
                                          endAngle: 7.83,
                                          tileMode: TileMode.repeated,
                                          colors: <Color>[Color(0xff272726), Color(0xff171717), Color(0xff373736), Color(0xff171717), Color(0xff373736), Color(0xff272726)],
                                          stops: <double>[0, 0.126, 0.384, 0.628, 0.88, 1],
                                        ),
                                      ),
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // ellipse2PeG (I31:900;6:1417)
                                            left: 5.4184570312*fem,
                                            top: 5.4183349609*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 38.16*fem,
                                                height: 38.16*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/ellipse-2-CbJ.png',
                                                  width: 38.16*fem,
                                                  height: 38.16*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // ellipse3hQ4 (I31:900;6:1418)
                                            left: 5.4184570312*fem,
                                            top: 5.4183349609*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 38.16*fem,
                                                height: 38.16*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/ellipse-3-xFA.png',
                                                  width: 38.16*fem,
                                                  height: 38.16*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // bottomnavRax (25:2279)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 109*fem),
              width: double.infinity,
              height: 93*fem,
              child: Stack(
                children: [
                  Positioned(
                    // subtractjbe (I25:2279;25:2321)
                    left: 0*fem,
                    top: 27*fem,
                    child: Align(
                      child: SizedBox(
                        width: 889*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/subtract-DLc.png',
                          width: 889*fem,
                          height: 66*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnavicons3sE (I25:2279;25:2322)
                    left: 39*fem,
                    top: 40*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-kYQ.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconsZag (I25:2279;25:2323)
                    left: 112.75*fem,
                    top: 40*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-X4c.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnaviconspWc (I25:2279;25:2324)
                    left: 186.5*fem,
                    top: 40*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 7*fem, 7*fem),
                        width: 40*fem,
                        height: 40*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(60*fem),
                        ),
                        child: Center(
                          // image13KyA (I25:2279;25:2324;78:413)
                          child: SizedBox(
                            width: 26*fem,
                            height: 26*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-13-fMi.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnavicons2Mn (I25:2279;25:2325)
                    left: 251*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(7*fem, 8*fem, 8*fem, 7*fem),
                      width: 60*fem,
                      height: 60*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(30*fem),
                      ),
                      child: Center(
                        // k2t (I25:2279;25:2325;72:1854)
                        child: SizedBox(
                          width: 45*fem,
                          height: 45*fem,
                          child: Image.asset(
                            'assets/page-1/images/-rXS.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottomnavicons55A (I25:2279;25:2326)
                    left: 334*fem,
                    top: 40*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/bottom-nav-icons-xXA.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // rectangle57mya (94:3108)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2459*fem, 0*fem),
              width: double.infinity,
              height: 930*fem,
              decoration: BoxDecoration (
                color: Color(0xffd9d9d9),
              ),
            ),
          ],
        ),
      ),
          );
  }
}