import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // loadingpage2c4g (157:475)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          height: 896*fem,
          child: Stack(
            children: [
              Positioned(
                // topbarXSY (157:477)
                left: 0*fem,
                top: 0*fem,
                child: Container(
                  width: 414*fem,
                  height: 87.67*fem,
                  child: Center(
                    // backgroundsWQ (157:478)
                    child: SizedBox(
                      width: double.infinity,
                      height: 87.67*fem,
                      child: Container(
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xffd0d1d3),
                              offset: Offset(0*fem, 0.3300000131*fem),
                              blurRadius: 0*fem,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // designlp2PUk (170:671)
                left: 0*fem,
                top: 0*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(0*fem, 15*fem, 0*fem, 15*fem),
                  width: 428*fem,
                  height: 926*fem,
                  decoration: BoxDecoration (
                    color: Color(0xfffffdde),
                    borderRadius: BorderRadius.circular(30*fem),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // autogroupfb5sgik (KwdzFuYJbfSDFmQ37pFb5S)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 75*fem),
                        width: 424*fem,
                        height: 789*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // untitleddesign11o2g (170:672)
                              left: 54*fem,
                              top: 298*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 300*fem,
                                  height: 300*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/untitled-design-1-1-kWL.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // headeriQY (170:673)
                              left: 154*fem,
                              top: 25*fem,
                              child: Container(
                                width: 100*fem,
                                height: 100*fem,
                                child: Center(
                                  // untitleddesign1fKn (170:674)
                                  child: SizedBox(
                                    width: 100*fem,
                                    height: 100*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/untitled-design-1.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // barsstatusbariphonexBJ8 (157:479)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(23.18*fem, 13*fem, 14.5*fem, 13*fem),
                                width: 414*fem,
                                height: 44*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // timestyle58c (157:498)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 241.41*fem, 0*fem),
                                      padding: EdgeInsets.fromLTRB(16.5*fem, 0*fem, 16.12*fem, 0*fem),
                                      height: double.infinity,
                                      child: Text(
                                        '9:41',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'SF Pro Text',
                                          fontSize: 15*ffem,
                                          fontWeight: FontWeight.w600,
                                          height: 1.2575*ffem/fem,
                                          letterSpacing: -0.3000000119*fem,
                                          color: Color(0xff171717),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // mobilesignalYnt (157:493)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.55*fem, 0*fem),
                                      width: 18.77*fem,
                                      height: 10.67*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/mobile-signal-4gY.png',
                                        width: 18.77*fem,
                                        height: 10.67*fem,
                                      ),
                                    ),
                                    Container(
                                      // wifiFhJ (157:489)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.61*fem, 0.37*fem),
                                      width: 16.86*fem,
                                      height: 10.97*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/wifi-Ah6.png',
                                        width: 16.86*fem,
                                        height: 10.97*fem,
                                      ),
                                    ),
                                    Container(
                                      // batteryBax (157:481)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0*fem),
                                      width: 24.5*fem,
                                      height: 10.5*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/battery-AZW.png',
                                        width: 24.5*fem,
                                        height: 10.5*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // group8uG4 (157:500)
                              left: 18*fem,
                              top: 44*fem,
                              child: Container(
                                width: 378*fem,
                                height: 25*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // vectorRkC (157:501)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 331*fem, 0.96*fem),
                                      width: 22*fem,
                                      height: 16.04*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-Goa.png',
                                        width: 22*fem,
                                        height: 16.04*fem,
                                      ),
                                    ),
                                    Container(
                                      // vector7sv (157:502)
                                      width: 25*fem,
                                      height: 25*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-e5W.png',
                                        width: 25*fem,
                                        height: 25*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // backgroundTwn (157:503)
                        margin: EdgeInsets.fromLTRB(7*fem, 0*fem, 7*fem, 0*fem),
                        width: double.infinity,
                        height: 32*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xffd0d1d3),
                              offset: Offset(0*fem, -0.3300000131*fem),
                              blurRadius: 0*fem,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}