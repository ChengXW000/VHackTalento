import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/disc.dart';
// import 'package:myapp/page-1/disc2.dart';
// import 'package:myapp/page-1/notes.dart';
// import 'package:myapp/page-1/bottom-nav-icons.dart';
// import 'package:myapp/page-1/bottom-nav.dart';
// import 'package:myapp/page-1/saved.dart';
// import 'package:myapp/page-1/interactive-components.dart';
// import 'package:myapp/page-1/upload.dart';
// import 'package:myapp/page-1/video-upload.dart';
// import 'package:myapp/page-1/privacy-and-settings.dart';
// import 'package:myapp/page-1/vhack-user-profile.dart';
// import 'package:myapp/page-1/loading-page-1.dart';
// import 'package:myapp/page-1/loading-page-2.dart';
// import 'package:myapp/page-1/company-saved-profile-1.dart';
// import 'package:myapp/page-1/company-saved-description.dart';
// import 'package:myapp/page-1/saved-company-apply-1.dart';
// import 'package:myapp/page-1/vhack-saved-compa-page-1.dart';
// import 'package:myapp/page-1/saved-candi-chat.dart';
// import 'package:myapp/page-1/saved-candi-description.dart';
// import 'package:myapp/page-1/saved-candi-profile.dart';
// import 'package:myapp/page-1/vhack-saved-candi-page-1.dart';
// import 'package:myapp/page-1/company-apply-21.dart';
// import 'package:myapp/page-1/company-description-2.dart';
// import 'package:myapp/page-1/company-profile-2.dart';
// import 'package:myapp/page-1/vhack-home-compa-page-2.dart';
// import 'package:myapp/page-1/company-profile-1.dart';
// import 'package:myapp/page-1/company-apply-13.dart';
// import 'package:myapp/page-1/company-apply-12.dart';
// import 'package:myapp/page-1/company-apply-11.dart';
// import 'package:myapp/page-1/company-description-1.dart';
// import 'package:myapp/page-1/vhack-home-compa-page-1.dart';
// import 'package:myapp/page-1/candi-profile-3.dart';
// import 'package:myapp/page-1/chat-candi-3.dart';
// import 'package:myapp/page-1/candi-description-3.dart';
// import 'package:myapp/page-1/vhack-home-candi-page-3.dart';
// import 'package:myapp/page-1/candi-profile-2.dart';
// import 'package:myapp/page-1/chat-candi-2.dart';
// import 'package:myapp/page-1/candi-description-2.dart';
// import 'package:myapp/page-1/vhack-home-candi-page-2.dart';
// import 'package:myapp/page-1/candi-profile-1.dart';
// import 'package:myapp/page-1/chat-candi-1.dart';
// import 'package:myapp/page-1/candi-description-1.dart';
// import 'package:myapp/page-1/vhack-home-candi-page-1.dart';
// import 'package:myapp/page-1/vhack-latest-info.dart';
// import 'package:myapp/page-1/.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
