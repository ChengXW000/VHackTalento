import 'package:flutter/material.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_home_candi_page_one_container_screen/vhack_home_candi_page_one_container_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/video_upload_screen/video_upload_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/candi_profile_one_screen/candi_profile_one_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_home_compa_page_one_screen/vhack_home_compa_page_one_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/company_profile_one_screen/company_profile_one_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_saved_candi_page_one_screen/vhack_saved_candi_page_one_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/saved_candi_profile_screen/saved_candi_profile_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/candi_description_one_screen/candi_description_one_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/company_description_one_screen/company_description_one_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/saved_candi_description_screen/saved_candi_description_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/chat_candi_one_screen/chat_candi_one_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/company_apply_1_3_screen/company_apply_1_3_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/company_apply_1_2_screen/company_apply_1_2_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/company_apply_1_1_screen/company_apply_1_1_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/saved_candi_chat_screen/saved_candi_chat_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_home_compa_page_two_screen/vhack_home_compa_page_two_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/company_profile_two_screen/company_profile_two_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_saved_compa_page_one_screen/vhack_saved_compa_page_one_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/company_saved_profile_one_screen/company_saved_profile_one_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_home_candi_page_three_screen/vhack_home_candi_page_three_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/candi_profile_three_screen/candi_profile_three_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/company_description_two_screen/company_description_two_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/company_saved_description_screen/company_saved_description_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/candi_description_three_screen/candi_description_three_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/company_apply_2_1_screen/company_apply_2_1_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/saved_company_apply_one_screen/saved_company_apply_one_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/chat_candi_three_screen/chat_candi_three_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_user_profile_screen/vhack_user_profile_screen.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String vhackHomeCandiPageOnePage =
      '/vhack_home_candi_page_one_page';

  static const String vhackHomeCandiPageOneContainerScreen =
      '/vhack_home_candi_page_one_container_screen';

  static const String videoUploadScreen = '/video_upload_screen';

  static const String candiProfileOneScreen = '/candi_profile_one_screen';

  static const String vhackHomeCompaPageOneScreen =
      '/vhack_home_compa_page_one_screen';

  static const String companyProfileOneScreen = '/company_profile_one_screen';

  static const String vhackSavedCandiPageOneScreen =
      '/vhack_saved_candi_page_one_screen';

  static const String savedCandiProfileScreen = '/saved_candi_profile_screen';

  static const String candiDescriptionOneScreen =
      '/candi_description_one_screen';

  static const String companyDescriptionOneScreen =
      '/company_description_one_screen';

  static const String savedCandiDescriptionScreen =
      '/saved_candi_description_screen';

  static const String chatCandiOneScreen = '/chat_candi_one_screen';

  static const String companyApply13Screen = '/company_apply_1_3_screen';

  static const String companyApply12Screen = '/company_apply_1_2_screen';

  static const String companyApply11Screen = '/company_apply_1_1_screen';

  static const String savedCandiChatScreen = '/saved_candi_chat_screen';

  static const String vhackHomeCompaPageTwoScreen =
      '/vhack_home_compa_page_two_screen';

  static const String companyProfileTwoScreen = '/company_profile_two_screen';

  static const String vhackSavedCompaPageOneScreen =
      '/vhack_saved_compa_page_one_screen';

  static const String companySavedProfileOneScreen =
      '/company_saved_profile_one_screen';

  static const String vhackHomeCandiPageThreeScreen =
      '/vhack_home_candi_page_three_screen';

  static const String candiProfileThreeScreen = '/candi_profile_three_screen';

  static const String companyDescriptionTwoScreen =
      '/company_description_two_screen';

  static const String companySavedDescriptionScreen =
      '/company_saved_description_screen';

  static const String candiDescriptionThreeScreen =
      '/candi_description_three_screen';

  static const String companyApply21Screen = '/company_apply_2_1_screen';

  static const String savedCompanyApplyOneScreen =
      '/saved_company_apply_one_screen';

  static const String chatCandiThreeScreen = '/chat_candi_three_screen';

  static const String vhackUserProfileScreen = '/vhack_user_profile_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    vhackHomeCandiPageOneContainerScreen: (context) =>
        VhackHomeCandiPageOneContainerScreen(),
    videoUploadScreen: (context) => VideoUploadScreen(),
    candiProfileOneScreen: (context) => CandiProfileOneScreen(),
    vhackHomeCompaPageOneScreen: (context) => VhackHomeCompaPageOneScreen(),
    companyProfileOneScreen: (context) => CompanyProfileOneScreen(),
    vhackSavedCandiPageOneScreen: (context) => VhackSavedCandiPageOneScreen(),
    savedCandiProfileScreen: (context) => SavedCandiProfileScreen(),
    candiDescriptionOneScreen: (context) => CandiDescriptionOneScreen(),
    companyDescriptionOneScreen: (context) => CompanyDescriptionOneScreen(),
    savedCandiDescriptionScreen: (context) => SavedCandiDescriptionScreen(),
    chatCandiOneScreen: (context) => ChatCandiOneScreen(),
    companyApply13Screen: (context) => CompanyApply13Screen(),
    companyApply12Screen: (context) => CompanyApply12Screen(),
    companyApply11Screen: (context) => CompanyApply11Screen(),
    savedCandiChatScreen: (context) => SavedCandiChatScreen(),
    vhackHomeCompaPageTwoScreen: (context) => VhackHomeCompaPageTwoScreen(),
    companyProfileTwoScreen: (context) => CompanyProfileTwoScreen(),
    vhackSavedCompaPageOneScreen: (context) => VhackSavedCompaPageOneScreen(),
    companySavedProfileOneScreen: (context) => CompanySavedProfileOneScreen(),
    vhackHomeCandiPageThreeScreen: (context) => VhackHomeCandiPageThreeScreen(),
    candiProfileThreeScreen: (context) => CandiProfileThreeScreen(),
    companyDescriptionTwoScreen: (context) => CompanyDescriptionTwoScreen(),
    companySavedDescriptionScreen: (context) => CompanySavedDescriptionScreen(),
    candiDescriptionThreeScreen: (context) => CandiDescriptionThreeScreen(),
    companyApply21Screen: (context) => CompanyApply21Screen(),
    savedCompanyApplyOneScreen: (context) => SavedCompanyApplyOneScreen(),
    chatCandiThreeScreen: (context) => ChatCandiThreeScreen(),
    vhackUserProfileScreen: (context) => VhackUserProfileScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
