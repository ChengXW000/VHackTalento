import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color blueA700 = fromHex('#084fff');

  static Color blueGray10001 = fromHex('#d9d9d9');

  static Color gray500B2 = fromHex('#b2979797');

  static Color gray50 = fromHex('#f8f9fc');

  static Color whiteA70099 = fromHex('#99ffffff');

  static Color teal500 = fromHex('#0dae87');

  static Color black900 = fromHex('#000000');

  static Color black90063 = fromHex('#63000000');

  static Color blueGray700 = fromHex('#535353');

  static Color blueGray900 = fromHex('#373736');

  static Color black90026 = fromHex('#26000000');

  static Color black9004c = fromHex('#4c000000');

  static Color tealA700 = fromHex('#00bf9c');

  static Color blueGray100 = fromHex('#d0d1d3');

  static Color gray500 = fromHex('#959595');

  static Color blueGray400 = fromHex('#86878b');

  static Color blue800 = fromHex('#1350c6');

  static Color indigo50 = fromHex('#e8e5f2');

  static Color gray900 = fromHex('#171717');

  static Color gray90001 = fromHex('#161722');

  static Color gray200 = fromHex('#ebebeb');

  static Color gray100 = fromHex('#f5f5f4');

  static Color black90033 = fromHex('#33000000');

  static Color deepPurple9002d = fromHex('#2d30007e');

  static Color black90099 = fromHex('#99000000');

  static Color bluegray400 = fromHex('#888888');

  static Color black90019 = fromHex('#19000000');

  static Color black90014 = fromHex('#14000000');

  static Color whiteA700 = fromHex('#ffffff');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
