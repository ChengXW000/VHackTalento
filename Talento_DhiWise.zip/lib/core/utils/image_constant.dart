class ImageConstant {
  static String imgRectangle71 = 'assets/images/img_rectangle7_1.png';

  static String imgRectangle6 = 'assets/images/img_rectangle6.png';

  static String imgImage30 = 'assets/images/img_image30.png';

  static String imgImage33 = 'assets/images/img_image33.png';

  static String img90263225121 = 'assets/images/img_90263225121.png';

  static String imgRectangle112 = 'assets/images/img_rectangle11_2.png';

  static String imgRectangle7 = 'assets/images/img_rectangle7.png';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgBackground4 = 'assets/images/img_background_4.png';

  static String imgImage22 = 'assets/images/img_image22.png';

  static String imgImage2 = 'assets/images/img_image2.png';

  static String imgRectangle91 = 'assets/images/img_rectangle9_1.png';

  static String imgMaskgroup2 = 'assets/images/img_maskgroup_2.png';

  static String imgBackground1 = 'assets/images/img_background_1.png';

  static String imgVideo = 'assets/images/img_video.svg';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgRectangle72 = 'assets/images/img_rectangle7_2.png';

  static String imgFollowing1 = 'assets/images/img_following1.png';

  static String imgEllipse36 = 'assets/images/img_ellipse3_6.png';

  static String imgEllipse38 = 'assets/images/img_ellipse3_8.png';

  static String imgFiltersicon = 'assets/images/img_filtersicon.svg';

  static String imgEllipse5 = 'assets/images/img_ellipse5.png';

  static String imgEllipse42 = 'assets/images/img_ellipse42.png';

  static String imgEllipse3845x45 = 'assets/images/img_ellipse38_45x45.png';

  static String imgMaskgroup1 = 'assets/images/img_maskgroup_1.png';

  static String imgRectangle93 = 'assets/images/img_rectangle9_3.png';

  static String imgDownload = 'assets/images/img_download.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgBackground32x411 = 'assets/images/img_background_32x411.png';

  static String imgEllipse33 = 'assets/images/img_ellipse3_3.png';

  static String imgBackground3 = 'assets/images/img_background_3.png';

  static String imgAirplane = 'assets/images/img_airplane.svg';

  static String imgImage10 = 'assets/images/img_image10.png';

  static String imgRectangle92 = 'assets/images/img_rectangle9_2.png';

  static String imgRectangle63 = 'assets/images/img_rectangle6_3.png';

  static String imgRectangle83 = 'assets/images/img_rectangle8_3.png';

  static String imgEllipse40 = 'assets/images/img_ellipse40.png';

  static String imgImage24 = 'assets/images/img_image24.png';

  static String imgGroup71 = 'assets/images/img_group71.png';

  static String imgGroup41 = 'assets/images/img_group41.png';

  static String imgEllipse41 = 'assets/images/img_ellipse41.png';

  static String imgEllipse39 = 'assets/images/img_ellipse39.png';

  static String imgBakcgrounpic = 'assets/images/img_bakcgrounpic.png';

  static String imgVector1 = 'assets/images/img_vector1.svg';

  static String imgRectangle9 = 'assets/images/img_rectangle9.png';

  static String imgImage23 = 'assets/images/img_image23.png';

  static String imgImage31 = 'assets/images/img_image31.png';

  static String imgEllipse338x38 = 'assets/images/img_ellipse3_38x38.png';

  static String imgRectangle59 = 'assets/images/img_rectangle59.png';

  static String imgImage14 = 'assets/images/img_image14.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgEllipse545x45 = 'assets/images/img_ellipse5_45x45.png';

  static String imgBottomnavicons = 'assets/images/img_bottomnavicons.svg';

  static String imgImage2167x213 = 'assets/images/img_image2_167x213.png';

  static String imgMaskgroup204x414 = 'assets/images/img_maskgroup_204x414.png';

  static String imgImage32 = 'assets/images/img_image32.png';

  static String imgImage18 = 'assets/images/img_image18.png';

  static String imgJomhack = 'assets/images/img_jomhack.png';

  static String imgFigmaimg = 'assets/images/img_figmaimg.png';

  static String imgEllipse445x45 = 'assets/images/img_ellipse4_45x45.png';

  static String imgRectangle8117x120 =
      'assets/images/img_rectangle8_117x120.png';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgGroup18 = 'assets/images/img_group18.png';

  static String imgEllipse3 = 'assets/images/img_ellipse3.png';

  static String imgGroup120 = 'assets/images/img_group120.png';

  static String imgCimg = 'assets/images/img_cimg.png';

  static String imgArrowleftGray200 =
      'assets/images/img_arrowleft_gray_200.svg';

  static String imgImage21 = 'assets/images/img_image21.png';

  static String imgImage29 = 'assets/images/img_image29.png';

  static String imgGroup16 = 'assets/images/img_group16.png';

  static String imgRectangle73 = 'assets/images/img_rectangle7_3.png';

  static String imgRectangle6117x120 =
      'assets/images/img_rectangle6_117x120.png';

  static String imgRectangle111 = 'assets/images/img_rectangle11_1.png';

  static String imgGroup1 = 'assets/images/img_group1.png';

  static String imgFollowing4 = 'assets/images/img_following4.png';

  static String imgBackgroundpic = 'assets/images/img_backgroundpic.png';

  static String imgBackground5 = 'assets/images/img_background_5.png';

  static String imgEllipse37 = 'assets/images/img_ellipse3_7.png';

  static String imgAdsignstrokeicon = 'assets/images/img_adsignstrokeicon.svg';

  static String imgImage37 = 'assets/images/img_image37.png';

  static String imgRectangle62 = 'assets/images/img_rectangle6_2.png';

  static String imgRectangle11 = 'assets/images/img_rectangle11.png';

  static String imgImage28 = 'assets/images/img_image28.png';

  static String imgRectangle61 = 'assets/images/img_rectangle6_1.png';

  static String imgPythonimg = 'assets/images/img_pythonimg.png';

  static String imgImage11 = 'assets/images/img_image11.png';

  static String imgEllipse34 = 'assets/images/img_ellipse3_4.png';

  static String imgEllipse3100x100 = 'assets/images/img_ellipse3_100x100.png';

  static String imgImage15 = 'assets/images/img_image15.png';

  static String imgUserBlue400 = 'assets/images/img_user_blue_400.svg';

  static String imgImage25 = 'assets/images/img_image25.png';

  static String imgImage20 = 'assets/images/img_image20.png';

  static String imgImage34 = 'assets/images/img_image34.png';

  static String imgGroup127 = 'assets/images/img_group127.png';

  static String imgRectangle102 = 'assets/images/img_rectangle10_2.png';

  static String imgImage27 = 'assets/images/img_image27.png';

  static String imgRectangle113 = 'assets/images/img_rectangle11_3.png';

  static String imgAlarm = 'assets/images/img_alarm.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgRectangle81 = 'assets/images/img_rectangle8_1.png';

  static String imgCloseGray90001 = 'assets/images/img_close_gray_900_01.svg';

  static String imgRectangle11117x120 =
      'assets/images/img_rectangle11_117x120.png';

  static String imgCut = 'assets/images/img_cut.svg';

  static String imgGroup20 = 'assets/images/img_group20.png';

  static String imgEllipse32 = 'assets/images/img_ellipse3_2.png';

  static String imgRectangle82 = 'assets/images/img_rectangle8_2.png';

  static String imgImage35 = 'assets/images/img_image35.png';

  static String imgRectangle101 = 'assets/images/img_rectangle10_1.png';

  static String imgMaskgroup = 'assets/images/img_maskgroup.png';

  static String imgEllipse6 = 'assets/images/img_ellipse6.png';

  static String imgRectangle10 = 'assets/images/img_rectangle10.png';

  static String imgAsmimg = 'assets/images/img_asmimg.png';

  static String imgImage25100x100 = 'assets/images/img_image25_100x100.png';

  static String imgRectangle8 = 'assets/images/img_rectangle8.png';

  static String imgTrashBlue400 = 'assets/images/img_trash_blue_400.svg';

  static String img86668055121 = 'assets/images/img_86668055121.png';

  static String imgEllipse35 = 'assets/images/img_ellipse3_5.png';

  static String imgImage26 = 'assets/images/img_image26.png';

  static String imgEllipse345x45 = 'assets/images/img_ellipse3_45x45.png';

  static String imgEllipse43 = 'assets/images/img_ellipse43.png';

  static String imgRectangle103 = 'assets/images/img_rectangle10_3.png';

  static String imgGroup20852x414 = 'assets/images/img_group20_852x414.png';

  static String imgSamcheng128 = 'assets/images/img_samcheng128.png';

  static String imgQuestion = 'assets/images/img_question.svg';

  static String imgTrash = 'assets/images/img_trash.svg';

  static String imgRectangle9117x120 =
      'assets/images/img_rectangle9_117x120.png';

  static String imgRectangle7117x120 =
      'assets/images/img_rectangle7_117x120.png';

  static String imgImage36 = 'assets/images/img_image36.png';

  static String imgRectangle10117x120 =
      'assets/images/img_rectangle10_117x120.png';

  static String imgImage295x95 = 'assets/images/img_image2_95x95.png';

  static String imgBackground2 = 'assets/images/img_background_2.png';

  static String imgDatabox = 'assets/images/img_databox.svg';

  static String imgBackground6 = 'assets/images/img_background_6.png';

  static String imgUserBlack900 = 'assets/images/img_user_black_900.svg';

  static String imgEllipse347x47 = 'assets/images/img_ellipse3_47x47.png';

  static String imgEllipse48 = 'assets/images/img_ellipse48.png';

  static String imgFrame11 = 'assets/images/img_frame11.png';

  static String imgBackground = 'assets/images/img_background.png';

  static String imgEllipse4 = 'assets/images/img_ellipse4.png';

  static String imgEllipse31 = 'assets/images/img_ellipse3_1.png';

  static String imgImage19 = 'assets/images/img_image19.png';

  static String imgEllipse3745x45 = 'assets/images/img_ellipse37_45x45.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
