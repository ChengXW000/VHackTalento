import 'package:flutter/material.dart';
import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';

class AppStyle {
  static TextStyle txtRobotoRomanBold24 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      24,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoBlack11Bluegray400 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoRomanBold20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoBlack13Gray90001 = TextStyle(
    color: ColorConstant.gray90001,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoBlack13 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoBlack24 = TextStyle(
    color: ColorConstant.gray90001,
    fontSize: getFontSize(
      24,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoRomanBold20Gray90001 = TextStyle(
    color: ColorConstant.gray90001,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoBlack16 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoRomanBold18Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoBlack15 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoRomanRegular10Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoBlack20 = TextStyle(
    color: ColorConstant.gray90001,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoBlack13Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoBlack11 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoRegular15 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoBlack16WhiteA70099 = TextStyle(
    color: ColorConstant.whiteA70099,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoRegular16 = TextStyle(
    color: ColorConstant.bluegray400,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoBlack17 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtRobotoRomanRegular10 = TextStyle(
    color: ColorConstant.blueGray700,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanBold18 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoRomanLight12 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w300,
  );

  static TextStyle txtRobotoRegular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular10 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular11 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );
}
