import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class CompanyApply12Screen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: getVerticalSize(
            654,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                  width: double.maxFinite,
                  margin: getMargin(
                    bottom: 83,
                  ),
                  padding: getPadding(
                    left: 3,
                    right: 3,
                  ),
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: getPadding(
                          top: 11,
                          bottom: 543,
                        ),
                        child: Text(
                          "Chat",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoBlack13Gray90001,
                        ),
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgCloseGray90001,
                        height: getSize(
                          39,
                        ),
                        width: getSize(
                          39,
                        ),
                        margin: getMargin(
                          left: 152,
                          bottom: 532,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: Padding(
                          padding: getPadding(
                            right: 3,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: getPadding(
                                  top: 12,
                                  bottom: 10,
                                ),
                                child: Text(
                                  "Intern - Web Development",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtRobotoBlack13Gray90001,
                                ),
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgCloseGray90001,
                                height: getSize(
                                  39,
                                ),
                                width: getSize(
                                  39,
                                ),
                                margin: getMargin(
                                  left: 89,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 18,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 10,
                          right: 14,
                          bottom: 10,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Qualification",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                355,
                              ),
                              margin: getMargin(
                                top: 3,
                                bottom: 3,
                              ),
                              child: Text(
                                "Candidate must be currently undergoing a course in IT / Computer Science / Computer engineering.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 16,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 5,
                          right: 14,
                          bottom: 5,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Job Scope",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                355,
                              ),
                              margin: getMargin(
                                top: 3,
                                bottom: 3,
                              ),
                              child: Text(
                                "Involved in design, coding, testing and deployment of modern information systems. Candidates will have the opportunity to work on state of the art systems running  different programming platform.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 13,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 11,
                          right: 14,
                          bottom: 11,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: getPadding(
                                top: 1,
                              ),
                              child: Text(
                                "Looking for",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtRobotoBlack20,
                              ),
                            ),
                            Container(
                              width: getHorizontalSize(
                                348,
                              ),
                              margin: getMargin(
                                left: 6,
                                top: 1,
                                right: 1,
                              ),
                              child: Text(
                                "Candidate familiar with stored procedures, SQL, .NET development (Winforms & Web Development).\nCandidates that are familiar with HTML, Javascript etc.\nCandidates experience in OO Programming, 3-tier development and SQL is preferred.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 10,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 4,
                          right: 14,
                          bottom: 4,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: getPadding(
                                top: 11,
                              ),
                              child: Text(
                                "Benefits",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtRobotoBlack20,
                              ),
                            ),
                            Container(
                              width: getHorizontalSize(
                                348,
                              ),
                              margin: getMargin(
                                left: 6,
                                top: 7,
                                right: 1,
                              ),
                              child: Text(
                                "Candidates who prefer to travel may be given opportunities to travel; Candidates who prefer not to travel may work locally.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 15,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 8,
                          right: 14,
                          bottom: 8,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Prefer",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                348,
                              ),
                              margin: getMargin(
                                left: 6,
                                top: 5,
                                right: 1,
                                bottom: 1,
                              ),
                              child: Text(
                                "Candidates able to work well in a team, as well as individually.\nCandidates passionate about technology and enjoy software development, riding on the latest technologies.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      CustomButton(
                        width: getHorizontalSize(
                          85,
                        ),
                        text: "Apply",
                        margin: getMargin(
                          top: 10,
                        ),
                        variant: ButtonVariant.OutlineBlack90026,
                        shape: ButtonShape.RoundedBorder6,
                        fontStyle: ButtonFontStyle.InterSemiBold16,
                      ),
                      Container(
                        height: getVerticalSize(
                          17,
                        ),
                        width: double.maxFinite,
                        margin: getMargin(
                          top: 6,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.whiteA700,
                          boxShadow: [
                            BoxShadow(
                              color: ColorConstant.blueGray100,
                              spreadRadius: getHorizontalSize(
                                2,
                              ),
                              blurRadius: getHorizontalSize(
                                2,
                              ),
                              offset: Offset(
                                0,
                                -0.33,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
