import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class CandiDescriptionThreeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: getVerticalSize(
            717,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              CustomImageView(
                svgPath: ImageConstant.imgCloseGray90001,
                height: getSize(
                  39,
                ),
                width: getSize(
                  39,
                ),
                alignment: Alignment.topRight,
                margin: getMargin(
                  top: 187,
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  height: getVerticalSize(
                    583,
                  ),
                  width: double.maxFinite,
                  child: Stack(
                    alignment: Alignment.topCenter,
                    children: [
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          decoration: AppDecoration.fillGray100.copyWith(
                            borderRadius: BorderRadiusStyle.customBorderTL8,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: getPadding(
                                  top: 62,
                                ),
                                child: Text(
                                  "Samuel Cheng",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtRobotoBlack24,
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  118,
                                ),
                                width: getHorizontalSize(
                                  384,
                                ),
                                margin: getMargin(
                                  top: 27,
                                ),
                                decoration: BoxDecoration(
                                  color: ColorConstant.gray50,
                                  borderRadius: BorderRadius.circular(
                                    getHorizontalSize(
                                      8,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: getMargin(
                                  left: 14,
                                  top: 6,
                                  right: 16,
                                ),
                                padding: getPadding(
                                  left: 30,
                                  top: 11,
                                  right: 30,
                                  bottom: 11,
                                ),
                                decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder8,
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    CustomImageView(
                                      imagePath: ImageConstant.imgJomhack,
                                      height: getSize(
                                        60,
                                      ),
                                      width: getSize(
                                        60,
                                      ),
                                      radius: BorderRadius.circular(
                                        getHorizontalSize(
                                          20,
                                        ),
                                      ),
                                      margin: getMargin(
                                        top: 28,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 28,
                                        right: 40,
                                        bottom: 9,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Company: JomHack",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtRobotoBlack11Bluegray400,
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 4,
                                            ),
                                            child: Text(
                                              "Role         : Coordinator     ",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtRobotoBlack11Bluegray400,
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 6,
                                            ),
                                            child: Text(
                                              "Period     : Jun 2022 - Present",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtRobotoBlack11Bluegray400,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: getHorizontalSize(
                                  384,
                                ),
                                margin: getMargin(
                                  left: 14,
                                  top: 6,
                                  right: 16,
                                ),
                                padding: getPadding(
                                  left: 15,
                                  top: 5,
                                  right: 15,
                                  bottom: 5,
                                ),
                                decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder8,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Skills",
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtRobotoBlack20,
                                    ),
                                    Align(
                                      alignment: Alignment.center,
                                      child: Padding(
                                        padding: getPadding(
                                          left: 45,
                                          top: 10,
                                          right: 48,
                                          bottom: 8,
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            CustomImageView(
                                              imagePath: ImageConstant.imgCimg,
                                              height: getVerticalSize(
                                                44,
                                              ),
                                              width: getHorizontalSize(
                                                40,
                                              ),
                                            ),
                                            CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgAsmimg,
                                              height: getSize(
                                                44,
                                              ),
                                              width: getSize(
                                                44,
                                              ),
                                              margin: getMargin(
                                                left: 33,
                                              ),
                                            ),
                                            CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgPythonimg,
                                              height: getVerticalSize(
                                                44,
                                              ),
                                              width: getHorizontalSize(
                                                40,
                                              ),
                                              margin: getMargin(
                                                left: 33,
                                              ),
                                            ),
                                            CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgFigmaimg,
                                              height: getVerticalSize(
                                                44,
                                              ),
                                              width: getHorizontalSize(
                                                29,
                                              ),
                                              margin: getMargin(
                                                left: 40,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              CustomButton(
                                width: getHorizontalSize(
                                  91,
                                ),
                                text: "OFFER",
                                margin: getMargin(
                                  top: 9,
                                ),
                                variant: ButtonVariant.OutlineBlack90026,
                                shape: ButtonShape.RoundedBorder6,
                                fontStyle: ButtonFontStyle.InterSemiBold16,
                              ),
                              Container(
                                height: getVerticalSize(
                                  17,
                                ),
                                width: double.maxFinite,
                                margin: getMargin(
                                  top: 9,
                                ),
                                decoration: BoxDecoration(
                                  color: ColorConstant.whiteA700,
                                  boxShadow: [
                                    BoxShadow(
                                      color: ColorConstant.blueGray100,
                                      spreadRadius: getHorizontalSize(
                                        2,
                                      ),
                                      blurRadius: getHorizontalSize(
                                        2,
                                      ),
                                      offset: Offset(
                                        0,
                                        -0.33,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgEllipse38,
                        height: getSize(
                          100,
                        ),
                        width: getSize(
                          100,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            50,
                          ),
                        ),
                        alignment: Alignment.topCenter,
                      ),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Container(
                          height: getVerticalSize(
                            167,
                          ),
                          width: getHorizontalSize(
                            213,
                          ),
                          margin: getMargin(
                            top: 151,
                          ),
                          child: Stack(
                            alignment: Alignment.topLeft,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgImage2167x213,
                                height: getVerticalSize(
                                  167,
                                ),
                                width: getHorizontalSize(
                                  213,
                                ),
                                alignment: Alignment.center,
                              ),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                  padding: getPadding(
                                    left: 29,
                                    top: 21,
                                  ),
                                  child: Text(
                                    "Education",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtRobotoBlack20,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          width: getHorizontalSize(
                            193,
                          ),
                          margin: getMargin(
                            top: 208,
                            right: 33,
                          ),
                          child: Text(
                            "Course: Computer and Communication  \n               System Engineering",
                            maxLines: null,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoBlack11,
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Padding(
                          padding: getPadding(
                            top: 241,
                            right: 89,
                          ),
                          child: Text(
                            "Status : Ongoing (2nd Year)    ",
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoBlack11Bluegray400,
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Padding(
                          padding: getPadding(
                            top: 259,
                            right: 159,
                          ),
                          child: Text(
                            "YOG     : 2025",
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoBlack11Bluegray400,
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: Padding(
                          padding: getPadding(
                            left: 28,
                            bottom: 259,
                          ),
                          child: Text(
                            "Experience",
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoBlack20,
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Padding(
                          padding: getPadding(
                            top: 143,
                          ),
                          child: Text(
                            "#intern #engineering(EE) #operations",
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoBlack13Black90099,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
