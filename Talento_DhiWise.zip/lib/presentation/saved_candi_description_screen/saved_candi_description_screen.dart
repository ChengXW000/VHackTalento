import '../saved_candi_description_screen/widgets/listcompanynasa_item_widget.dart';
import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:flutter/material.dart';

class SavedCandiDescriptionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: getVerticalSize(
            717,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.topCenter,
            children: [
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomImageView(
                        svgPath: ImageConstant.imgCloseGray90001,
                        height: getSize(
                          39,
                        ),
                        width: getSize(
                          39,
                        ),
                        alignment: Alignment.centerRight,
                        margin: getMargin(
                          top: 3,
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          top: 20,
                        ),
                        child: Text(
                          "Jonny Kim",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoRomanBold20Gray90001,
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          top: 6,
                        ),
                        child: Text(
                          "#MD #USNavy #Astronaut",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoBlack13Black90099,
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 14,
                          top: 12,
                          right: 16,
                        ),
                        padding: getPadding(
                          left: 15,
                          top: 8,
                          right: 15,
                          bottom: 8,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "Experience",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Padding(
                              padding: getPadding(
                                left: 1,
                                top: 20,
                                right: 33,
                                bottom: 11,
                              ),
                              child: ListView.separated(
                                physics: NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                separatorBuilder: (context, index) {
                                  return SizedBox(
                                    height: getVerticalSize(
                                      1,
                                    ),
                                  );
                                },
                                itemCount: 3,
                                itemBuilder: (context, index) {
                                  return ListcompanynasaItemWidget();
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        height: getVerticalSize(
                          17,
                        ),
                        width: double.maxFinite,
                        margin: getMargin(
                          top: 39,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.whiteA700,
                          boxShadow: [
                            BoxShadow(
                              color: ColorConstant.blueGray100,
                              spreadRadius: getHorizontalSize(
                                2,
                              ),
                              blurRadius: getHorizontalSize(
                                2,
                              ),
                              offset: Offset(
                                0,
                                -0.33,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              CustomImageView(
                imagePath: ImageConstant.imgEllipse31,
                height: getSize(
                  100,
                ),
                width: getSize(
                  100,
                ),
                radius: BorderRadius.circular(
                  getHorizontalSize(
                    50,
                  ),
                ),
                alignment: Alignment.topCenter,
                margin: getMargin(
                  top: 134,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
