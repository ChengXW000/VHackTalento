import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListcompanynasaItemWidget extends StatelessWidget {
  ListcompanynasaItemWidget();

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomImageView(
          imagePath: ImageConstant.imgImage22,
          height: getSize(
            100,
          ),
          width: getSize(
            100,
          ),
        ),
        Padding(
          padding: getPadding(
            left: 50,
            top: 18,
            bottom: 31,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                "Company: NASA",
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtRobotoBlack11Bluegray400,
              ),
              Padding(
                padding: getPadding(
                  top: 4,
                ),
                child: Text(
                  "Role         : Astronaut ",
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtRobotoBlack11Bluegray400,
                ),
              ),
              Padding(
                padding: getPadding(
                  top: 6,
                ),
                child: Text(
                  "Period     : 2017 - Present",
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtRobotoBlack11Bluegray400,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
