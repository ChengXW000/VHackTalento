import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class SavedCompanyApplyOneScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: getVerticalSize(
            654,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                  width: double.maxFinite,
                  margin: getMargin(
                    bottom: 83,
                  ),
                  padding: getPadding(
                    left: 3,
                    right: 3,
                  ),
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: getPadding(
                          top: 11,
                          bottom: 543,
                        ),
                        child: Text(
                          "Chat",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoBlack13Gray90001,
                        ),
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgCloseGray90001,
                        height: getSize(
                          39,
                        ),
                        width: getSize(
                          39,
                        ),
                        margin: getMargin(
                          left: 152,
                          bottom: 532,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomAppBar(
                        height: getVerticalSize(
                          39,
                        ),
                        centerTitle: true,
                        title: Text(
                          "Senior Startup Ecosystem Executive",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoBlack13Gray90001,
                        ),
                        actions: [
                          AppbarImage(
                            height: getSize(
                              39,
                            ),
                            width: getSize(
                              39,
                            ),
                            svgPath: ImageConstant.imgCloseGray90001,
                            margin: getMargin(
                              left: 3,
                              right: 3,
                            ),
                          ),
                        ],
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 18,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 10,
                          right: 14,
                          bottom: 10,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Qualification",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                355,
                              ),
                              margin: getMargin(
                                top: 3,
                                bottom: 3,
                              ),
                              child: Text(
                                "Tertiary education in any field with preference for those with a business, communication or technology degree.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 16,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 13,
                          top: 5,
                          right: 13,
                          bottom: 5,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "Job Scope",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                355,
                              ),
                              margin: getMargin(
                                top: 3,
                                bottom: 6,
                              ),
                              child: Text(
                                "Ability to perform planning and execution of startup programs in many areas. Comfortable to engage with stakeholders of the ecosystem",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 12,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 7,
                          right: 14,
                          bottom: 7,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: getPadding(
                                top: 4,
                              ),
                              child: Text(
                                "Looking for",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtRobotoBlack20,
                              ),
                            ),
                            Container(
                              width: getHorizontalSize(
                                348,
                              ),
                              margin: getMargin(
                                left: 6,
                                top: 1,
                              ),
                              child: Text(
                                "Candidates with good written and spoken English and Bahasa Malaysia. Written Mandarin, Tamil and other languages is a plus.\nCandidate experience in event planning and management.\nCandidates ready to be based in Penang (not negotiable).",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 14,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 6,
                          right: 14,
                          bottom: 6,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Prefer",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                348,
                              ),
                              margin: getMargin(
                                left: 6,
                                top: 7,
                                bottom: 2,
                              ),
                              child: Text(
                                "Previous experience in similar role in any government or private startup ecosystem development company is a plus.\nDemonstrate interest and experience in the tech startup space.\nProfessional with good communication skills. Able to articulate yourself clearly.\nRespectful and have good interpersonal skills with people.\nLearn quickly, adapt fast with good self-discipline and organization capabilities.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      CustomButton(
                        width: getHorizontalSize(
                          85,
                        ),
                        text: "Apply",
                        margin: getMargin(
                          top: 46,
                        ),
                        variant: ButtonVariant.OutlineBlack90026,
                        shape: ButtonShape.RoundedBorder6,
                        fontStyle: ButtonFontStyle.InterSemiBold16,
                      ),
                      Container(
                        height: getVerticalSize(
                          17,
                        ),
                        width: double.maxFinite,
                        margin: getMargin(
                          top: 6,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.whiteA700,
                          boxShadow: [
                            BoxShadow(
                              color: ColorConstant.blueGray100,
                              spreadRadius: getHorizontalSize(
                                2,
                              ),
                              blurRadius: getHorizontalSize(
                                2,
                              ),
                              offset: Offset(
                                0,
                                -0.33,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
