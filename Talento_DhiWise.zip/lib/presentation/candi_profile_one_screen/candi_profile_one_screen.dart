import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_home_candi_page_one_page/vhack_home_candi_page_one_page.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_bottom_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_button.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

// ignore_for_file: must_be_immutable
class CandiProfileOneScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                height: size.height,
                width: double.maxFinite,
                child: Stack(alignment: Alignment.topCenter, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          decoration: AppDecoration.fillWhiteA700,
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                    height: getVerticalSize(43),
                                    width: double.maxFinite,
                                    decoration: BoxDecoration(
                                        color: ColorConstant.whiteA700,
                                        boxShadow: [
                                          BoxShadow(
                                              color: ColorConstant.blueGray100,
                                              spreadRadius:
                                                  getHorizontalSize(2),
                                              blurRadius: getHorizontalSize(2),
                                              offset: Offset(0, 1))
                                        ])),
                                Spacer(),
                                Padding(
                                    padding: getPadding(
                                        left: 11, right: 17, bottom: 96),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                              padding: getPadding(top: 4),
                                              child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                        decoration: AppDecoration
                                                            .outlineBlack90026
                                                            .copyWith(
                                                                borderRadius:
                                                                    BorderRadiusStyle
                                                                        .roundedBorder23),
                                                        child: Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Container(
                                                                  padding: getPadding(
                                                                      left: 40,
                                                                      top: 13,
                                                                      right: 40,
                                                                      bottom:
                                                                          13),
                                                                  decoration: BoxDecoration(
                                                                      image: DecorationImage(
                                                                          image: fs.Svg(ImageConstant
                                                                              .imgDatabox),
                                                                          fit: BoxFit
                                                                              .cover)),
                                                                  child: Column(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .end,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .end,
                                                                      children: [
                                                                        Container(
                                                                            width:
                                                                                getHorizontalSize(35),
                                                                            margin: getMargin(top: 13, right: 5),
                                                                            child: RichText(
                                                                                text: TextSpan(children: [
                                                                                  TextSpan(text: "108\n", style: TextStyle(color: ColorConstant.black900, fontSize: getFontSize(20), fontFamily: 'Roboto', fontWeight: FontWeight.w700)),
                                                                                  TextSpan(text: "Saves", style: TextStyle(color: ColorConstant.gray500, fontSize: getFontSize(11), fontFamily: 'Roboto', fontWeight: FontWeight.w300, letterSpacing: getHorizontalSize(0.06)))
                                                                                ]),
                                                                                textAlign: TextAlign.center)),
                                                                        Container(
                                                                            width:
                                                                                getHorizontalSize(48),
                                                                            margin: getMargin(top: 14),
                                                                            child: RichText(
                                                                                text: TextSpan(children: [
                                                                                  TextSpan(text: "988\n", style: TextStyle(color: ColorConstant.black900, fontSize: getFontSize(20), fontFamily: 'Roboto', fontWeight: FontWeight.w700)),
                                                                                  TextSpan(text: "Following", style: TextStyle(color: ColorConstant.gray500, fontSize: getFontSize(11), fontFamily: 'Roboto', fontWeight: FontWeight.w300, letterSpacing: getHorizontalSize(0.06)))
                                                                                ]),
                                                                                textAlign: TextAlign.center)),
                                                                        Container(
                                                                            width:
                                                                                getHorizontalSize(48),
                                                                            margin: getMargin(top: 28),
                                                                            child: RichText(
                                                                                text: TextSpan(children: [
                                                                                  TextSpan(text: "703\n", style: TextStyle(color: ColorConstant.black900, fontSize: getFontSize(20), fontFamily: 'Roboto', fontWeight: FontWeight.w700)),
                                                                                  TextSpan(text: "Followers", style: TextStyle(color: ColorConstant.gray500, fontSize: getFontSize(11), fontFamily: 'Roboto', fontWeight: FontWeight.w300, letterSpacing: getHorizontalSize(0.06)))
                                                                                ]),
                                                                                textAlign: TextAlign.center))
                                                                      ]))
                                                            ])),
                                                    Container(
                                                        margin:
                                                            getMargin(top: 22),
                                                        padding: getPadding(
                                                            left: 40,
                                                            top: 25,
                                                            right: 40,
                                                            bottom: 25),
                                                        decoration: AppDecoration
                                                            .fillGray50
                                                            .copyWith(
                                                                borderRadius:
                                                                    BorderRadiusStyle
                                                                        .roundedBorder23),
                                                        child: Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              CustomIconButton(
                                                                  height: 45,
                                                                  width: 45,
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                  child: CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgGroup20)),
                                                              CustomIconButton(
                                                                  height: 45,
                                                                  width: 45,
                                                                  margin:
                                                                      getMargin(
                                                                          top:
                                                                              20,
                                                                          bottom:
                                                                              4),
                                                                  alignment:
                                                                      Alignment
                                                                          .centerRight,
                                                                  child: CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgGroup18))
                                                            ]))
                                                  ])),
                                          Padding(
                                              padding: getPadding(
                                                  left: 7, bottom: 286),
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Padding(
                                                        padding:
                                                            getPadding(left: 3),
                                                        child: Text("Following",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtRobotoRomanBold18Black900)),
                                                    Align(
                                                        alignment: Alignment
                                                            .centerRight,
                                                        child: Padding(
                                                            padding: getPadding(
                                                                top: 5),
                                                            child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgEllipse42,
                                                                      height:
                                                                          getSize(
                                                                              45),
                                                                      width:
                                                                          getSize(
                                                                              45),
                                                                      radius: BorderRadius
                                                                          .circular(
                                                                              getHorizontalSize(22))),
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgEllipse43,
                                                                      height:
                                                                          getSize(
                                                                              45),
                                                                      width:
                                                                          getSize(
                                                                              45),
                                                                      radius: BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              22)),
                                                                      margin: getMargin(
                                                                          left:
                                                                              16)),
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgEllipse41,
                                                                      height:
                                                                          getSize(
                                                                              45),
                                                                      width:
                                                                          getSize(
                                                                              45),
                                                                      radius: BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              22)),
                                                                      margin: getMargin(
                                                                          left:
                                                                              17)),
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgEllipse48,
                                                                      height:
                                                                          getSize(
                                                                              45),
                                                                      width:
                                                                          getSize(
                                                                              45),
                                                                      radius: BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              22)),
                                                                      margin: getMargin(
                                                                          left:
                                                                              17))
                                                                ]))),
                                                    Padding(
                                                        padding:
                                                            getPadding(top: 23),
                                                        child: Text("Gallery",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtRobotoRomanBold18Black900))
                                                  ]))
                                        ]))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          height: getVerticalSize(204),
                          width: double.maxFinite,
                          child: Stack(alignment: Alignment.topLeft, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgBakcgrounpic,
                                height: getVerticalSize(204),
                                width: getHorizontalSize(414),
                                alignment: Alignment.center),
                            CustomImageView(
                                svgPath: ImageConstant.imgArrowleftGray200,
                                height: getVerticalSize(16),
                                width: getHorizontalSize(22),
                                alignment: Alignment.topLeft,
                                margin: getMargin(left: 18, top: 4),
                                onTap: () {
                                  onTapImgArrowleft(context);
                                })
                          ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          margin: getMargin(left: 11, top: 74, right: 10),
                          padding: getPadding(
                              left: 12, top: 19, right: 12, bottom: 19),
                          decoration: AppDecoration.outlineDeeppurple9002d
                              .copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder33),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Padding(
                                    padding: getPadding(top: 34),
                                    child: Text("Jaye",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtRobotoRomanBold20)),
                                Container(
                                    width: getHorizontalSize(362),
                                    margin:
                                        getMargin(left: 4, top: 10, right: 2),
                                    child: Text(
                                        "Currently a first-year student pursuing Computer and Communication System Engineering in University Putra Malaysia. Continue learning about science, technology, engineering and mathematics",
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtRobotoRomanLight12)),
                                Padding(
                                    padding: getPadding(top: 5),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Container(
                                              height: getSize(45),
                                              width: getSize(45),
                                              child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgUser,
                                                        height: getSize(45),
                                                        width: getSize(45),
                                                        alignment:
                                                            Alignment.center),
                                                    CustomImageView(
                                                        imagePath: ImageConstant
                                                            .imgImage15,
                                                        height: getSize(35),
                                                        width: getSize(35),
                                                        alignment:
                                                            Alignment.center)
                                                  ])),
                                          CustomIconButton(
                                              height: 45,
                                              width: 45,
                                              margin: getMargin(left: 29),
                                              child: CustomImageView(
                                                  imagePath: ImageConstant
                                                      .imgGroup16)),
                                          CustomIconButton(
                                              height: 45,
                                              width: 45,
                                              margin: getMargin(left: 29),
                                              child: CustomImageView(
                                                  imagePath:
                                                      ImageConstant.imgGroup18))
                                        ])),
                                Padding(
                                    padding: getPadding(left: 13, top: 15),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Expanded(
                                              child: CustomButton(
                                                  height: getVerticalSize(45),
                                                  text: "Resume",
                                                  margin:
                                                      getMargin(right: 10))),
                                          Expanded(
                                              child: CustomButton(
                                                  height: getVerticalSize(45),
                                                  text: "Follow",
                                                  margin: getMargin(left: 10)))
                                        ]))
                              ]))),
                  CustomImageView(
                      imagePath: ImageConstant.imgImage25100x100,
                      height: getSize(100),
                      width: getSize(100),
                      radius: BorderRadius.circular(getHorizontalSize(50)),
                      alignment: Alignment.topCenter,
                      margin: getMargin(top: 24)),
                  Align(
                      alignment: Alignment.bottomRight,
                      child: Padding(
                          padding: getPadding(right: 14),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CustomImageView(
                                          imagePath: ImageConstant.imgImage26,
                                          height: getVerticalSize(123),
                                          width: getHorizontalSize(121)),
                                      CustomImageView(
                                          imagePath: ImageConstant.imgImage30,
                                          height: getVerticalSize(122),
                                          width: getHorizontalSize(118),
                                          margin: getMargin(left: 8, bottom: 1))
                                    ]),
                                Padding(
                                    padding: getPadding(top: 7),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage28,
                                              height: getVerticalSize(123),
                                              width: getHorizontalSize(119)),
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage29,
                                              height: getVerticalSize(123),
                                              width: getHorizontalSize(120),
                                              margin: getMargin(left: 10))
                                        ])),
                                Padding(
                                    padding: getPadding(top: 6),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgRectangle10,
                                              height: getVerticalSize(118),
                                              width: getHorizontalSize(121),
                                              margin: getMargin(bottom: 9)),
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage27,
                                              height: getVerticalSize(127),
                                              width: getHorizontalSize(121),
                                              margin: getMargin(left: 8))
                                        ]))
                              ]))),
                  CustomImageView(
                      imagePath: ImageConstant.imgBackground32x411,
                      height: getVerticalSize(32),
                      width: getHorizontalSize(411),
                      alignment: Alignment.bottomCenter),
                  CustomIconButton(
                      height: 60,
                      width: 60,
                      margin: getMargin(left: 109, bottom: 33),
                      variant: IconButtonVariant.FillWhiteA700,
                      shape: IconButtonShape.CircleBorder30,
                      padding: IconButtonPadding.PaddingAll15,
                      alignment: Alignment.bottomLeft,
                      child: CustomImageView(
                          svgPath: ImageConstant.imgUserBlue400))
                ])),
            bottomNavigationBar:
                CustomBottomBar(onChanged: (BottomBarEnum type) {
              Navigator.pushNamed(
                  navigatorKey.currentContext!, getCurrentRoute(type));
            })));
  }

  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Bottomnavicons:
        return AppRoutes.vhackHomeCandiPageOnePage;
      default:
        return "/";
    }
  }

  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.vhackHomeCandiPageOnePage:
        return VhackHomeCandiPageOnePage();
      default:
        return DefaultWidget();
    }
  }

  onTapImgArrowleft(BuildContext context) {
    Navigator.pop(context);
  }
}
