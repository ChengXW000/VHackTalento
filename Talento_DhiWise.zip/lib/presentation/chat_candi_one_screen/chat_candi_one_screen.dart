import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class ChatCandiOneScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: getVerticalSize(
            571,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.topRight,
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: getPadding(
                    top: 11,
                  ),
                  child: Text(
                    "Chat",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtRobotoBlack13Gray90001,
                  ),
                ),
              ),
              CustomImageView(
                svgPath: ImageConstant.imgCloseGray90001,
                height: getSize(
                  39,
                ),
                width: getSize(
                  39,
                ),
                alignment: Alignment.topRight,
                margin: getMargin(
                  right: 3,
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  padding: getPadding(
                    left: 3,
                    right: 3,
                  ),
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Padding(
                            padding: getPadding(
                              top: 11,
                              bottom: 11,
                            ),
                            child: Text(
                              "Chat",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack13Gray90001,
                            ),
                          ),
                          CustomImageView(
                            svgPath: ImageConstant.imgCloseGray90001,
                            height: getSize(
                              39,
                            ),
                            width: getSize(
                              39,
                            ),
                            margin: getMargin(
                              left: 152,
                            ),
                          ),
                        ],
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Card(
                          clipBehavior: Clip.antiAlias,
                          elevation: 0,
                          margin: getMargin(
                            left: 15,
                            top: 31,
                          ),
                          color: ColorConstant.gray200,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(
                                getHorizontalSize(
                                  16,
                                ),
                              ),
                              bottomLeft: Radius.circular(
                                getHorizontalSize(
                                  16,
                                ),
                              ),
                              bottomRight: Radius.circular(
                                getHorizontalSize(
                                  16,
                                ),
                              ),
                            ),
                          ),
                          child: Container(
                            height: getVerticalSize(
                              68,
                            ),
                            width: getHorizontalSize(
                              267,
                            ),
                            padding: getPadding(
                              left: 10,
                              top: 1,
                              right: 10,
                              bottom: 1,
                            ),
                            decoration: AppDecoration.fillGray200.copyWith(
                              borderRadius: BorderRadiusStyle.customBorderBL16,
                            ),
                            child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                Align(
                                  alignment: Alignment.bottomRight,
                                  child: Text(
                                    "12:00",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtRobotoRomanRegular10,
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topCenter,
                                  child: Container(
                                    width: getHorizontalSize(
                                      243,
                                    ),
                                    margin: getMargin(
                                      top: 7,
                                    ),
                                    child: Text(
                                      "Dear Jaye, I’m reaching out to see if you’d be interested in a Product Intern role. Please let me know if you are available to discuss as we have a position which very much may interest you",
                                      maxLines: null,
                                      textAlign: TextAlign.left,
                                      style: AppStyle
                                          .txtRobotoRomanRegular10Black900,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      CustomButton(
                        height: getVerticalSize(
                          44,
                        ),
                        width: getHorizontalSize(
                          241,
                        ),
                        text: "Thank you for pm me, I will consider about it.",
                        margin: getMargin(
                          top: 26,
                          bottom: 363,
                        ),
                        variant: ButtonVariant.OutlineBlack90014,
                        shape: ButtonShape.CustomBorderTL24,
                        padding: ButtonPadding.PaddingAll16,
                        fontStyle: ButtonFontStyle.RobotoRomanRegular10,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Container(
          height: getVerticalSize(
            82,
          ),
          width: double.maxFinite,
          decoration: AppDecoration.outlineBluegray100,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: getPadding(
                    left: 18,
                    top: 15,
                    right: 16,
                    bottom: 45,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: getPadding(
                          bottom: 3,
                        ),
                        child: Text(
                          "Type Message ...",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoRegular15,
                        ),
                      ),
                      Spacer(),
                      CustomImageView(
                        svgPath: ImageConstant.imgAdsignstrokeicon,
                        height: getSize(
                          22,
                        ),
                        width: getSize(
                          22,
                        ),
                      ),
                      Container(
                        height: getSize(
                          22,
                        ),
                        width: getSize(
                          22,
                        ),
                        margin: getMargin(
                          left: 22,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.gray90001,
                          borderRadius: BorderRadius.circular(
                            getHorizontalSize(
                              11,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  width: double.maxFinite,
                  padding: getPadding(
                    left: 16,
                    top: 15,
                    right: 16,
                    bottom: 15,
                  ),
                  decoration: AppDecoration.outlineBluegray100,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: getPadding(
                          left: 1,
                          bottom: 33,
                        ),
                        child: Text(
                          "Type Message ...",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoRegular15,
                        ),
                      ),
                      Spacer(),
                      CustomImageView(
                        svgPath: ImageConstant.imgAdsignstrokeicon,
                        height: getSize(
                          22,
                        ),
                        width: getSize(
                          22,
                        ),
                        margin: getMargin(
                          bottom: 30,
                        ),
                      ),
                      Container(
                        height: getSize(
                          22,
                        ),
                        width: getSize(
                          22,
                        ),
                        margin: getMargin(
                          left: 22,
                          bottom: 30,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.gray90001,
                          borderRadius: BorderRadius.circular(
                            getHorizontalSize(
                              11,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
