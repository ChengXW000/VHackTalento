import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_subtitle.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_title.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class VhackHomeCandiPageOnePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Container(
          height: getVerticalSize(
            787,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.bottomRight,
            children: [
              CustomIconButton(
                height: 49,
                width: 49,
                margin: getMargin(
                  right: 6,
                  bottom: 97,
                ),
                variant: IconButtonVariant.GradientGray900Bluegray900,
                shape: IconButtonShape.RoundedBorder24,
                alignment: Alignment.bottomRight,
                child: CustomImageView(
                  imagePath: ImageConstant.imgFrame11,
                ),
              ),
              CustomImageView(
                imagePath: ImageConstant.img86668055121,
                height: getVerticalSize(
                  54,
                ),
                width: getHorizontalSize(
                  50,
                ),
                alignment: Alignment.bottomRight,
                margin: getMargin(
                  right: 5,
                  bottom: 344,
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  padding: getPadding(
                    top: 12,
                    bottom: 12,
                  ),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        ImageConstant.imgGroup120,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomAppBar(
                        height: getVerticalSize(
                          20,
                        ),
                        title: AppbarSubtitle(
                          text: "Candidates",
                          margin: getMargin(
                            left: 90,
                          ),
                        ),
                        actions: [
                          AppbarImage(
                            height: getVerticalSize(
                              11,
                            ),
                            width: getHorizontalSize(
                              1,
                            ),
                            svgPath: ImageConstant.imgVector1,
                            margin: getMargin(
                              left: 35,
                              top: 3,
                              bottom: 5,
                            ),
                          ),
                          AppbarTitle(
                            text: "Companies",
                            margin: getMargin(
                              left: 34,
                              top: 1,
                              right: 90,
                            ),
                          ),
                        ],
                      ),
                      Spacer(),
                      CustomImageView(
                        imagePath: ImageConstant.imgImage25,
                        height: getSize(
                          47,
                        ),
                        width: getSize(
                          47,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            23,
                          ),
                        ),
                        margin: getMargin(
                          right: 7,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.img86668055121,
                        height: getVerticalSize(
                          54,
                        ),
                        width: getHorizontalSize(
                          50,
                        ),
                        margin: getMargin(
                          top: 16,
                          right: 7,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgImage10,
                        height: getSize(
                          45,
                        ),
                        width: getSize(
                          45,
                        ),
                        margin: getMargin(
                          top: 23,
                          right: 8,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgImage11,
                        height: getSize(
                          40,
                        ),
                        width: getSize(
                          40,
                        ),
                        margin: getMargin(
                          top: 18,
                          right: 10,
                        ),
                      ),
                      Container(
                        height: getVerticalSize(
                          15,
                        ),
                        width: getHorizontalSize(
                          28,
                        ),
                        margin: getMargin(
                          top: 11,
                          right: 17,
                        ),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Align(
                              alignment: Alignment.center,
                              child: Container(
                                decoration: AppDecoration.txtOutlineBlack9004c,
                                child: Text(
                                  "Chat",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: AppStyle.txtRobotoBlack13,
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Container(
                                decoration: AppDecoration.txtOutlineBlack9004c,
                                child: Text(
                                  "Chat",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: AppStyle.txtRobotoBlack13,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: getPadding(
                            left: 12,
                            top: 1,
                            right: 39,
                            bottom: 93,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: getPadding(
                                    bottom: 36,
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Container(
                                        height: getVerticalSize(
                                          20,
                                        ),
                                        width: getHorizontalSize(
                                          94,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Align(
                                              alignment: Alignment.center,
                                              child: RichText(
                                                text: TextSpan(
                                                  children: [
                                                    TextSpan(
                                                      text: "@jaye",
                                                      style: TextStyle(
                                                        color: ColorConstant
                                                            .whiteA700,
                                                        fontSize: getFontSize(
                                                          17,
                                                        ),
                                                        fontFamily: 'Roboto',
                                                        fontWeight:
                                                            FontWeight.w900,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: " · ",
                                                      style: TextStyle(
                                                        color: ColorConstant
                                                            .whiteA70099,
                                                        fontSize: getFontSize(
                                                          17,
                                                        ),
                                                        fontFamily: 'Roboto',
                                                        fontWeight:
                                                            FontWeight.w900,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: "1-28",
                                                      style: TextStyle(
                                                        color: ColorConstant
                                                            .whiteA70099,
                                                        fontSize: getFontSize(
                                                          15,
                                                        ),
                                                        fontFamily: 'Roboto',
                                                        fontWeight:
                                                            FontWeight.w900,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.center,
                                              child: RichText(
                                                text: TextSpan(
                                                  children: [
                                                    TextSpan(
                                                      text: "@jaye",
                                                      style: TextStyle(
                                                        color: ColorConstant
                                                            .whiteA700,
                                                        fontSize: getFontSize(
                                                          17,
                                                        ),
                                                        fontFamily: 'Roboto',
                                                        fontWeight:
                                                            FontWeight.w900,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: " · ",
                                                      style: TextStyle(
                                                        color: ColorConstant
                                                            .whiteA70099,
                                                        fontSize: getFontSize(
                                                          17,
                                                        ),
                                                        fontFamily: 'Roboto',
                                                        fontWeight:
                                                            FontWeight.w900,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: "1-28",
                                                      style: TextStyle(
                                                        color: ColorConstant
                                                            .whiteA70099,
                                                        fontSize: getFontSize(
                                                          15,
                                                        ),
                                                        fontFamily: 'Roboto',
                                                        fontWeight:
                                                            FontWeight.w900,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: getVerticalSize(
                                          18,
                                        ),
                                        width: getHorizontalSize(
                                          292,
                                        ),
                                        margin: getMargin(
                                          top: 9,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Align(
                                              alignment: Alignment.center,
                                              child: Text(
                                                "#intern #engineering(EE) #engineering(SE)",
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style:
                                                    AppStyle.txtRobotoBlack15,
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.center,
                                              child: Text(
                                                "#intern #engineering(EE) #engineering(SE)",
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style:
                                                    AppStyle.txtRobotoBlack15,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgQuestion,
                                height: getVerticalSize(
                                  82,
                                ),
                                width: getHorizontalSize(
                                  58,
                                ),
                                margin: getMargin(
                                  left: 11,
                                  top: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              CustomIconButton(
                height: 60,
                width: 60,
                margin: getMargin(
                  left: 32,
                  bottom: 33,
                ),
                variant: IconButtonVariant.FillWhiteA700,
                shape: IconButtonShape.CircleBorder30,
                padding: IconButtonPadding.PaddingAll15,
                alignment: Alignment.bottomLeft,
                child: CustomImageView(
                  svgPath: ImageConstant.imgTrash,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
