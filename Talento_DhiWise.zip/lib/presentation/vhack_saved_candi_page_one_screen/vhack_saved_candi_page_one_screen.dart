import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_home_candi_page_one_page/vhack_home_candi_page_one_page.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_subtitle.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_title.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_bottom_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class VhackSavedCandiPageOneScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                height: size.height,
                width: double.maxFinite,
                child: Stack(alignment: Alignment.bottomRight, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding: getPadding(top: 11, bottom: 11),
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage(ImageConstant.imgGroup1),
                                  fit: BoxFit.cover)),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomAppBar(
                                    height: getVerticalSize(20),
                                    title: AppbarSubtitle(
                                        text: "Candidates",
                                        margin: getMargin(left: 90)),
                                    actions: [
                                      AppbarImage(
                                          height: getVerticalSize(11),
                                          width: getHorizontalSize(1),
                                          svgPath: ImageConstant.imgVector1,
                                          margin: getMargin(
                                              left: 35, top: 3, bottom: 5)),
                                      AppbarTitle(
                                          text: "Companies",
                                          margin: getMargin(
                                              left: 34, top: 1, right: 90),
                                          onTap: () => onTapCompanies(context))
                                    ]),
                                Spacer(),
                                Padding(
                                    padding: getPadding(
                                        left: 12, right: 5, bottom: 86),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Padding(
                                              padding: getPadding(
                                                  top: 269, bottom: 44),
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    RichText(
                                                        text:
                                                            TextSpan(children: [
                                                          TextSpan(
                                                              text:
                                                                  "@Jonny Kim",
                                                              style: TextStyle(
                                                                  color: ColorConstant
                                                                      .whiteA700,
                                                                  fontSize:
                                                                      getFontSize(
                                                                          17),
                                                                  fontFamily:
                                                                      'Roboto',
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w900)),
                                                          TextSpan(
                                                              text: " · ",
                                                              style: TextStyle(
                                                                  color: ColorConstant
                                                                      .whiteA70099,
                                                                  fontSize:
                                                                      getFontSize(
                                                                          17),
                                                                  fontFamily:
                                                                      'Roboto',
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w900)),
                                                          TextSpan(
                                                              text: "1-28",
                                                              style: TextStyle(
                                                                  color: ColorConstant
                                                                      .whiteA70099,
                                                                  fontSize:
                                                                      getFontSize(
                                                                          15),
                                                                  fontFamily:
                                                                      'Roboto',
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w900))
                                                        ]),
                                                        textAlign:
                                                            TextAlign.left),
                                                    Padding(
                                                        padding:
                                                            getPadding(top: 11),
                                                        child: Text("#",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtRobotoBlack15)),
                                                    Text(
                                                        "#MD #USNavy #Astronaut",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtRobotoBlack15)
                                                  ])),
                                          Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgEllipse347x47,
                                                    height: getSize(47),
                                                    width: getSize(47),
                                                    radius:
                                                        BorderRadius.circular(
                                                            getHorizontalSize(
                                                                23)),
                                                    margin: getMargin(right: 2),
                                                    onTap: () {
                                                      onTapImgEllipseThree(
                                                          context);
                                                    }),
                                                CustomImageView(
                                                    imagePath: ImageConstant
                                                        .img86668055121,
                                                    height: getVerticalSize(54),
                                                    width:
                                                        getHorizontalSize(50),
                                                    margin: getMargin(top: 18)),
                                                Container(
                                                    margin:
                                                        getMargin(right: 10),
                                                    decoration: AppDecoration
                                                        .txtOutlineBlack9004c,
                                                    child: Text("100K",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: AppStyle
                                                            .txtRobotoBlack13)),
                                                CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgImage10,
                                                    height: getSize(45),
                                                    width: getSize(45),
                                                    margin: getMargin(
                                                        top: 8, right: 3),
                                                    onTap: () {
                                                      onTapImgImageTen(context);
                                                    }),
                                                CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgImage11,
                                                    height: getSize(40),
                                                    width: getSize(40),
                                                    margin: getMargin(
                                                        top: 18, right: 5),
                                                    onTap: () {
                                                      onTapImgImageEleven(
                                                          context);
                                                    }),
                                                Container(
                                                    margin: getMargin(
                                                        top: 11, right: 12),
                                                    decoration: AppDecoration
                                                        .txtOutlineBlack9004c,
                                                    child: Text("Chat",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: AppStyle
                                                            .txtRobotoBlack13)),
                                                Container(
                                                    height: getSize(91),
                                                    width: getSize(91),
                                                    margin: getMargin(
                                                        top: 2, right: 1),
                                                    child: Stack(
                                                        alignment: Alignment
                                                            .bottomRight,
                                                        children: [
                                                          CustomImageView(
                                                              svgPath:
                                                                  ImageConstant
                                                                      .imgQuestion,
                                                              height:
                                                                  getVerticalSize(
                                                                      82),
                                                              width:
                                                                  getHorizontalSize(
                                                                      58),
                                                              alignment:
                                                                  Alignment
                                                                      .topLeft),
                                                          CustomIconButton(
                                                              height: 49,
                                                              width: 49,
                                                              variant:
                                                                  IconButtonVariant
                                                                      .GradientGray900Bluegray900,
                                                              shape: IconButtonShape
                                                                  .RoundedBorder24,
                                                              alignment: Alignment
                                                                  .bottomRight,
                                                              child: CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgFrame11))
                                                        ]))
                                              ])
                                        ]))
                              ]))),
                  Align(
                      alignment: Alignment.bottomRight,
                      child: Card(
                          clipBehavior: Clip.antiAlias,
                          elevation: 0,
                          margin: getMargin(right: 103, bottom: 33),
                          color: ColorConstant.whiteA700,
                          shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(getHorizontalSize(30))),
                          child: Container(
                              height: getSize(60),
                              width: getSize(60),
                              padding: getPadding(all: 7),
                              decoration: AppDecoration.fillWhiteA700.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.circleBorder30),
                              child: Stack(children: [
                                CustomImageView(
                                    imagePath: ImageConstant.img90263225121,
                                    height: getSize(45),
                                    width: getSize(45),
                                    alignment: Alignment.center)
                              ]))))
                ])),
            bottomNavigationBar:
                CustomBottomBar(onChanged: (BottomBarEnum type) {
              Navigator.pushNamed(
                  navigatorKey.currentContext!, getCurrentRoute(type));
            })));
  }

  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Bottomnavicons:
        return AppRoutes.vhackHomeCandiPageOnePage;
      default:
        return "/";
    }
  }

  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.vhackHomeCandiPageOnePage:
        return VhackHomeCandiPageOnePage();
      default:
        return DefaultWidget();
    }
  }

  onTapCompanies(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.vhackSavedCompaPageOneScreen);
  }

  onTapImgEllipseThree(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.savedCandiProfileScreen);
  }

  onTapImgImageTen(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.savedCandiDescriptionScreen);
  }

  onTapImgImageEleven(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.savedCandiChatScreen);
  }
}
