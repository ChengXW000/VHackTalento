import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_button.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

class CandiProfileThreeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          height: getVerticalSize(853),
                          width: double.maxFinite,
                          child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        decoration: AppDecoration.fillWhiteA700,
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Container(
                                                  height: getVerticalSize(44),
                                                  width: double.maxFinite,
                                                  decoration: BoxDecoration(
                                                      color: ColorConstant
                                                          .whiteA700,
                                                      boxShadow: [
                                                        BoxShadow(
                                                            color: ColorConstant
                                                                .blueGray100,
                                                            spreadRadius:
                                                                getHorizontalSize(
                                                                    2),
                                                            blurRadius:
                                                                getHorizontalSize(
                                                                    2),
                                                            offset:
                                                                Offset(0, 1))
                                                      ])),
                                              Spacer(),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 11,
                                                      right: 14,
                                                      bottom: 1),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Padding(
                                                            padding: getPadding(
                                                                top: 4,
                                                                bottom: 95),
                                                            child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Container(
                                                                      decoration: AppDecoration
                                                                          .outlineBlack90026
                                                                          .copyWith(
                                                                              borderRadius: BorderRadiusStyle
                                                                                  .roundedBorder23),
                                                                      child: Column(
                                                                          mainAxisSize: MainAxisSize
                                                                              .min,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          children: [
                                                                            Container(
                                                                                padding: getPadding(left: 39, top: 13, right: 39, bottom: 13),
                                                                                decoration: BoxDecoration(image: DecorationImage(image: fs.Svg(ImageConstant.imgDatabox), fit: BoxFit.cover)),
                                                                                child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.end, children: [
                                                                                  Container(
                                                                                      width: getHorizontalSize(35),
                                                                                      margin: getMargin(top: 13, right: 6),
                                                                                      child: RichText(
                                                                                          text: TextSpan(children: [
                                                                                            TextSpan(text: "888\n", style: TextStyle(color: ColorConstant.black900, fontSize: getFontSize(20), fontFamily: 'Roboto', fontWeight: FontWeight.w700)),
                                                                                            TextSpan(text: "Saves", style: TextStyle(color: ColorConstant.gray500, fontSize: getFontSize(11), fontFamily: 'Roboto', fontWeight: FontWeight.w300, letterSpacing: getHorizontalSize(0.06)))
                                                                                          ]),
                                                                                          textAlign: TextAlign.center)),
                                                                                  Container(
                                                                                      width: getHorizontalSize(48),
                                                                                      margin: getMargin(top: 17),
                                                                                      child: RichText(
                                                                                          text: TextSpan(children: [
                                                                                            TextSpan(text: "10K\n", style: TextStyle(color: ColorConstant.black900, fontSize: getFontSize(20), fontFamily: 'Roboto', fontWeight: FontWeight.w700)),
                                                                                            TextSpan(text: "Following", style: TextStyle(color: ColorConstant.gray500, fontSize: getFontSize(11), fontFamily: 'Roboto', fontWeight: FontWeight.w300, letterSpacing: getHorizontalSize(0.06)))
                                                                                          ]),
                                                                                          textAlign: TextAlign.center)),
                                                                                  Align(
                                                                                      alignment: Alignment.center,
                                                                                      child: Container(
                                                                                          width: getHorizontalSize(48),
                                                                                          margin: getMargin(top: 25),
                                                                                          child: RichText(
                                                                                              text: TextSpan(children: [
                                                                                                TextSpan(text: "0\n", style: TextStyle(color: ColorConstant.black900, fontSize: getFontSize(20), fontFamily: 'Roboto', fontWeight: FontWeight.w700)),
                                                                                                TextSpan(text: "Followers", style: TextStyle(color: ColorConstant.gray500, fontSize: getFontSize(11), fontFamily: 'Roboto', fontWeight: FontWeight.w300, letterSpacing: getHorizontalSize(0.06)))
                                                                                              ]),
                                                                                              textAlign: TextAlign.center)))
                                                                                ]))
                                                                          ])),
                                                                  Container(
                                                                      margin: getMargin(
                                                                          top:
                                                                              22),
                                                                      padding: getPadding(
                                                                          left:
                                                                              40,
                                                                          top:
                                                                              25,
                                                                          right:
                                                                              40,
                                                                          bottom:
                                                                              25),
                                                                      decoration: AppDecoration
                                                                          .fillGray50
                                                                          .copyWith(
                                                                              borderRadius: BorderRadiusStyle
                                                                                  .roundedBorder23),
                                                                      child: Column(
                                                                          mainAxisSize: MainAxisSize
                                                                              .min,
                                                                          crossAxisAlignment: CrossAxisAlignment
                                                                              .start,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.center,
                                                                          children: [
                                                                            CustomIconButton(
                                                                                height: 45,
                                                                                width: 45,
                                                                                alignment: Alignment.center,
                                                                                child: CustomImageView(imagePath: ImageConstant.imgGroup20)),
                                                                            CustomIconButton(
                                                                                height: 45,
                                                                                width: 45,
                                                                                margin: getMargin(top: 20, bottom: 4),
                                                                                alignment: Alignment.centerRight,
                                                                                child: CustomImageView(imagePath: ImageConstant.imgGroup18))
                                                                          ]))
                                                                ])),
                                                        Padding(
                                                            padding: getPadding(
                                                                left: 7),
                                                            child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              3),
                                                                      child: Text(
                                                                          "Following",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtRobotoRomanBold18Black900)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              4,
                                                                          top:
                                                                              5),
                                                                      child: Row(
                                                                          children: [
                                                                            CustomImageView(
                                                                                imagePath: ImageConstant.imgFollowing1,
                                                                                height: getSize(45),
                                                                                width: getSize(45),
                                                                                radius: BorderRadius.circular(getHorizontalSize(22)),
                                                                                onTap: () {
                                                                                  onTapImgFollowingOne(context);
                                                                                }),
                                                                            CustomImageView(
                                                                                imagePath: ImageConstant.imgEllipse5,
                                                                                height: getSize(45),
                                                                                width: getSize(45),
                                                                                radius: BorderRadius.circular(getHorizontalSize(22)),
                                                                                margin: getMargin(left: 24),
                                                                                onTap: () {
                                                                                  onTapImgFollowingTwo(context);
                                                                                }),
                                                                            CustomImageView(
                                                                                imagePath: ImageConstant.imgEllipse33,
                                                                                height: getSize(45),
                                                                                width: getSize(45),
                                                                                radius: BorderRadius.circular(getHorizontalSize(22)),
                                                                                margin: getMargin(left: 20),
                                                                                onTap: () {
                                                                                  onTapImgFollowingThree(context);
                                                                                }),
                                                                            CustomImageView(
                                                                                imagePath: ImageConstant.imgFollowing4,
                                                                                height: getSize(45),
                                                                                width: getSize(45),
                                                                                radius: BorderRadius.circular(getHorizontalSize(22)),
                                                                                margin: getMargin(left: 21),
                                                                                onTap: () {
                                                                                  onTapImgFollowingFour(context);
                                                                                })
                                                                          ])),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          top:
                                                                              23),
                                                                      child: Text(
                                                                          "Gallery",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtRobotoRomanBold18Black900)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              3,
                                                                          top:
                                                                              4),
                                                                      child: Row(
                                                                          children: [
                                                                            CustomImageView(
                                                                                imagePath: ImageConstant.imgRectangle63,
                                                                                height: getVerticalSize(117),
                                                                                width: getHorizontalSize(120)),
                                                                            CustomImageView(
                                                                                imagePath: ImageConstant.imgRectangle73,
                                                                                height: getVerticalSize(117),
                                                                                width: getHorizontalSize(120),
                                                                                margin: getMargin(left: 8))
                                                                          ])),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              3,
                                                                          top:
                                                                              11),
                                                                      child: Row(
                                                                          children: [
                                                                            CustomImageView(
                                                                                imagePath: ImageConstant.imgRectangle83,
                                                                                height: getVerticalSize(117),
                                                                                width: getHorizontalSize(120)),
                                                                            CustomImageView(
                                                                                imagePath: ImageConstant.imgRectangle93,
                                                                                height: getVerticalSize(117),
                                                                                width: getHorizontalSize(120),
                                                                                margin: getMargin(left: 8))
                                                                          ])),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              3,
                                                                          top:
                                                                              11),
                                                                      child: Row(
                                                                          children: [
                                                                            CustomImageView(
                                                                                imagePath: ImageConstant.imgRectangle10,
                                                                                height: getVerticalSize(117),
                                                                                width: getHorizontalSize(120)),
                                                                            CustomImageView(
                                                                                imagePath: ImageConstant.imgRectangle113,
                                                                                height: getVerticalSize(117),
                                                                                width: getHorizontalSize(120),
                                                                                margin: getMargin(left: 8))
                                                                          ]))
                                                                ]))
                                                      ]))
                                            ]))),
                                Align(
                                    alignment: Alignment.topCenter,
                                    child: Container(
                                        height: getVerticalSize(205),
                                        width: double.maxFinite,
                                        child: Stack(
                                            alignment: Alignment.topLeft,
                                            children: [
                                              CustomImageView(
                                                  imagePath: ImageConstant
                                                      .imgBackgroundpic,
                                                  height: getVerticalSize(205),
                                                  width: getHorizontalSize(414),
                                                  alignment: Alignment.center),
                                              CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgArrowleftGray200,
                                                  height: getVerticalSize(16),
                                                  width: getHorizontalSize(22),
                                                  alignment: Alignment.topLeft,
                                                  margin: getMargin(
                                                      left: 18, top: 5),
                                                  onTap: () {
                                                    onTapImgArrowleft(context);
                                                  })
                                            ]))),
                                Align(
                                    alignment: Alignment.topCenter,
                                    child: Container(
                                        margin: getMargin(
                                            left: 11, top: 75, right: 10),
                                        padding: getPadding(
                                            left: 12,
                                            top: 19,
                                            right: 12,
                                            bottom: 19),
                                        decoration: AppDecoration
                                            .outlineDeeppurple9002d
                                            .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .roundedBorder33),
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              Padding(
                                                  padding: getPadding(top: 33),
                                                  child: Text("Samuel Cheng",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtRobotoRomanBold20)),
                                              Container(
                                                  width: getHorizontalSize(316),
                                                  margin: getMargin(
                                                      left: 27,
                                                      top: 7,
                                                      right: 24),
                                                  child: Text(
                                                      "Currently a student pursuing Computer and Communication System Engineering in University Putra Malaysia. Passionate about technology, science, engineering and investing.",
                                                      maxLines: null,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: AppStyle
                                                          .txtRobotoRomanLight12)),
                                              Padding(
                                                  padding: getPadding(top: 9),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Container(
                                                            height: getSize(45),
                                                            width: getSize(45),
                                                            child: Stack(
                                                                alignment:
                                                                    Alignment
                                                                        .center,
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgUser,
                                                                      height:
                                                                          getSize(
                                                                              45),
                                                                      width:
                                                                          getSize(
                                                                              45),
                                                                      alignment:
                                                                          Alignment
                                                                              .center),
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgImage15,
                                                                      height:
                                                                          getSize(
                                                                              35),
                                                                      width:
                                                                          getSize(
                                                                              35),
                                                                      alignment:
                                                                          Alignment
                                                                              .center)
                                                                ])),
                                                        CustomIconButton(
                                                            height: 45,
                                                            width: 45,
                                                            margin: getMargin(
                                                                left: 29),
                                                            child: CustomImageView(
                                                                imagePath:
                                                                    ImageConstant
                                                                        .imgGroup16)),
                                                        CustomIconButton(
                                                            height: 45,
                                                            width: 45,
                                                            margin: getMargin(
                                                                left: 29),
                                                            child: CustomImageView(
                                                                imagePath:
                                                                    ImageConstant
                                                                        .imgGroup18))
                                                      ])),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 13, top: 15),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        45),
                                                                text: "Resume",
                                                                margin: getMargin(
                                                                    right:
                                                                        10))),
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        45),
                                                                text: "Follow",
                                                                margin:
                                                                    getMargin(
                                                                        left:
                                                                            10)))
                                                      ]))
                                            ]))),
                                CustomImageView(
                                    imagePath: ImageConstant.imgImage295x95,
                                    height: getSize(95),
                                    width: getSize(95),
                                    radius: BorderRadius.circular(
                                        getHorizontalSize(47)),
                                    alignment: Alignment.topCenter,
                                    margin: getMargin(top: 27)),
                                CustomImageView(
                                    imagePath: ImageConstant.imgBackground5,
                                    height: getVerticalSize(32),
                                    width: getHorizontalSize(411),
                                    alignment: Alignment.bottomCenter)
                              ]))
                    ]))));
  }

  onTapImgFollowingOne(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.vhackSavedCompaPageOneScreen);
  }

  onTapImgFollowingTwo(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.vhackHomeCompaPageTwoScreen);
  }

  onTapImgFollowingThree(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.vhackHomeCompaPageOneScreen);
  }

  onTapImgFollowingFour(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.vhackSavedCandiPageOneScreen);
  }

  onTapImgArrowleft(BuildContext context) {
    Navigator.pop(context);
  }
}
