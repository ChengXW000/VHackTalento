import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class CompanyApply21Screen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: getVerticalSize(
            654,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                  width: double.maxFinite,
                  margin: getMargin(
                    bottom: 83,
                  ),
                  padding: getPadding(
                    left: 3,
                    right: 3,
                  ),
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: getPadding(
                          top: 11,
                          bottom: 543,
                        ),
                        child: Text(
                          "Chat",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoBlack13Gray90001,
                        ),
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgCloseGray90001,
                        height: getSize(
                          39,
                        ),
                        width: getSize(
                          39,
                        ),
                        margin: getMargin(
                          left: 152,
                          bottom: 532,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: Padding(
                          padding: getPadding(
                            left: 101,
                            right: 3,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: getPadding(
                                  top: 12,
                                  bottom: 10,
                                ),
                                child: Text(
                                  "Fresh Graduate - Software Engineer",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtRobotoBlack13Gray90001,
                                ),
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgCloseGray90001,
                                height: getSize(
                                  39,
                                ),
                                width: getSize(
                                  39,
                                ),
                                margin: getMargin(
                                  left: 60,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 18,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 13,
                          top: 10,
                          right: 13,
                          bottom: 10,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Qualification",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                355,
                              ),
                              margin: getMargin(
                                top: 3,
                                bottom: 3,
                              ),
                              child: Text(
                                "A Bachelor’s Degree in Information Technology, Computer Science or equivalent education. (CGPA > 3.5)",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 16,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 5,
                          right: 14,
                          bottom: 5,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Job Scope",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                355,
                              ),
                              margin: getMargin(
                                top: 3,
                                bottom: 2,
                              ),
                              child: Text(
                                "Carry out the developer role in a Scrum Team and translate user stories into technical implementation.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 14,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 12,
                          right: 14,
                          bottom: 12,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Looking for",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                348,
                              ),
                              margin: getMargin(
                                left: 6,
                                top: 1,
                                right: 1,
                                bottom: 3,
                              ),
                              child: Text(
                                "Candidates with good command of English (spoken and written) as well as communication / convincing skills\nCandidate’s ability and willingness to learn new things - Strong ability to pickup new technical topics quickly and apply them to assignments\nCandidates experience Conceptional and analytical skills with hands-on software development experience (e.g Java, APEX, C# or equivalent)",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 14,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 6,
                          right: 14,
                          bottom: 6,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Benefits",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                348,
                              ),
                              margin: getMargin(
                                left: 6,
                                top: 7,
                                right: 1,
                                bottom: 1,
                              ),
                              child: Text(
                                "Show us what you are made of, and we will offer you opportunities to move around the business – to work abroad, experience different job functions and tackle different markets. It is a wonderful way to find the right match for your ambitions and achieve the exciting career you are after.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      CustomButton(
                        width: getHorizontalSize(
                          85,
                        ),
                        text: "Apply",
                        margin: getMargin(
                          top: 52,
                        ),
                        variant: ButtonVariant.OutlineBlack90026,
                        shape: ButtonShape.RoundedBorder6,
                        fontStyle: ButtonFontStyle.InterSemiBold16,
                      ),
                      Container(
                        height: getVerticalSize(
                          17,
                        ),
                        width: double.maxFinite,
                        margin: getMargin(
                          top: 6,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.whiteA700,
                          boxShadow: [
                            BoxShadow(
                              color: ColorConstant.blueGray100,
                              spreadRadius: getHorizontalSize(
                                2,
                              ),
                              blurRadius: getHorizontalSize(
                                2,
                              ),
                              offset: Offset(
                                0,
                                -0.33,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
