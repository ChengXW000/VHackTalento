import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_home_candi_page_one_page/vhack_home_candi_page_one_page.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_subtitle.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_title.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_bottom_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class VhackHomeCandiPageThreeScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: getVerticalSize(
            853,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.bottomRight,
                child: Padding(
                  padding: getPadding(
                    right: 5,
                    bottom: 97,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.img86668055121,
                        height: getVerticalSize(
                          54,
                        ),
                        width: getHorizontalSize(
                          50,
                        ),
                        alignment: Alignment.center,
                      ),
                      CustomIconButton(
                        height: 49,
                        width: 49,
                        margin: getMargin(
                          top: 197,
                        ),
                        variant: IconButtonVariant.GradientGray900Bluegray900,
                        shape: IconButtonShape.RoundedBorder24,
                        child: CustomImageView(
                          imagePath: ImageConstant.imgFrame11,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  padding: getPadding(
                    top: 12,
                    bottom: 12,
                  ),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        ImageConstant.imgGroup127,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomAppBar(
                        height: getVerticalSize(
                          20,
                        ),
                        title: AppbarSubtitle(
                          text: "Candidates",
                          margin: getMargin(
                            left: 90,
                          ),
                        ),
                        actions: [
                          AppbarImage(
                            height: getVerticalSize(
                              11,
                            ),
                            width: getHorizontalSize(
                              1,
                            ),
                            svgPath: ImageConstant.imgVector1,
                            margin: getMargin(
                              left: 35,
                              top: 3,
                              bottom: 5,
                            ),
                          ),
                          AppbarTitle(
                            text: "Companies",
                            margin: getMargin(
                              left: 34,
                              top: 1,
                              right: 90,
                            ),
                          ),
                        ],
                      ),
                      Spacer(),
                      CustomImageView(
                        imagePath: ImageConstant.imgEllipse37,
                        height: getSize(
                          47,
                        ),
                        width: getSize(
                          47,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            23,
                          ),
                        ),
                        margin: getMargin(
                          right: 7,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.img86668055121,
                        height: getVerticalSize(
                          54,
                        ),
                        width: getHorizontalSize(
                          50,
                        ),
                        margin: getMargin(
                          top: 18,
                          right: 5,
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          right: 19,
                        ),
                        decoration: AppDecoration.txtOutlineBlack9004c,
                        child: Text(
                          "888",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: AppStyle.txtRobotoBlack13,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgImage10,
                        height: getSize(
                          45,
                        ),
                        width: getSize(
                          45,
                        ),
                        margin: getMargin(
                          top: 8,
                          right: 8,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgImage11,
                        height: getSize(
                          40,
                        ),
                        width: getSize(
                          40,
                        ),
                        margin: getMargin(
                          top: 18,
                          right: 10,
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          top: 11,
                          right: 17,
                        ),
                        decoration: AppDecoration.txtOutlineBlack9004c,
                        child: Text(
                          "Chat",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: AppStyle.txtRobotoBlack13,
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: getPadding(
                            left: 12,
                            top: 1,
                            right: 39,
                            bottom: 93,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: getPadding(
                                  bottom: 36,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    CustomImageView(
                                      imagePath: ImageConstant.imgSamcheng128,
                                      height: getVerticalSize(
                                        20,
                                      ),
                                      width: getHorizontalSize(
                                        146,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 9,
                                      ),
                                      child: Text(
                                        "#intern #engineering(EE) #operations",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtRobotoBlack15,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgQuestion,
                                height: getVerticalSize(
                                  82,
                                ),
                                width: getHorizontalSize(
                                  58,
                                ),
                                margin: getMargin(
                                  left: 48,
                                  top: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              CustomIconButton(
                height: 60,
                width: 60,
                margin: getMargin(
                  left: 29,
                  bottom: 33,
                ),
                variant: IconButtonVariant.FillWhiteA700,
                shape: IconButtonShape.CircleBorder30,
                padding: IconButtonPadding.PaddingAll15,
                alignment: Alignment.bottomLeft,
                child: CustomImageView(
                  svgPath: ImageConstant.imgTrash,
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Bottomnavicons:
        return AppRoutes.vhackHomeCandiPageOnePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.vhackHomeCandiPageOnePage:
        return VhackHomeCandiPageOnePage();
      default:
        return DefaultWidget();
    }
  }
}
