import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_home_candi_page_one_page/vhack_home_candi_page_one_page.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_subtitle.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_title.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_bottom_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class VhackHomeCompaPageTwoScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: size.height,
          width: double.maxFinite,
          decoration: AppDecoration.fillWhiteA700,
          child: Stack(
            alignment: Alignment.bottomLeft,
            children: [
              Align(
                alignment: Alignment.center,
                child: Container(
                  padding: getPadding(
                    top: 10,
                    bottom: 10,
                  ),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        ImageConstant.imgGroup41,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomAppBar(
                        height: getVerticalSize(
                          20,
                        ),
                        title: AppbarTitle(
                          text: "Candidates",
                          margin: getMargin(
                            left: 93,
                          ),
                        ),
                        actions: [
                          AppbarImage(
                            height: getVerticalSize(
                              11,
                            ),
                            width: getHorizontalSize(
                              1,
                            ),
                            svgPath: ImageConstant.imgVector1,
                            margin: getMargin(
                              left: 35,
                              top: 3,
                              bottom: 5,
                            ),
                          ),
                          AppbarSubtitle(
                            text: "Companies",
                            margin: getMargin(
                              left: 34,
                              top: 1,
                              right: 87,
                            ),
                          ),
                        ],
                      ),
                      Spacer(),
                      CustomImageView(
                        imagePath: ImageConstant.imgEllipse32,
                        height: getSize(
                          47,
                        ),
                        width: getSize(
                          47,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            23,
                          ),
                        ),
                        margin: getMargin(
                          right: 7,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.img86668055121,
                        height: getVerticalSize(
                          54,
                        ),
                        width: getHorizontalSize(
                          50,
                        ),
                        margin: getMargin(
                          top: 18,
                          right: 5,
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          right: 18,
                        ),
                        decoration: AppDecoration.txtOutlineBlack9004c,
                        child: Text(
                          "88K",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: AppStyle.txtRobotoBlack13,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgImage18,
                        height: getSize(
                          40,
                        ),
                        width: getSize(
                          40,
                        ),
                        margin: getMargin(
                          top: 21,
                          right: 10,
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Padding(
                          padding: getPadding(
                            left: 12,
                            top: 77,
                            right: 9,
                            bottom: 87,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: getPadding(
                                  bottom: 45,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    RichText(
                                      text: TextSpan(
                                        children: [
                                          TextSpan(
                                            text: "@Hilti",
                                            style: TextStyle(
                                              color: ColorConstant.whiteA700,
                                              fontSize: getFontSize(
                                                17,
                                              ),
                                              fontFamily: 'Roboto',
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                          TextSpan(
                                            text: " · ",
                                            style: TextStyle(
                                              color: ColorConstant.whiteA70099,
                                              fontSize: getFontSize(
                                                17,
                                              ),
                                              fontFamily: 'Roboto',
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                          TextSpan(
                                            text: "1-28",
                                            style: TextStyle(
                                              color: ColorConstant.whiteA70099,
                                              fontSize: getFontSize(
                                                15,
                                              ),
                                              fontFamily: 'Roboto',
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                        ],
                                      ),
                                      textAlign: TextAlign.left,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 9,
                                      ),
                                      child: Text(
                                        "#construction #engineering #software",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtRobotoBlack15,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  91,
                                ),
                                width: getHorizontalSize(
                                  89,
                                ),
                                margin: getMargin(
                                  top: 1,
                                ),
                                child: Stack(
                                  alignment: Alignment.bottomRight,
                                  children: [
                                    CustomImageView(
                                      svgPath: ImageConstant.imgQuestion,
                                      height: getVerticalSize(
                                        82,
                                      ),
                                      width: getHorizontalSize(
                                        58,
                                      ),
                                      alignment: Alignment.topLeft,
                                    ),
                                    Align(
                                      alignment: Alignment.bottomRight,
                                      child: Card(
                                        clipBehavior: Clip.antiAlias,
                                        elevation: 0,
                                        margin: EdgeInsets.all(0),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            getHorizontalSize(
                                              24,
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          height: getSize(
                                            49,
                                          ),
                                          width: getSize(
                                            49,
                                          ),
                                          padding: getPadding(
                                            all: 5,
                                          ),
                                          decoration: AppDecoration
                                              .gradientGray900Bluegray900
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder23,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgFrame11,
                                                height: getSize(
                                                  38,
                                                ),
                                                width: getSize(
                                                  38,
                                                ),
                                                radius: BorderRadius.circular(
                                                  getHorizontalSize(
                                                    19,
                                                  ),
                                                ),
                                                alignment: Alignment.center,
                                              ),
                                              CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgEllipse338x38,
                                                height: getSize(
                                                  38,
                                                ),
                                                width: getSize(
                                                  38,
                                                ),
                                                radius: BorderRadius.circular(
                                                  getHorizontalSize(
                                                    19,
                                                  ),
                                                ),
                                                alignment: Alignment.center,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              CustomIconButton(
                height: 60,
                width: 60,
                margin: getMargin(
                  left: 23,
                  bottom: 28,
                ),
                variant: IconButtonVariant.FillWhiteA700,
                shape: IconButtonShape.CircleBorder30,
                padding: IconButtonPadding.PaddingAll15,
                alignment: Alignment.bottomLeft,
                child: CustomImageView(
                  svgPath: ImageConstant.imgTrashBlue400,
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Bottomnavicons:
        return AppRoutes.vhackHomeCandiPageOnePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.vhackHomeCandiPageOnePage:
        return VhackHomeCandiPageOnePage();
      default:
        return DefaultWidget();
    }
  }
}
