import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class CompanyApply13Screen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: getVerticalSize(
            654,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                  width: double.maxFinite,
                  margin: getMargin(
                    bottom: 83,
                  ),
                  padding: getPadding(
                    left: 3,
                    right: 3,
                  ),
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: getPadding(
                          top: 11,
                          bottom: 543,
                        ),
                        child: Text(
                          "Chat",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoBlack13Gray90001,
                        ),
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgCloseGray90001,
                        height: getSize(
                          39,
                        ),
                        width: getSize(
                          39,
                        ),
                        margin: getMargin(
                          left: 152,
                          bottom: 532,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: Padding(
                          padding: getPadding(
                            right: 3,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: getPadding(
                                  top: 12,
                                  bottom: 10,
                                ),
                                child: Text(
                                  "Full Stack Developer",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtRobotoBlack13Gray90001,
                                ),
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgCloseGray90001,
                                height: getSize(
                                  39,
                                ),
                                width: getSize(
                                  39,
                                ),
                                margin: getMargin(
                                  left: 105,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 18,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 13,
                          top: 9,
                          right: 13,
                          bottom: 9,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: getPadding(
                                top: 1,
                              ),
                              child: Text(
                                "Qualification",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtRobotoBlack20,
                              ),
                            ),
                            Container(
                              width: getHorizontalSize(
                                355,
                              ),
                              margin: getMargin(
                                top: 3,
                              ),
                              child: Text(
                                "Advance Diploma, Bachelor's Degree, Professional Degree, Master's Degree in IT/ Computer Science/ Computer engineering/ Information System or any IT related fields.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 18,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 11,
                          right: 14,
                          bottom: 11,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Job Scope",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                355,
                              ),
                              margin: getMargin(
                                top: 2,
                                bottom: 2,
                              ),
                              child: Text(
                                "Design and implement responsive web & mobile applications from front to back using open source frameworks like MEAN, Ionic and Swagger.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 16,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 12,
                          right: 14,
                          bottom: 12,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "Looking for",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                348,
                              ),
                              margin: getMargin(
                                left: 6,
                                top: 1,
                              ),
                              child: Text(
                                "Candidates proven hands-on experience with Javascript (preferably popular frameworks like AngularJS, React, KnockoutJS etc.), HTML5 & CSS.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 16,
                          top: 11,
                          right: 14,
                        ),
                        padding: getPadding(
                          left: 14,
                          top: 8,
                          right: 14,
                          bottom: 8,
                        ),
                        decoration: AppDecoration.fillGray50.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Prefer",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoBlack20,
                            ),
                            Container(
                              width: getHorizontalSize(
                                348,
                              ),
                              margin: getMargin(
                                left: 6,
                                top: 5,
                                right: 1,
                                bottom: 4,
                              ),
                              child: Text(
                                "Candidates experience developing mobile applications would be considered an advantage.\nExperience with NodeJS, Swagger, MongoDB, PostgreSQL and MS SQL Server would be considered an advantage.\nPreferably 2-3 years of working experience.\nCandidates who are able to start work immediately will have an added advantage.\nFresh graduates with enthusiasm for learning new skills and technologies are encouraged to apply.",
                                maxLines: null,
                                textAlign: TextAlign.justify,
                                style: AppStyle.txtRobotoBlack11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      CustomButton(
                        width: getHorizontalSize(
                          85,
                        ),
                        text: "Apply",
                        margin: getMargin(
                          top: 33,
                        ),
                        variant: ButtonVariant.OutlineBlack90026,
                        shape: ButtonShape.RoundedBorder6,
                        fontStyle: ButtonFontStyle.InterSemiBold16,
                      ),
                      Container(
                        height: getVerticalSize(
                          17,
                        ),
                        width: double.maxFinite,
                        margin: getMargin(
                          top: 6,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.whiteA700,
                          boxShadow: [
                            BoxShadow(
                              color: ColorConstant.blueGray100,
                              spreadRadius: getHorizontalSize(
                                2,
                              ),
                              blurRadius: getHorizontalSize(
                                2,
                              ),
                              offset: Offset(
                                0,
                                -0.33,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
