import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_home_candi_page_one_page/vhack_home_candi_page_one_page.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_bottom_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class VideoUploadScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                height: size.height,
                width: double.maxFinite,
                child: Stack(alignment: Alignment.bottomRight, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          height: size.height,
                          width: double.maxFinite,
                          decoration: AppDecoration.fillBlack900,
                          child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                CustomImageView(
                                    imagePath: ImageConstant.imgBackground,
                                    height: getVerticalSize(750),
                                    width: getHorizontalSize(414),
                                    radius: BorderRadius.circular(
                                        getHorizontalSize(12)),
                                    alignment: Alignment.topCenter),
                                Align(
                                    alignment: Alignment.topCenter,
                                    child: Padding(
                                        padding: getPadding(
                                            left: 8,
                                            top: 6,
                                            right: 8,
                                            bottom: 135),
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.end,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Divider(
                                                  height: getVerticalSize(6),
                                                  thickness: getVerticalSize(6),
                                                  color:
                                                      ColorConstant.black90063),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 12,
                                                      top: 19,
                                                      right: 4),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        CustomImageView(
                                                            svgPath:
                                                                ImageConstant
                                                                    .imgClose,
                                                            height: getSize(16),
                                                            width: getSize(16),
                                                            margin: getMargin(
                                                                top: 3,
                                                                bottom: 332),
                                                            onTap: () {
                                                              onTapImgClose(
                                                                  context);
                                                            }),
                                                        Container(
                                                            decoration:
                                                                AppDecoration
                                                                    .outlineBlack90033,
                                                            child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgVolume,
                                                                      height:
                                                                          getVerticalSize(
                                                                              22),
                                                                      width: getHorizontalSize(
                                                                          27)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          top:
                                                                              7),
                                                                      child: Text(
                                                                          "Flip",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtRobotoRegular10)),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgAlarm,
                                                                      height:
                                                                          getSize(
                                                                              24),
                                                                      width:
                                                                          getSize(
                                                                              24),
                                                                      margin: getMargin(
                                                                          top:
                                                                              19)),
                                                                  Align(
                                                                      alignment:
                                                                          Alignment
                                                                              .centerLeft,
                                                                      child: Padding(
                                                                          padding: getPadding(
                                                                              left:
                                                                                  1,
                                                                              top:
                                                                                  6),
                                                                          child: Text(
                                                                              "Speed",
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtRobotoRegular10))),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgCut,
                                                                      height:
                                                                          getSize(
                                                                              24),
                                                                      width:
                                                                          getSize(
                                                                              24),
                                                                      margin: getMargin(
                                                                          top:
                                                                              19)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          top:
                                                                              6),
                                                                      child: Text(
                                                                          "Beauty",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtRobotoRegular10)),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgFiltersicon,
                                                                      height:
                                                                          getVerticalSize(
                                                                              23),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              24),
                                                                      margin: getMargin(
                                                                          top:
                                                                              19)),
                                                                  Align(
                                                                      alignment:
                                                                          Alignment
                                                                              .centerLeft,
                                                                      child: Padding(
                                                                          padding: getPadding(
                                                                              left:
                                                                                  1,
                                                                              top:
                                                                                  5),
                                                                          child: Text(
                                                                              "Filters",
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtRobotoRegular10))),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgClock,
                                                                      height:
                                                                          getVerticalSize(
                                                                              24),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              22),
                                                                      margin: getMargin(
                                                                          top:
                                                                              21)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          top:
                                                                              5),
                                                                      child: Text(
                                                                          "Timer",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtRobotoRegular10)),
                                                                  CustomImageView(
                                                                      svgPath: ImageConstant
                                                                          .imgAirplane,
                                                                      height:
                                                                          getVerticalSize(
                                                                              24),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              18),
                                                                      alignment:
                                                                          Alignment
                                                                              .centerLeft,
                                                                      margin: getMargin(
                                                                          left:
                                                                              5,
                                                                          top:
                                                                              20)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          top:
                                                                              5),
                                                                      child: Text(
                                                                          "Flash",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtRobotoRegular10))
                                                                ]))
                                                      ])),
                                              Spacer(),
                                              Padding(
                                                  padding:
                                                      getPadding(right: 57),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: [
                                                        CustomImageView(
                                                            svgPath: ImageConstant
                                                                .imgLightbulb,
                                                            height: getSize(80),
                                                            width: getSize(80)),
                                                        Padding(
                                                            padding: getPadding(
                                                                left: 66,
                                                                top: 24,
                                                                bottom: 4),
                                                            child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgDownload,
                                                                      height:
                                                                          getSize(
                                                                              32),
                                                                      width: getSize(
                                                                          32)),
                                                                  Container(
                                                                      margin: getMargin(
                                                                          top:
                                                                              6),
                                                                      decoration:
                                                                          AppDecoration
                                                                              .txtOutlineBlack90019,
                                                                      child: Text(
                                                                          "Upload",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .center,
                                                                          style:
                                                                              AppStyle.txtRobotoRegular11))
                                                                ]))
                                                      ]))
                                            ])))
                              ]))),
                  CustomIconButton(
                      height: 60,
                      width: 60,
                      margin: getMargin(right: 28, bottom: 33),
                      variant: IconButtonVariant.FillWhiteA700,
                      shape: IconButtonShape.CircleBorder30,
                      padding: IconButtonPadding.PaddingAll15,
                      alignment: Alignment.bottomRight,
                      child: CustomImageView(svgPath: ImageConstant.imgVideo))
                ])),
            bottomNavigationBar:
                CustomBottomBar(onChanged: (BottomBarEnum type) {
              Navigator.pushNamed(
                  navigatorKey.currentContext!, getCurrentRoute(type));
            })));
  }

  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Bottomnavicons:
        return AppRoutes.vhackHomeCandiPageOnePage;
      default:
        return "/";
    }
  }

  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.vhackHomeCandiPageOnePage:
        return VhackHomeCandiPageOnePage();
      default:
        return DefaultWidget();
    }
  }

  onTapImgClose(BuildContext context) {
    Navigator.pop(context);
  }
}
