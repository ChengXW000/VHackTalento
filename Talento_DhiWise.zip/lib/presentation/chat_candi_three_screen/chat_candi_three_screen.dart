import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:flutter/material.dart';

class ChatCandiThreeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: getVerticalSize(
            571,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.topRight,
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: getPadding(
                    top: 11,
                  ),
                  child: Text(
                    "Chat",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtRobotoBlack13Gray90001,
                  ),
                ),
              ),
              CustomImageView(
                svgPath: ImageConstant.imgCloseGray90001,
                height: getSize(
                  39,
                ),
                width: getSize(
                  39,
                ),
                alignment: Alignment.topRight,
                margin: getMargin(
                  right: 3,
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  padding: getPadding(
                    left: 3,
                    right: 3,
                  ),
                  decoration: AppDecoration.fillGray100.copyWith(
                    borderRadius: BorderRadiusStyle.customBorderTL8,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: getPadding(
                                top: 11,
                                bottom: 11,
                              ),
                              child: Text(
                                "Chat",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtRobotoBlack13Gray90001,
                              ),
                            ),
                            CustomImageView(
                              svgPath: ImageConstant.imgCloseGray90001,
                              height: getSize(
                                39,
                              ),
                              width: getSize(
                                39,
                              ),
                              margin: getMargin(
                                left: 152,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 15,
                          top: 31,
                          bottom: 363,
                        ),
                        padding: getPadding(
                          left: 8,
                          top: 5,
                          right: 8,
                          bottom: 5,
                        ),
                        decoration: AppDecoration.fillGray200.copyWith(
                          borderRadius: BorderRadiusStyle.customBorderBL16,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: getHorizontalSize(
                                242,
                              ),
                              margin: getMargin(
                                top: 3,
                                right: 6,
                              ),
                              child: RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text:
                                          "Our company is work on training International Certificate in Ethical Hacking and other Cybersecurity courses. Also, we can accept Malaysian university students for internship to work as web backend developer or work in marketing section. We cannot pay money (salary) for internship. If you are interested in our courses to register or work as an internship, you can message me for more information. WhatsApp: +60173605097 Montana Education and Training (Malaysia) ",
                                      style: TextStyle(
                                        color: ColorConstant.black900,
                                        fontSize: getFontSize(
                                          10,
                                        ),
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    TextSpan(
                                      text: "https://www.montana.com.my/",
                                      style: TextStyle(
                                        color: ColorConstant.black900,
                                        fontSize: getFontSize(
                                          10,
                                        ),
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w400,
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                  ],
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Text(
                              "03:50",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtRobotoRomanRegular10,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Container(
          height: getVerticalSize(
            82,
          ),
          width: double.maxFinite,
          decoration: AppDecoration.outlineBluegray100,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: getPadding(
                    left: 18,
                    top: 15,
                    right: 16,
                    bottom: 45,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: getPadding(
                          bottom: 3,
                        ),
                        child: Text(
                          "Type Message ...",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoRegular15,
                        ),
                      ),
                      Spacer(),
                      CustomImageView(
                        svgPath: ImageConstant.imgAdsignstrokeicon,
                        height: getSize(
                          22,
                        ),
                        width: getSize(
                          22,
                        ),
                      ),
                      Container(
                        height: getSize(
                          22,
                        ),
                        width: getSize(
                          22,
                        ),
                        margin: getMargin(
                          left: 22,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.gray90001,
                          borderRadius: BorderRadius.circular(
                            getHorizontalSize(
                              11,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  width: double.maxFinite,
                  padding: getPadding(
                    left: 16,
                    top: 15,
                    right: 16,
                    bottom: 15,
                  ),
                  decoration: AppDecoration.outlineBluegray100,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: getPadding(
                          left: 1,
                          bottom: 33,
                        ),
                        child: Text(
                          "Type Message ...",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoRegular15,
                        ),
                      ),
                      Spacer(),
                      CustomImageView(
                        svgPath: ImageConstant.imgAdsignstrokeicon,
                        height: getSize(
                          22,
                        ),
                        width: getSize(
                          22,
                        ),
                        margin: getMargin(
                          bottom: 30,
                        ),
                      ),
                      Container(
                        height: getSize(
                          22,
                        ),
                        width: getSize(
                          22,
                        ),
                        margin: getMargin(
                          left: 22,
                          bottom: 30,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.gray90001,
                          borderRadius: BorderRadius.circular(
                            getHorizontalSize(
                              11,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
