import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class CompanyDescriptionOneScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                height: getVerticalSize(717),
                width: double.maxFinite,
                child: Stack(alignment: Alignment.topCenter, children: [
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                          decoration: AppDecoration.fillGray100.copyWith(
                              borderRadius: BorderRadiusStyle.customBorderTL8),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CustomImageView(
                                    svgPath: ImageConstant.imgCloseGray90001,
                                    height: getSize(39),
                                    width: getSize(39),
                                    alignment: Alignment.centerRight,
                                    margin: getMargin(top: 3)),
                                Padding(
                                    padding: getPadding(top: 21),
                                    child: Text("Fusionex Group",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtRobotoBlack24)),
                                Padding(
                                    padding: getPadding(top: 1),
                                    child: Text("#IT #services #consulting",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtRobotoBlack13Black90099)),
                                Container(
                                    height: getVerticalSize(371),
                                    width: getHorizontalSize(384),
                                    margin: getMargin(top: 9),
                                    child: Stack(
                                        alignment: Alignment.bottomCenter,
                                        children: [
                                          Align(
                                              alignment: Alignment.topCenter,
                                              child: Container(
                                                  padding: getPadding(
                                                      left: 22,
                                                      top: 42,
                                                      right: 22,
                                                      bottom: 42),
                                                  decoration: AppDecoration
                                                      .fillGray50
                                                      .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .roundedBorder8),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Padding(
                                                            padding: getPadding(
                                                                top: 1,
                                                                right: 10),
                                                            child: Text(
                                                                "Focus : IT Services and IT Consulting",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtRobotoBlack11Bluegray400)),
                                                        Padding(
                                                            padding: getPadding(
                                                                top: 6),
                                                            child: Text(
                                                                "Specializes : Analytics, Big Data, ML/AI",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtRobotoBlack11Bluegray400))
                                                      ]))),
                                          Align(
                                              alignment: Alignment.bottomCenter,
                                              child: Container(
                                                  padding: getPadding(
                                                      left: 17,
                                                      top: 10,
                                                      right: 17,
                                                      bottom: 10),
                                                  decoration: AppDecoration
                                                      .fillGray50
                                                      .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .roundedBorder8),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        Align(
                                                            alignment: Alignment
                                                                .centerLeft,
                                                            child: Text(
                                                                "Hiring",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtRobotoBlack20)),
                                                        CustomButton(
                                                            height:
                                                                getVerticalSize(
                                                                    35),
                                                            text:
                                                                "Intern - Software Engineer",
                                                            margin: getMargin(
                                                                left: 13,
                                                                top: 10,
                                                                right: 13),
                                                            variant:
                                                                ButtonVariant
                                                                    .FillGray50,
                                                            shape: ButtonShape
                                                                .RoundedBorder6,
                                                            fontStyle:
                                                                ButtonFontStyle
                                                                    .RobotoRomanMedium15,
                                                            onTap: () =>
                                                                onTapInternsoftwareengineer(
                                                                    context)),
                                                        CustomButton(
                                                            height:
                                                                getVerticalSize(
                                                                    35),
                                                            text:
                                                                "Intern - Web Development",
                                                            margin: getMargin(
                                                                left: 13,
                                                                top: 12,
                                                                right: 13),
                                                            variant:
                                                                ButtonVariant
                                                                    .FillGray50,
                                                            shape: ButtonShape
                                                                .RoundedBorder6,
                                                            fontStyle:
                                                                ButtonFontStyle
                                                                    .RobotoRomanMedium15,
                                                            onTap: () =>
                                                                onTapInternwebdevelopment(
                                                                    context)),
                                                        CustomButton(
                                                            height:
                                                                getVerticalSize(
                                                                    35),
                                                            text:
                                                                "Full Stack Developer",
                                                            margin: getMargin(
                                                                left: 13,
                                                                top: 12,
                                                                right: 13,
                                                                bottom: 57),
                                                            variant:
                                                                ButtonVariant
                                                                    .FillGray50,
                                                            shape: ButtonShape
                                                                .RoundedBorder6,
                                                            fontStyle:
                                                                ButtonFontStyle
                                                                    .RobotoRomanMedium15,
                                                            onTap: () =>
                                                                onTapFullstackdeveloper(
                                                                    context))
                                                      ]))),
                                          Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                  height: getVerticalSize(137),
                                                  width: getHorizontalSize(131),
                                                  margin: getMargin(left: 15),
                                                  child: Stack(
                                                      alignment:
                                                          Alignment.topLeft,
                                                      children: [
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage14,
                                                            height:
                                                                getVerticalSize(
                                                                    137),
                                                            width:
                                                                getHorizontalSize(
                                                                    131),
                                                            alignment: Alignment
                                                                .center),
                                                        Align(
                                                            alignment: Alignment
                                                                .topLeft,
                                                            child: Container(
                                                                height:
                                                                    getVerticalSize(
                                                                        24),
                                                                width:
                                                                    getHorizontalSize(
                                                                        83),
                                                                margin:
                                                                    getMargin(
                                                                        left: 1,
                                                                        top: 9),
                                                                child: Stack(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    children: [
                                                                      Align(
                                                                          alignment: Alignment
                                                                              .center,
                                                                          child: Text(
                                                                              "About Us",
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtRobotoBlack20)),
                                                                      Align(
                                                                          alignment: Alignment
                                                                              .center,
                                                                          child: Text(
                                                                              "About Us",
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtRobotoBlack20))
                                                                    ])))
                                                      ])))
                                        ])),
                                Container(
                                    height: getVerticalSize(17),
                                    width: double.maxFinite,
                                    margin: getMargin(top: 26),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.whiteA700,
                                        boxShadow: [
                                          BoxShadow(
                                              color: ColorConstant.blueGray100,
                                              spreadRadius:
                                                  getHorizontalSize(2),
                                              blurRadius: getHorizontalSize(2),
                                              offset: Offset(0, -0.33))
                                        ]))
                              ]))),
                  CustomImageView(
                      imagePath: ImageConstant.imgEllipse3100x100,
                      height: getSize(100),
                      width: getSize(100),
                      radius: BorderRadius.circular(getHorizontalSize(50)),
                      alignment: Alignment.topCenter,
                      margin: getMargin(top: 134))
                ]))));
  }

  onTapInternsoftwareengineer(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.companyApply11Screen);
  }

  onTapInternwebdevelopment(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.companyApply12Screen);
  }

  onTapFullstackdeveloper(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.companyApply13Screen);
  }
}
