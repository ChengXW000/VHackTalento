import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class CompanyDescriptionTwoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                height: getVerticalSize(717),
                width: double.maxFinite,
                child: Stack(alignment: Alignment.topCenter, children: [
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                          decoration: AppDecoration.fillGray100.copyWith(
                              borderRadius: BorderRadiusStyle.customBorderTL8),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CustomImageView(
                                    svgPath: ImageConstant.imgCloseGray90001,
                                    height: getSize(39),
                                    width: getSize(39),
                                    alignment: Alignment.centerRight,
                                    margin: getMargin(top: 3)),
                                Padding(
                                    padding: getPadding(top: 18),
                                    child: Text("Hilti",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtRobotoBlack24)),
                                Padding(
                                    padding: getPadding(top: 3),
                                    child: Text(
                                        "#construction #engineering #software",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtRobotoBlack13Black90099)),
                                Container(
                                    margin:
                                        getMargin(left: 13, top: 9, right: 17),
                                    padding: getPadding(
                                        left: 16, top: 9, right: 16, bottom: 9),
                                    decoration: AppDecoration.fillGray50
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder8),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Container(
                                              height: getVerticalSize(24),
                                              width: getHorizontalSize(83),
                                              child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Text("About Us",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtRobotoBlack20)),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Text("About Us",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtRobotoBlack20))
                                                  ])),
                                          Padding(
                                              padding: getPadding(
                                                  top: 8, right: 7, bottom: 18),
                                              child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    CustomImageView(
                                                        imagePath: ImageConstant
                                                            .imgImage20,
                                                        height:
                                                            getVerticalSize(30),
                                                        width:
                                                            getHorizontalSize(
                                                                130),
                                                        margin: getMargin(
                                                            top: 1,
                                                            bottom: 15)),
                                                    Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                              "Focus : Construction ",
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtRobotoBlack11Bluegray400),
                                                          Container(
                                                              width:
                                                                  getHorizontalSize(
                                                                      194),
                                                              margin: getMargin(
                                                                  top: 5),
                                                              child: Text(
                                                                  "Specializes : Engineering, Power Tools,  \n                        Services, Quality",
                                                                  maxLines:
                                                                      null,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtRobotoBlack11))
                                                        ])
                                                  ]))
                                        ])),
                                Container(
                                    width: getHorizontalSize(384),
                                    margin:
                                        getMargin(left: 13, top: 11, right: 17),
                                    padding: getPadding(
                                        left: 17,
                                        top: 10,
                                        right: 17,
                                        bottom: 10),
                                    decoration: AppDecoration.fillGray50
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder8),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text("Hiring",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoBlack20)),
                                          CustomButton(
                                              height: getVerticalSize(35),
                                              text:
                                                  "Fresh Graduate - Software Engineer",
                                              margin: getMargin(
                                                  left: 13, top: 10, right: 13),
                                              variant: ButtonVariant.FillGray50,
                                              shape: ButtonShape.RoundedBorder6,
                                              fontStyle: ButtonFontStyle
                                                  .RobotoRomanMedium15,
                                              onTap: () =>
                                                  onTapFreshgraduatesoftwareengineer(
                                                      context)),
                                          CustomButton(
                                              height: getVerticalSize(35),
                                              text:
                                                  "Fresh Graduate - IT Business Analyst",
                                              margin: getMargin(
                                                  left: 13, top: 12, right: 13),
                                              variant: ButtonVariant.FillGray50,
                                              shape: ButtonShape.RoundedBorder6,
                                              fontStyle: ButtonFontStyle
                                                  .RobotoRomanMedium15),
                                          CustomButton(
                                              height: getVerticalSize(35),
                                              text:
                                                  "Fresh Graduate - IT Support",
                                              margin: getMargin(
                                                  left: 13,
                                                  top: 12,
                                                  right: 13,
                                                  bottom: 57),
                                              variant: ButtonVariant.FillGray50,
                                              shape: ButtonShape.RoundedBorder6,
                                              fontStyle: ButtonFontStyle
                                                  .RobotoRomanMedium15)
                                        ])),
                                Container(
                                    height: getVerticalSize(17),
                                    width: double.maxFinite,
                                    margin: getMargin(top: 26),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.whiteA700,
                                        boxShadow: [
                                          BoxShadow(
                                              color: ColorConstant.blueGray100,
                                              spreadRadius:
                                                  getHorizontalSize(2),
                                              blurRadius: getHorizontalSize(2),
                                              offset: Offset(0, -0.33))
                                        ]))
                              ]))),
                  CustomImageView(
                      imagePath: ImageConstant.imgEllipse34,
                      height: getSize(100),
                      width: getSize(100),
                      radius: BorderRadius.circular(getHorizontalSize(50)),
                      alignment: Alignment.topCenter,
                      margin: getMargin(top: 134))
                ]))));
  }

  onTapFreshgraduatesoftwareengineer(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.companyApply21Screen);
  }
}
