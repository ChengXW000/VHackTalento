import 'package:cheng_xiang_wen_s_application3/core/app_export.dart';
import 'package:cheng_xiang_wen_s_application3/presentation/vhack_home_candi_page_one_page/vhack_home_candi_page_one_page.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_subtitle.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/appbar_title.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:cheng_xiang_wen_s_application3/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class VhackSavedCompaPageOneScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                height: size.height,
                width: double.maxFinite,
                decoration: AppDecoration.fillWhiteA700,
                child: Stack(alignment: Alignment.bottomRight, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding: getPadding(top: 11, bottom: 11),
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage(ImageConstant.imgGroup71),
                                  fit: BoxFit.cover)),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomAppBar(
                                    height: getVerticalSize(20),
                                    title: AppbarTitle(
                                        text: "Candidates",
                                        margin: getMargin(left: 93),
                                        onTap: () => onTapCandidates(context)),
                                    actions: [
                                      AppbarImage(
                                          height: getVerticalSize(11),
                                          width: getHorizontalSize(1),
                                          svgPath: ImageConstant.imgVector1,
                                          margin: getMargin(
                                              left: 35, top: 3, bottom: 5)),
                                      AppbarSubtitle(
                                          text: "Companies",
                                          margin: getMargin(
                                              left: 34, top: 1, right: 87))
                                    ]),
                                Spacer(),
                                CustomImageView(
                                    imagePath: ImageConstant.imgEllipse35,
                                    height: getSize(47),
                                    width: getSize(47),
                                    radius: BorderRadius.circular(
                                        getHorizontalSize(23)),
                                    margin: getMargin(right: 7),
                                    onTap: () {
                                      onTapImgEllipseThree(context);
                                    }),
                                CustomImageView(
                                    imagePath: ImageConstant.img86668055121,
                                    height: getVerticalSize(54),
                                    width: getHorizontalSize(50),
                                    margin: getMargin(top: 18, right: 5)),
                                Container(
                                    margin: getMargin(right: 18),
                                    decoration:
                                        AppDecoration.txtOutlineBlack9004c,
                                    child: Text("58K",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtRobotoBlack13)),
                                CustomImageView(
                                    imagePath: ImageConstant.imgImage18,
                                    height: getSize(40),
                                    width: getSize(40),
                                    margin: getMargin(top: 21, right: 10),
                                    onTap: () {
                                      onTapImgImageEighteen(context);
                                    }),
                                Align(
                                    alignment: Alignment.center,
                                    child: Padding(
                                        padding: getPadding(
                                            left: 12,
                                            top: 77,
                                            right: 9,
                                            bottom: 86),
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                  padding:
                                                      getPadding(bottom: 45),
                                                  child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        RichText(
                                                            text: TextSpan(
                                                                children: [
                                                                  TextSpan(
                                                                      text:
                                                                          "@DigitalPenang",
                                                                      style: TextStyle(
                                                                          color: ColorConstant
                                                                              .whiteA700,
                                                                          fontSize: getFontSize(
                                                                              17),
                                                                          fontFamily:
                                                                              'Roboto',
                                                                          fontWeight:
                                                                              FontWeight.w900)),
                                                                  TextSpan(
                                                                      text:
                                                                          " · ",
                                                                      style: TextStyle(
                                                                          color: ColorConstant
                                                                              .whiteA70099,
                                                                          fontSize: getFontSize(
                                                                              17),
                                                                          fontFamily:
                                                                              'Roboto',
                                                                          fontWeight:
                                                                              FontWeight.w900)),
                                                                  TextSpan(
                                                                      text:
                                                                          "1-28",
                                                                      style: TextStyle(
                                                                          color: ColorConstant
                                                                              .whiteA70099,
                                                                          fontSize: getFontSize(
                                                                              15),
                                                                          fontFamily:
                                                                              'Roboto',
                                                                          fontWeight:
                                                                              FontWeight.w900))
                                                                ]),
                                                            textAlign:
                                                                TextAlign.left),
                                                        Padding(
                                                            padding: getPadding(
                                                                top: 8),
                                                            child: Text("#",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtRobotoBlack15)),
                                                        Text(
                                                            "#IT #services #consulting",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtRobotoBlack15)
                                                      ])),
                                              Container(
                                                  height: getVerticalSize(91),
                                                  width: getHorizontalSize(89),
                                                  margin: getMargin(top: 1),
                                                  child: Stack(
                                                      alignment:
                                                          Alignment.bottomRight,
                                                      children: [
                                                        CustomImageView(
                                                            svgPath:
                                                                ImageConstant
                                                                    .imgQuestion,
                                                            height:
                                                                getVerticalSize(
                                                                    82),
                                                            width:
                                                                getHorizontalSize(
                                                                    58),
                                                            alignment: Alignment
                                                                .topLeft),
                                                        Align(
                                                            alignment: Alignment
                                                                .bottomRight,
                                                            child: Card(
                                                                clipBehavior: Clip
                                                                    .antiAlias,
                                                                elevation: 0,
                                                                margin:
                                                                    EdgeInsets.all(
                                                                        0),
                                                                shape: RoundedRectangleBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(getHorizontalSize(
                                                                            24))),
                                                                child:
                                                                    Container(
                                                                        height: getSize(
                                                                            49),
                                                                        width: getSize(
                                                                            49),
                                                                        padding: getPadding(
                                                                            all:
                                                                                5),
                                                                        decoration: AppDecoration.gradientGray900Bluegray900.copyWith(
                                                                            borderRadius: BorderRadiusStyle
                                                                                .roundedBorder23),
                                                                        child: Stack(
                                                                            alignment:
                                                                                Alignment.center,
                                                                            children: [
                                                                              CustomImageView(imagePath: ImageConstant.imgFrame11, height: getSize(38), width: getSize(38), radius: BorderRadius.circular(getHorizontalSize(19)), alignment: Alignment.center),
                                                                              CustomImageView(imagePath: ImageConstant.imgEllipse338x38, height: getSize(38), width: getSize(38), radius: BorderRadius.circular(getHorizontalSize(19)), alignment: Alignment.center)
                                                                            ]))))
                                                      ]))
                                            ])))
                              ]))),
                  Align(
                      alignment: Alignment.bottomRight,
                      child: Card(
                          clipBehavior: Clip.antiAlias,
                          elevation: 0,
                          margin: getMargin(right: 103, bottom: 33),
                          color: ColorConstant.whiteA700,
                          shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(getHorizontalSize(30))),
                          child: Container(
                              height: getSize(60),
                              width: getSize(60),
                              padding: getPadding(all: 7),
                              decoration: AppDecoration.fillWhiteA700.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.circleBorder30),
                              child: Stack(children: [
                                CustomImageView(
                                    imagePath: ImageConstant.img90263225121,
                                    height: getSize(45),
                                    width: getSize(45),
                                    alignment: Alignment.center)
                              ]))))
                ])),
            bottomNavigationBar:
                CustomBottomBar(onChanged: (BottomBarEnum type) {
              Navigator.pushNamed(
                  navigatorKey.currentContext!, getCurrentRoute(type));
            })));
  }

  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Bottomnavicons:
        return AppRoutes.vhackHomeCandiPageOnePage;
      default:
        return "/";
    }
  }

  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.vhackHomeCandiPageOnePage:
        return VhackHomeCandiPageOnePage();
      default:
        return DefaultWidget();
    }
  }

  onTapCandidates(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.vhackSavedCandiPageOneScreen);
  }

  onTapImgEllipseThree(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.candiProfileOneScreen);
  }

  onTapImgImageEighteen(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.companySavedDescriptionScreen);
  }
}
